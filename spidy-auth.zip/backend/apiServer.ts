import express, { Request, Response } from 'express';
import { db } from '../src/shared/FirebaseConfig';
import { doc, getDoc, getDocs, updateDoc, collection, query, where, setDoc } from 'firebase/firestore';

export const apiRouter = express.Router();
apiRouter.use(express.json());

// In-memory active client sessions cache
const activeSessions = new Map<string, { appId: string; identifier: string; hwid: string; expiresAt: number }>();

// 1. POST /api/v1/application/init
apiRouter.post('/v1/application/init', async (req: Request, res: Response) => {
  try {
    const { appId, appSecret } = req.body;
    if (!appId || !appSecret) {
      return res.status(400).json({ success: false, error: 'Missing appId or appSecret' });
    }

    const appDoc = await getDoc(doc(db, 'applications', appId));
    if (!appDoc.exists()) {
      return res.status(404).json({ success: false, error: 'Application not found' });
    }

    const appData = appDoc.data();
    if (appData.appSecret !== appSecret) {
      return res.status(403).json({ success: false, error: 'Invalid application secret' });
    }

    if (appData.status !== 'active') {
      return res.status(403).json({ success: false, error: 'Application is disabled by administrator' });
    }

    const sessionToken = 'ses_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
    activeSessions.set(sessionToken, {
      appId,
      identifier: 'INIT',
      hwid: '',
      expiresAt: Date.now() + 3600 * 1000 * 2, // 2 hour session
    });

    return res.json({
      success: true,
      message: 'Application initialized successfully',
      data: {
        appName: appData.name,
        version: appData.version,
        hwidLockEnabled: appData.hwidLockEnabled,
        sessionToken,
        serverTime: new Date().toISOString(),
      },
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});

// 2. POST /api/v1/license/verify
apiRouter.post('/v1/license/verify', async (req: Request, res: Response) => {
  try {
    const { appId, key, hwid } = req.body;
    if (!appId || !key) {
      return res.status(400).json({ success: false, error: 'Missing appId or license key' });
    }

    const q = query(
      collection(db, 'license_keys'),
      where('appId', '==', appId),
      where('key', '==', key.trim())
    );
    const snap = await getDocs(q);

    if (snap.empty) {
      return res.status(404).json({ success: false, error: 'License key not found for this application' });
    }

    const keyData = snap.docs[0].data();

    if (keyData.status === 'banned') {
      return res.status(403).json({
        success: false,
        error: `License has been banned: ${keyData.bannedReason || 'Terms violation'}`,
        status: 'banned',
      });
    }

    // Check expiration
    if (keyData.expiresAt && new Date(keyData.expiresAt) < new Date()) {
      return res.status(403).json({
        success: false,
        error: 'License key has expired',
        status: 'expired',
      });
    }

    // Check HWID if bound
    let hwidMatch = true;
    if (keyData.hwid && hwid && keyData.hwid !== hwid) {
      hwidMatch = false;
    }

    return res.json({
      success: true,
      status: keyData.status,
      durationDays: keyData.durationDays,
      expiresAt: keyData.expiresAt,
      hwidMatch,
      hwidLocked: !!keyData.hwid,
      notes: keyData.notes,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});

// 3. POST /api/v1/license/login
apiRouter.post('/v1/license/login', async (req: Request, res: Response) => {
  try {
    const { appId, key, username, password, hwid } = req.body;
    if (!appId) {
      return res.status(400).json({ success: false, error: 'Missing appId' });
    }

    if (!key && (!username || !password)) {
      return res.status(400).json({ success: false, error: 'Provide license key or username/password' });
    }

    // Fetch App
    const appDoc = await getDoc(doc(db, 'applications', appId));
    if (!appDoc.exists()) {
      return res.status(404).json({ success: false, error: 'Application not found' });
    }
    const app = appDoc.data();

    // Mode A: License Key Login
    if (key) {
      const q = query(
        collection(db, 'license_keys'),
        where('appId', '==', appId),
        where('key', '==', key.trim())
      );
      const snap = await getDocs(q);

      if (snap.empty) {
        return res.status(404).json({ success: false, error: 'Invalid license key' });
      }

      const keyDoc = snap.docs[0];
      const keyData = keyDoc.data();

      if (keyData.status === 'banned') {
        return res.status(403).json({ success: false, error: `License banned: ${keyData.bannedReason || 'Violation'}` });
      }

      // Expiration check
      if (keyData.expiresAt && new Date(keyData.expiresAt) < new Date()) {
        await updateDoc(doc(db, 'license_keys', keyDoc.id), { status: 'expired' });
        return res.status(403).json({ success: false, error: 'License expired' });
      }

      // HWID binding check
      if (app.hwidLockEnabled && hwid) {
        if (!keyData.hwid) {
          // Bind on first use
          await updateDoc(doc(db, 'license_keys', keyDoc.id), {
            hwid,
            status: 'active',
            activatedAt: keyData.activatedAt || new Date().toISOString(),
          });
        } else if (keyData.hwid !== hwid) {
          return res.status(403).json({ success: false, error: 'HWID mismatch. Hardware does not match registered device.' });
        }
      }

      // If unused, activate and compute expiration
      let expiresAt = keyData.expiresAt;
      if (keyData.status === 'unused') {
        const now = new Date();
        if (keyData.durationDays > 0) {
          const exp = new Date(now);
          exp.setDate(exp.getDate() + keyData.durationDays);
          expiresAt = exp.toISOString();
        }
        await updateDoc(doc(db, 'license_keys', keyDoc.id), {
          status: 'active',
          activatedAt: now.toISOString(),
          expiresAt: expiresAt || null,
          lastUsedAt: now.toISOString(),
        });
      } else {
        await updateDoc(doc(db, 'license_keys', keyDoc.id), {
          lastUsedAt: new Date().toISOString(),
        });
      }

      const sessionToken = 'ses_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
      activeSessions.set(sessionToken, {
        appId,
        identifier: key,
        hwid: hwid || '',
        expiresAt: Date.now() + 3600 * 1000 * 24,
      });

      return res.json({
        success: true,
        message: 'Authentication successful',
        sessionToken,
        license: {
          key: keyData.key,
          status: 'active',
          durationDays: keyData.durationDays,
          expiresAt,
          hwid: hwid || keyData.hwid,
        },
      });
    }

    // Mode B: Username / Password Login
    if (username && password) {
      const q = query(
        collection(db, 'credentials'),
        where('appId', '==', appId),
        where('username', '==', username.trim())
      );
      const snap = await getDocs(q);

      if (snap.empty) {
        return res.status(404).json({ success: false, error: 'Invalid username or password' });
      }

      const credDoc = snap.docs[0];
      const cred = credDoc.data();

      // Verify simple SHA256 password hash match
      const encoder = new TextEncoder();
      const data = encoder.encode(password + '_spidy_salt_v1');
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const computedHash = Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, '0')).join('');

      if (cred.passwordHash !== computedHash) {
        return res.status(403).json({ success: false, error: 'Invalid username or password' });
      }

      if (cred.status !== 'active') {
        return res.status(403).json({ success: false, error: `Account status is ${cred.status}` });
      }

      if (cred.expiresAt && new Date(cred.expiresAt) < new Date()) {
        return res.status(403).json({ success: false, error: 'Account credentials have expired' });
      }

      // Check HWID
      if (app.hwidLockEnabled && hwid) {
        if (!cred.currentHwid) {
          await updateDoc(doc(db, 'credentials', credDoc.id), { currentHwid: hwid });
        } else if (cred.currentHwid !== hwid) {
          return res.status(403).json({ success: false, error: 'HWID mismatch for this user account' });
        }
      }

      const sessionToken = 'ses_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
      return res.json({
        success: true,
        message: 'Account login successful',
        sessionToken,
        user: {
          username: cred.username,
          expiresAt: cred.expiresAt,
          deviceLimit: cred.deviceLimit,
        },
      });
    }

    return res.status(400).json({ success: false, error: 'Bad Request' });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});

// 4. POST /api/v1/license/register (Register username+pwd using license key)
apiRouter.post('/v1/license/register', async (req: Request, res: Response) => {
  try {
    const { appId, key, username, password, hwid } = req.body;
    if (!appId || !key || !username || !password) {
      return res.status(400).json({ success: false, error: 'Missing required registration parameters' });
    }

    const q = query(
      collection(db, 'license_keys'),
      where('appId', '==', appId),
      where('key', '==', key.trim())
    );
    const snap = await getDocs(q);

    if (snap.empty) {
      return res.status(404).json({ success: false, error: 'Invalid license key' });
    }

    const keyDoc = snap.docs[0];
    const keyData = keyDoc.data();

    if (keyData.status === 'banned') {
      return res.status(403).json({ success: false, error: 'License key is banned' });
    }

    if (keyData.status === 'active' && keyData.username) {
      return res.status(400).json({ success: false, error: 'This license key has already been registered to a user' });
    }

    // Check if username is already registered in this application
    const userCheckQ = query(
      collection(db, 'credentials'),
      where('appId', '==', appId),
      where('username', '==', username.trim())
    );
    const userCheckSnap = await getDocs(userCheckQ);
    if (!userCheckSnap.empty) {
      return res.status(400).json({ success: false, error: 'Username already taken for this application' });
    }

    // Compute password hash
    const encoder = new TextEncoder();
    const data = encoder.encode(password + '_spidy_salt_v1');
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const passwordHash = Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, '0')).join('');

    const now = new Date();
    let expiresAt = null;
    if (keyData.durationDays > 0) {
      const exp = new Date(now);
      exp.setDate(exp.getDate() + keyData.durationDays);
      expiresAt = exp.toISOString();
    }

    // Create Credential document
    const credId = 'cred_' + Math.random().toString(36).substring(2);
    await setDoc(doc(db, 'credentials', credId), {
      id: credId,
      appId,
      ownerId: keyData.ownerId,
      username: username.trim(),
      passwordHash,
      durationDays: keyData.durationDays,
      status: 'active',
      deviceLimit: keyData.maxDevices || 1,
      currentHwid: hwid || null,
      expiresAt,
      createdAt: now.toISOString(),
    });

    // Update license key record
    await updateDoc(doc(db, 'license_keys', keyDoc.id), {
      status: 'active',
      username: username.trim(),
      passwordHash,
      hwid: hwid || null,
      activatedAt: now.toISOString(),
      expiresAt,
      lastUsedAt: now.toISOString(),
    });

    return res.json({
      success: true,
      message: 'Account registered successfully using license key',
      user: {
        username: username.trim(),
        expiresAt,
      },
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});

// 5. POST /api/v1/license/logout
apiRouter.post('/v1/license/logout', (req: Request, res: Response) => {
  const { sessionToken } = req.body;
  if (sessionToken && activeSessions.has(sessionToken)) {
    activeSessions.delete(sessionToken);
  }
  return res.json({ success: true, message: 'Session logged out' });
});

// 6. POST /api/v1/license/hwid-reset
apiRouter.post('/v1/license/hwid-reset', async (req: Request, res: Response) => {
  try {
    const { appId, key } = req.body;
    if (!appId || !key) {
      return res.status(400).json({ success: false, error: 'Missing appId or key' });
    }

    const q = query(collection(db, 'license_keys'), where('appId', '==', appId), where('key', '==', key.trim()));
    const snap = await getDocs(q);

    if (snap.empty) {
      return res.status(404).json({ success: false, error: 'License key not found' });
    }

    await updateDoc(doc(db, 'license_keys', snap.docs[0].id), {
      hwid: null,
      currentDevices: 0,
    });

    return res.json({ success: true, message: 'Hardware lock (HWID) reset successfully' });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});

// 7. GET /api/v1/application/version
apiRouter.get('/v1/application/version', async (req: Request, res: Response) => {
  try {
    const appId = req.query.appId as string;
    if (!appId) {
      return res.status(400).json({ success: false, error: 'Missing appId query parameter' });
    }

    const appDoc = await getDoc(doc(db, 'applications', appId));
    if (!appDoc.exists()) {
      return res.status(404).json({ success: false, error: 'Application not found' });
    }

    const app = appDoc.data();
    return res.json({
      success: true,
      appId: app.id,
      name: app.name,
      latestVersion: app.version,
      status: app.status,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});

// 8. GET /api/v1/subscription/status
apiRouter.get('/v1/subscription/status', async (req: Request, res: Response) => {
  try {
    const email = (req.query.email as string)?.trim().toLowerCase();
    if (!email) {
      return res.status(400).json({ success: false, error: 'Missing email query parameter' });
    }

    const allowQ = query(
      collection(db, 'premium_allowlist'),
      where('email', '==', email),
      where('status', '==', 'active')
    );
    const allowSnap = await getDocs(allowQ);

    if (!allowSnap.empty) {
      const rec = allowSnap.docs[0].data();
      const isExpired = rec.expiresAt && new Date(rec.expiresAt) < new Date();
      if (!isExpired) {
        return res.json({
          success: true,
          plan: 'PREMIUM',
          isPremium: true,
          expiresAt: rec.expiresAt,
          durationDays: rec.durationDays,
        });
      }
    }

    return res.json({
      success: true,
      plan: 'FREE',
      isPremium: false,
      maxKeysQuota: 50,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message || 'Internal server error' });
  }
});
