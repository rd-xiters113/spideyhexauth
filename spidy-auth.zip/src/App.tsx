import React from 'react';
import { AuthProvider } from './shared/AuthContext';
import { UserApp } from './user/UserApp';

export default function App() {
  return (
    <AuthProvider>
      <UserApp />
    </AuthProvider>
  );
}
