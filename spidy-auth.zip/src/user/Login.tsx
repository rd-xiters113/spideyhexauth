import React, { useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import { SpidyLogo } from '../shared/Components/SpidyLogo';
import { Button } from '../shared/Components/CommonUI';
import { Mail, Lock, AlertCircle, ArrowLeft } from 'lucide-react';

interface LoginProps {
  onRegisterClick: () => void;
  onForgotPasswordClick: () => void;
  onBackToHome: () => void;
}

export const Login: React.FC<LoginProps> = ({
  onRegisterClick,
  onForgotPasswordClick,
  onBackToHome,
}) => {
  const { loginWithEmail, loginWithGoogle } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await loginWithEmail(email.trim(), password);
    } catch (err: any) {
      setError(err.message?.replace('Firebase: ', '') || 'Failed to authenticate');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      setError(err.message?.replace('Firebase: ', '') || 'Google authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080808] flex items-center justify-center p-4 cyber-grid relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-[#FF2020]/10 blur-[130px] rounded-full pointer-events-none" />

      <div className="w-full max-w-md glass-card rounded-2xl p-8 border border-white/10 shadow-2xl relative z-10">
        <button
          onClick={onBackToHome}
          className="inline-flex items-center gap-1.5 text-xs text-[#888888] hover:text-white transition-colors mb-6 font-mono"
        >
          <ArrowLeft size={14} />
          <span>Back to Home</span>
        </button>

        <div className="flex flex-col items-center text-center mb-8">
          <SpidyLogo size="lg" />
          <h2 className="text-2xl font-extrabold text-white mt-4 tracking-tight">Developer Sign In</h2>
          <p className="text-xs text-[#888888] mt-1">Authenticate to manage applications and licenses</p>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-lg bg-red-950/40 border border-red-500/40 text-red-400 text-xs flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Google Authentication */}
        <button
          onClick={handleGoogleSignIn}
          disabled={loading}
          type="button"
          className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-lg bg-[#181818] hover:bg-[#202020] border border-white/10 hover:border-white/20 text-sm font-medium text-white transition-all cursor-pointer mb-6"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.36 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.97 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.36 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        <div className="relative flex items-center justify-center my-6">
          <div className="border-t border-white/10 w-full" />
          <span className="bg-[#151515] px-3 text-[11px] font-mono text-[#666666] uppercase absolute">
            or email
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 text-[#666666]" size={16} />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="developer@example.com"
                className="w-full bg-[#111111] border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-sm text-white placeholder-[#555555] focus:outline-none focus:border-[#FF2020] transition-colors"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-[#aaaaaa]">Password</label>
              <button
                type="button"
                onClick={onForgotPasswordClick}
                className="text-xs text-[#FF2020] hover:underline"
              >
                Forgot?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-[#666666]" size={16} />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-[#111111] border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-sm text-white placeholder-[#555555] focus:outline-none focus:border-[#FF2020] transition-colors"
              />
            </div>
          </div>

          <Button type="submit" variant="primary" className="w-full py-2.5 mt-2" isLoading={loading}>
            Sign In to Dashboard
          </Button>
        </form>

        <div className="mt-8 text-center text-xs text-[#888888]">
          Don't have an account?{' '}
          <button
            onClick={onRegisterClick}
            className="text-[#FF2020] hover:underline font-semibold"
          >
            Create one free (50 keys)
          </button>
        </div>
      </div>
    </div>
  );
};
