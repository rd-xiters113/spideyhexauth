import React, { useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import { LandingPage } from './LandingPage';
import { Login } from './Login';
import { Register } from './Register';
import { ForgotPassword } from './ForgotPassword';
import { Dashboard } from './Dashboard';
import { Applications } from './Applications';
import { LicenseKeys } from './LicenseKeys';
import { CredentialsManagement } from './CredentialsManagement';
import { Subscription } from './Subscription';
import { Resellers } from './Resellers';
import { ApiSdkDocs } from './ApiSdkDocs';
import { Settings } from './Settings';
import { AdminApp } from '../admin/AdminApp';
import { SpidyLogo } from '../shared/Components/SpidyLogo';
import { Badge, Button } from '../shared/Components/CommonUI';
import {
  LayoutDashboard,
  Layers,
  KeyRound,
  UserCheck,
  Zap,
  Terminal,
  Users,
  Settings as SettingsIcon,
  LogOut,
  ShieldCheck,
  Menu,
  X,
} from 'lucide-react';

export const UserApp: React.FC = () => {
  const { currentUser, userProfile, loading, isAdmin, isSuperAdmin, logout, remainingKeys } = useAuth();
  
  // Public auth view
  const [authView, setAuthView] = useState<'landing' | 'login' | 'register' | 'forgot-password'>('landing');

  // View Mode: 'user' or 'admin' (only accessible if admin)
  const [viewMode, setViewMode] = useState<'user' | 'admin'>('user');

  // Authenticated tab
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [selectedAppForKeys, setSelectedAppForKeys] = useState<string | undefined>(undefined);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#080808] flex items-center justify-center cyber-grid">
        <div className="flex flex-col items-center gap-3">
          <SpidyLogo size="lg" />
          <div className="w-6 h-6 border-2 border-[#FF2020] border-t-transparent rounded-full animate-spin mt-4" />
          <span className="text-xs text-[#888888] font-mono">Initializing Zero-Trust Engine...</span>
        </div>
      </div>
    );
  }

  // If user selected Admin Mode and is verified admin, render the complete Admin App interface!
  if (viewMode === 'admin' && (isAdmin || isSuperAdmin)) {
    return <AdminApp onExitToUser={() => setViewMode('user')} />;
  }

  // Not logged in -> Show public views (NO admin buttons shown anywhere)
  if (!currentUser) {
    if (authView === 'login') {
      return (
        <Login
          onRegisterClick={() => setAuthView('register')}
          onForgotPasswordClick={() => setAuthView('forgot-password')}
          onBackToHome={() => setAuthView('landing')}
        />
      );
    }
    if (authView === 'register') {
      return (
        <Register
          onLoginClick={() => setAuthView('login')}
          onBackToHome={() => setAuthView('landing')}
        />
      );
    }
    if (authView === 'forgot-password') {
      return <ForgotPassword onBackToLogin={() => setAuthView('login')} />;
    }
    return (
      <LandingPage
        onLogin={() => setAuthView('login')}
        onRegister={() => setAuthView('register')}
      />
    );
  }

  // Authenticated App Shell
  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'applications', label: 'Applications', icon: Layers },
    { id: 'license-keys', label: 'License Keys', icon: KeyRound },
    { id: 'credentials', label: 'User & Passwords', icon: UserCheck },
    { id: 'subscription', label: 'Subscription', icon: Zap },
    { id: 'api-sdk', label: 'API & SDK', icon: Terminal },
    { id: 'resellers', label: 'Resellers', icon: Users },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  const handleNavigateToKeysWithApp = (appId: string) => {
    setSelectedAppForKeys(appId);
    setActiveTab('license-keys');
  };

  const isFreePlan = userProfile?.plan === 'FREE';

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col antialiased">
      {/* Top Navbar */}
      <header className="h-16 border-b border-white/10 bg-[#0c0c0c]/90 backdrop-blur-md sticky top-0 z-40 px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 rounded-lg text-[#888888] hover:text-white lg:hidden hover:bg-white/5"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <SpidyLogo size="md" />
        </div>

        {/* Live Quota Badge & Admin Link & User Avatar */}
        <div className="flex items-center gap-3">
          {/* Live Quota Pill (Part 4) */}
          <div className="hidden md:flex items-center gap-2 bg-[#141414] border border-white/5 px-3 py-1.5 rounded-lg text-xs font-mono">
            <span className="text-[#888888]">Plan:</span>
            <span className={isFreePlan ? 'text-white font-bold' : 'text-[#FF2020] font-bold'}>
              {userProfile?.plan || 'FREE'}
            </span>
            <span className="text-[#444444]">|</span>
            <span className="text-[#888888]">
              Quota:{' '}
              <strong className="text-white">
                {userProfile?.keysUsed || 0} / {isFreePlan ? 50 : '∞'}
              </strong>
            </span>
          </div>

          {/* ADMIN PANEL BUTTON - STRICTLY ONLY SHOWN IF THE LOGGED-IN USER IS AN ADMIN */}
          {(isAdmin || isSuperAdmin) && (
            <button
              onClick={() => setViewMode('admin')}
              className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-white bg-[#FF2020] hover:bg-[#ff3838] px-3.5 py-1.5 rounded-lg shadow-[0_0_15px_rgba(255,32,32,0.4)] transition-all cursor-pointer animate-in fade-in"
              title="Open Master Admin Panel"
            >
              <ShieldCheck size={14} className="text-white" />
              <span>ADMIN PANEL</span>
            </button>
          )}

          {/* User Profile Tag */}
          <div className="flex items-center gap-2 pl-2 border-l border-white/10">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FF2020] to-[#880000] flex items-center justify-center text-xs font-bold font-mono">
              {userProfile?.displayName?.charAt(0).toUpperCase() || 'U'}
            </div>
            <button
              onClick={() => logout()}
              className="p-1.5 rounded-lg text-[#888888] hover:text-red-400 hover:bg-white/5 transition-colors cursor-pointer"
              title="Sign Out"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Desktop Sidebar (Part 6) */}
        <aside className="w-64 border-r border-white/10 bg-[#090909] p-4 hidden lg:flex flex-col justify-between shrink-0">
          <div className="space-y-1">
            {/* STRICTLY ONLY SHOWN IN SIDEBAR IF LOGGED IN AS ADMIN */}
            {(isAdmin || isSuperAdmin) && (
              <div className="mb-4 pb-3 border-b border-white/10">
                <button
                  onClick={() => setViewMode('admin')}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-[#FF2020]/15 hover:bg-[#FF2020]/25 border border-[#FF2020]/40 text-white font-mono text-xs font-bold transition-all shadow-[0_0_12px_rgba(255,32,32,0.2)] cursor-pointer group"
                >
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={16} className="text-[#FF2020] group-hover:scale-110 transition-transform" />
                    <span>Admin Console</span>
                  </div>
                  <span className="text-[10px] bg-[#FF2020] text-white px-1.5 py-0.5 rounded font-bold">
                    ENTER
                  </span>
                </button>
              </div>
            )}

            <div className="px-3 py-2 text-[11px] font-mono text-[#666666] uppercase tracking-wider">
              Developer Navigation
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-mono font-medium transition-all ${
                    isActive
                      ? 'bg-[#FF2020]/15 text-[#FF2020] border border-[#FF2020]/30 shadow-[0_0_15px_rgba(255,32,32,0.15)] font-bold'
                      : 'text-[#888888] hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <Icon size={16} className={isActive ? 'text-[#FF2020]' : 'text-[#666666]'} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Sidebar bottom card */}
          <div className="p-3.5 rounded-xl bg-[#121212] border border-white/5 font-mono text-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[#888888] text-[11px]">Free Quota</span>
              <span className="text-white font-bold">{remainingKeys} Left</span>
            </div>
            <div className="w-full bg-[#1c1c1c] rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-[#FF2020] h-full rounded-full"
                style={{ width: `${Math.min(100, ((userProfile?.keysUsed || 0) / 50) * 100)}%` }}
              />
            </div>
            {isFreePlan && (
              <button
                onClick={() => setActiveTab('subscription')}
                className="text-[10px] text-[#FF2020] hover:underline mt-2 block"
              >
                Request Unlimited
              </button>
            )}
          </div>
        </aside>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative w-72 bg-[#0d0d0d] border-r border-white/10 p-5 flex flex-col justify-between z-10">
              <div className="space-y-2">
                <div className="flex items-center justify-between pb-4 border-b border-white/10">
                  <SpidyLogo size="sm" />
                  <button onClick={() => setMobileMenuOpen(false)} className="text-[#888888]">
                    <X size={20} />
                  </button>
                </div>

                {/* Mobile Admin button only if admin */}
                {(isAdmin || isSuperAdmin) && (
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        setViewMode('admin');
                        setMobileMenuOpen(false);
                      }}
                      className="w-full py-2.5 px-3 rounded-xl bg-[#FF2020] text-white font-mono text-xs font-bold flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(255,32,32,0.4)]"
                    >
                      <ShieldCheck size={16} />
                      <span>OPEN ADMIN PANEL</span>
                    </button>
                  </div>
                )}

                <div className="pt-4 space-y-1">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-mono transition-all ${
                          isActive
                            ? 'bg-[#FF2020]/15 text-[#FF2020] border border-[#FF2020]/30 font-bold'
                            : 'text-[#888888] hover:text-white'
                        }`}
                      >
                        <Icon size={16} />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <Button variant="danger" size="sm" className="w-full" onClick={() => logout()}>
                <LogOut size={14} />
                <span>Sign Out</span>
              </Button>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'overview' && <Dashboard onNavigate={(tab) => setActiveTab(tab)} />}
          {activeTab === 'applications' && (
            <Applications onNavigateKeysWithApp={handleNavigateToKeysWithApp} />
          )}
          {activeTab === 'license-keys' && (
            <LicenseKeys
              initialAppId={selectedAppForKeys}
              onNavigateSubscription={() => setActiveTab('subscription')}
            />
          )}
          {activeTab === 'credentials' && <CredentialsManagement />}
          {activeTab === 'subscription' && <Subscription />}
          {activeTab === 'api-sdk' && <ApiSdkDocs />}
          {activeTab === 'resellers' && <Resellers />}
          {activeTab === 'settings' && <Settings />}
        </main>
      </div>
    </div>
  );
};
