import React from 'react';
import { SpidyLogo } from '../shared/Components/SpidyLogo';
import { Button, Badge } from '../shared/Components/CommonUI';
import {
  ShieldCheck,
  KeyRound,
  Cpu,
  Layers,
  Terminal,
  Users,
  CheckCircle2,
  Lock,
  ArrowRight,
  ExternalLink,
  Zap,
} from 'lucide-react';

interface LandingPageProps {
  onLogin: () => void;
  onRegister: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onLogin, onRegister }) => {
  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col cyber-grid relative overflow-hidden">
      {/* Glow mesh in background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[450px] bg-[#FF2020]/15 blur-[140px] pointer-events-none rounded-full" />

      {/* Top Header */}
      <header className="border-b border-white/5 backdrop-blur-md sticky top-0 z-40 bg-[#080808]/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          <SpidyLogo size="md" />

          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onLogin}>
              Sign In
            </Button>
            <Button variant="primary" size="sm" onClick={onRegister}>
              Get Started Free
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 flex flex-col items-center text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#181818] border border-white/10 text-xs font-mono text-[#FF2020] mb-8 neon-glow-sm">
          <span className="w-2 h-2 rounded-full bg-[#FF2020] animate-pulse" />
          <span>CYBER LICENSING &bull; ZERO-TRUST HWID ENFORCEMENT</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight max-w-4xl text-white">
          Fortify Your Software with{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF2020] via-[#ff5555] to-[#B80000] drop-shadow-[0_0_25px_rgba(255,32,32,0.4)]">
            Spidy Auth
          </span>
        </h1>

        <p className="mt-6 text-lg sm:text-xl text-[#999999] max-w-2xl leading-relaxed">
          The next-generation authentication, software licensing, and subscription management SaaS.
          Stop piracy with cryptographic key generation, hardware-ID lock, and granular developer quotas.
        </p>

        {/* Action Buttons */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Button variant="primary" size="lg" onClick={onRegister} className="px-8 font-mono">
            <span>Create Free Account</span>
            <ArrowRight size={18} />
          </Button>
          <Button variant="secondary" size="lg" onClick={onLogin} className="px-8 font-mono">
            <span>Access Developer Console</span>
          </Button>
        </div>

        {/* Free Plan Live Quota Pill */}
        <div className="mt-6 flex items-center gap-2 text-xs font-mono text-[#888888] bg-[#121212] px-4 py-2 rounded-lg border border-white/5">
          <Zap size={14} className="text-[#FF2020]" />
          <span>Automatic Starter Plan: <strong className="text-white">50 Free Lifetime License Keys</strong></span>
        </div>

        {/* Hero Preview Card */}
        <div className="mt-14 w-full max-w-4xl glass-card rounded-2xl p-6 sm:p-8 neon-border shadow-2xl relative overflow-hidden text-left">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/80" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
              <span className="text-xs text-[#666666] font-mono ml-2">spidy-auth-core // engine.cs</span>
            </div>
            <Badge variant="red">PRODUCTION-READY</Badge>
          </div>

          <pre className="font-mono text-xs sm:text-sm text-[#cccccc] overflow-x-auto py-4 leading-relaxed">
            <code>{`// Spidy Auth High-Security Desktop Client Initialization
using SpidyAuth;

var spidy = new SpidyClient(
    appId: "app_c9f28a11bc32e7",
    appSecret: "sec_8840b10e9f1a20",
    version: "2.5.0"
);

// Authenticate user with cryptographically bound hardware ID
var authResult = await spidy.LoginWithLicenseAsync("SPIDY-99X4-KQ18-A702-Z59L");

if (authResult.Success) {
    Console.WriteLine($"[+] Access Granted: {authResult.License.Status} (Expires in {authResult.License.DurationDays} days)");
    Console.WriteLine($"[+] HWID Bound: {authResult.License.Hwid}");
} else {
    Console.WriteLine($"[-] Authentication Blocked: {authResult.Error}");
}`}</code>
          </pre>
        </div>

        {/* Feature Grid */}
        <div className="mt-24 w-full grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          <div className="glass-card glass-card-hover rounded-xl p-6 relative">
            <div className="w-12 h-12 rounded-lg bg-[#FF2020]/10 border border-[#FF2020]/20 text-[#FF2020] flex items-center justify-center mb-4">
              <KeyRound size={24} />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Cryptographic Licensing</h3>
            <p className="text-sm text-[#888888]">
              Generate single keys or username & password accounts. Configure custom durations from 1 day to permanent lifetime.
            </p>
          </div>

          <div className="glass-card glass-card-hover rounded-xl p-6 relative">
            <div className="w-12 h-12 rounded-lg bg-[#FF2020]/10 border border-[#FF2020]/20 text-[#FF2020] flex items-center justify-center mb-4">
              <Cpu size={24} />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Zero-Trust HWID Lock</h3>
            <p className="text-sm text-[#888888]">
              Prevent key sharing and license piracy. Hardware IDs are bound instantly on first activation with one-click admin reset.
            </p>
          </div>

          <div className="glass-card glass-card-hover rounded-xl p-6 relative">
            <div className="w-12 h-12 rounded-lg bg-[#FF2020]/10 border border-[#FF2020]/20 text-[#FF2020] flex items-center justify-center mb-4">
              <ShieldCheck size={24} />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Admin Email Allowlist</h3>
            <p className="text-sm text-[#888888]">
              Strict backend verification. Premium tiers cannot be tampered with on client side; access is governed by verified administrator approvals.
            </p>
          </div>

          <div className="glass-card glass-card-hover rounded-xl p-6 relative">
            <div className="w-12 h-12 rounded-lg bg-[#FF2020]/10 border border-[#FF2020]/20 text-[#FF2020] flex items-center justify-center mb-4">
              <Layers size={24} />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Multi-Application Control</h3>
            <p className="text-sm text-[#888888]">
              Manage dozens of independent software products with isolated license databases, version tracking, and application secrets.
            </p>
          </div>

          <div className="glass-card glass-card-hover rounded-xl p-6 relative">
            <div className="w-12 h-12 rounded-lg bg-[#FF2020]/10 border border-[#FF2020]/20 text-[#FF2020] flex items-center justify-center mb-4">
              <Users size={24} />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Reseller Architecture</h3>
            <p className="text-sm text-[#888888]">
              Appoint distributors and resellers for specific applications with generation quotas, permission controls, and activity logs.
            </p>
          </div>

          <div className="glass-card glass-card-hover rounded-xl p-6 relative">
            <div className="w-12 h-12 rounded-lg bg-[#FF2020]/10 border border-[#FF2020]/20 text-[#FF2020] flex items-center justify-center mb-4">
              <Terminal size={24} />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">REST API & SDKs</h3>
            <p className="text-sm text-[#888888]">
              Plug-and-play integrations for C#, C++, Python, and JavaScript. Tested high-speed endpoints for instant software validation.
            </p>
          </div>
        </div>

        {/* Pricing & Free Quota breakdown */}
        <div className="mt-24 w-full max-w-4xl">
          <h2 className="text-3xl font-extrabold text-white mb-4">Transparent Software Tiers</h2>
          <p className="text-sm text-[#888888] mb-12">Every developer gets 50 free license keys on signup. Upgrade to Premium for unconstrained scale.</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
            {/* Free Tier */}
            <div className="glass-card rounded-2xl p-8 border border-white/10 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-white">Starter Free</h3>
                  <Badge variant="gray">AUTOMATIC</Badge>
                </div>
                <div className="text-4xl font-extrabold font-mono text-white mb-6">
                  $0 <span className="text-xs text-[#888888] font-normal">/ lifetime</span>
                </div>
                <ul className="space-y-3 text-sm text-[#bbbbbb]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>50 Generated License Keys Limit</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>Full HWID Locking & Reset</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>Multi-Application Management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>Standard REST API Access</span>
                  </li>
                  <li className="flex items-center gap-2 text-[#666666]">
                    <Lock size={16} />
                    <span>Unlimited Quota (Requires Premium)</span>
                  </li>
                </ul>
              </div>

              <Button variant="secondary" className="w-full mt-8" onClick={onRegister}>
                Start Free (50 Keys)
              </Button>
            </div>

            {/* Premium Tier */}
            <div className="glass-card rounded-2xl p-8 border border-[#FF2020]/40 neon-glow-red flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-4 right-4">
                <Badge variant="red">ADMIN APPROVED</Badge>
              </div>
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <span>Premium Scale</span>
                  </h3>
                </div>
                <div className="text-4xl font-extrabold font-mono text-[#FF2020] mb-6">
                  Custom <span className="text-xs text-[#888888] font-normal">/ verified access</span>
                </div>
                <ul className="space-y-3 text-sm text-[#bbbbbb]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span className="font-semibold text-white">Unlimited License Key Generation</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>Advanced Reseller System</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>High-Frequency Dedicated API</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>Custom Expiration Timers & Whitelists</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-[#FF2020]" />
                    <span>Priority Cybersecurity Engineering Support</span>
                  </li>
                </ul>
              </div>

              <Button variant="primary" className="w-full mt-8" onClick={onLogin}>
                Submit Upgrade Request
              </Button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 bg-[#060606] text-xs text-[#666666] text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <SpidyLogo size="sm" />
          <p>&copy; {new Date().getFullYear()} SPIDY AUTH. All rights reserved. Zero-Trust Software Authentication.</p>
          <div className="flex items-center gap-4">
            <span className="text-[#888888]">Enterprise Security Shield Active</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
