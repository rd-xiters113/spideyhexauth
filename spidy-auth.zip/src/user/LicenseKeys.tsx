import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  generateLicenseKey,
  getLicenseKeys,
  getApplications,
  updateLicenseStatus,
  resetLicenseHwid,
  deleteLicenseKey,
  registerCredentialWithKey,
} from '../shared/DatabaseService';
import { ApplicationItem, LicenseKeyItem, CredentialItem } from '../shared/Types';
import { Button, Modal, Badge } from '../shared/Components/CommonUI';
import {
  KeyRound,
  Plus,
  Search,
  Filter,
  Copy,
  Check,
  RotateCcw,
  Ban,
  Trash2,
  AlertTriangle,
  Zap,
  Cpu,
  Clock,
  ArrowRight,
  UserPlus,
  UserCheck,
  ShieldAlert,
} from 'lucide-react';

interface LicenseKeysProps {
  initialAppId?: string;
  onNavigateSubscription: () => void;
}

export const LicenseKeys: React.FC<LicenseKeysProps> = ({
  initialAppId,
  onNavigateSubscription,
}) => {
  const { currentUser, userProfile, remainingKeys, refreshProfile } = useAuth();
  const [keys, setKeys] = useState<LicenseKeyItem[]>([]);
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter & Search
  const [selectedAppId, setSelectedAppId] = useState<string>(initialAppId || 'ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  // Generate Key Modal
  const [generateModalOpen, setGenerateModalOpen] = useState(false);
  const [targetAppId, setTargetAppId] = useState('');
  const [licenseType, setLicenseType] = useState<'key' | 'credentials'>('key');
  const [durationPreset, setDurationPreset] = useState<string>('30');
  const [customDays, setCustomDays] = useState<number>(30);
  const [maxDevices, setMaxDevices] = useState(1);
  const [notes, setNotes] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedKeyResult, setGeneratedKeyResult] = useState<LicenseKeyItem | null>(null);

  // Register User Account from Key Modal
  const [registerModalOpen, setRegisterModalOpen] = useState(false);
  const [regKeyTarget, setRegKeyTarget] = useState<LicenseKeyItem | null>(null);
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regSubmitting, setRegSubmitting] = useState(false);
  const [regError, setRegError] = useState<string | null>(null);
  const [regSuccessCred, setRegSuccessCred] = useState<CredentialItem | null>(null);

  // Action states
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);

  const isFreePlan = userProfile?.plan === 'FREE';
  const isQuotaExceeded = isFreePlan && (userProfile?.keysUsed || 0) >= 50;

  useEffect(() => {
    loadData();
  }, [currentUser]);

  useEffect(() => {
    if (initialAppId) {
      setSelectedAppId(initialAppId);
      setTargetAppId(initialAppId);
    }
  }, [initialAppId]);

  const loadData = async () => {
    if (!currentUser) return;
    try {
      setLoading(true);
      const [userApps, userKeys] = await Promise.all([
        getApplications(currentUser.uid),
        getLicenseKeys(currentUser.uid),
      ]);
      setApps(userApps);
      setKeys(userKeys);
      if (userApps.length > 0 && !targetAppId) {
        setTargetAppId(userApps[0].id);
      }
    } catch (err: any) {
      console.error('Failed to load license keys:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!targetAppId) {
      setError('Please select an application to generate a key for.');
      return;
    }

    if (isQuotaExceeded) {
      setError('You have reached your Free Plan key generation limit. Upgrade to Premium to access additional features.');
      return;
    }

    setError(null);
    setSubmitting(true);

    try {
      let days = parseInt(durationPreset, 10);
      if (durationPreset === 'custom') {
        days = customDays;
      }

      const targetApp = apps.find((a) => a.id === targetAppId);

      const created = await generateLicenseKey({
        ownerId: currentUser.uid,
        ownerEmail: currentUser.email || '',
        appId: targetAppId,
        appName: targetApp?.name,
        type: licenseType,
        durationDays: days,
        maxDevices,
        notes,
        username: licenseType === 'credentials' ? username : undefined,
        password: licenseType === 'credentials' ? password : undefined,
      });

      setGeneratedKeyResult(created);
      await refreshProfile();
      await loadData();
    } catch (err: any) {
      setError(err.message || 'Key generation failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetHwid = async (keyId: string) => {
    if (!currentUser) return;
    if (!confirm('Reset hardware locking (HWID) for this key?')) return;
    try {
      await resetLicenseHwid(keyId, currentUser.uid, currentUser.email || '');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to reset HWID');
    }
  };

  const handleBanKey = async (keyId: string) => {
    if (!currentUser) return;
    const reason = prompt('Enter reason for banning this key:', 'Unauthorized redistribution');
    if (reason === null) return;
    try {
      await updateLicenseStatus(keyId, 'banned', currentUser.uid, currentUser.email || '', reason);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to ban key');
    }
  };

  const handleDelete = async (keyId: string) => {
    if (!currentUser) return;
    if (!confirm('Delete this key? NOTE: Deleting an existing key will NOT restore your used quota.')) return;
    try {
      await deleteLicenseKey(keyId, currentUser.uid, currentUser.email || '');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete key');
    }
  };

  const openRegisterModal = (item: LicenseKeyItem) => {
    setRegKeyTarget(item);
    setRegUsername('');
    setRegPassword('');
    setRegError(null);
    setRegSuccessCred(null);
    setRegisterModalOpen(true);
  };

  const handleRegisterUserFromKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !regKeyTarget) return;

    setRegError(null);
    setRegSubmitting(true);
    try {
      const cred = await registerCredentialWithKey({
        ownerId: currentUser.uid,
        ownerEmail: currentUser.email || '',
        appId: regKeyTarget.appId,
        keyCode: regKeyTarget.key,
        username: regUsername.trim(),
        passwordPlain: regPassword,
      });

      setRegSuccessCred(cred);
      await loadData();
    } catch (err: any) {
      setRegError(err.message || 'Failed to register account with license key');
    } finally {
      setRegSubmitting(false);
    }
  };

  const copyKeyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(id);
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  // Filter keys
  const filteredKeys = keys.filter((item) => {
    if (selectedAppId !== 'ALL' && item.appId !== selectedAppId) return false;
    if (statusFilter !== 'ALL' && item.status !== statusFilter) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchKey = item.key.toLowerCase().includes(term);
      const matchApp = item.appName?.toLowerCase().includes(term);
      const matchNotes = item.notes?.toLowerCase().includes(term);
      const matchHwid = item.hwid?.toLowerCase().includes(term);
      if (!matchKey && !matchApp && !matchNotes && !matchHwid) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <KeyRound className="text-[#FF2020]" />
            <span>License Keys</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Generate, bind HWID hardware fingerprints, ban fraudulent keys, and track activations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="primary"
            size="md"
            onClick={() => {
              setGeneratedKeyResult(null);
              setError(null);
              setGenerateModalOpen(true);
            }}
            disabled={apps.length === 0}
          >
            <Plus size={16} />
            <span>Create License Key</span>
          </Button>
        </div>
      </div>

      {/* Quota Counter Card */}
      <div className="glass-card rounded-xl p-4 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#FF2020]/10 border border-[#FF2020]/20 text-[#FF2020]">
            <Zap size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-[#888888] uppercase">Generation Quota</span>
              {isFreePlan ? <Badge variant="gray">FREE PLAN</Badge> : <Badge variant="red">PREMIUM UNLIMITED</Badge>}
            </div>
            <div className="text-sm font-mono text-white mt-0.5">
              Used: <strong className="text-white">{userProfile?.keysUsed || 0}</strong>
              {isFreePlan ? ` / 50 keys` : ' (Unlimited)'}
              {isFreePlan && (
                <span className="ml-3 text-xs text-[#888888]">
                  Remaining:{' '}
                  <strong className={remainingKeys > 5 ? 'text-emerald-400' : 'text-[#FF2020]'}>
                    {remainingKeys}
                  </strong>
                </span>
              )}
            </div>
          </div>
        </div>

        {isQuotaExceeded && (
          <Button variant="primary" size="sm" onClick={onNavigateSubscription}>
            <span>Limit Reached - Upgrade</span>
            <ArrowRight size={14} />
          </Button>
        )}
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-2.5 text-[#666666]" size={16} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search key, HWID, notes..."
            className="w-full bg-[#111111] border border-white/10 rounded-lg py-2 pl-9 pr-4 text-xs text-white placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
          />
        </div>

        {/* Filter dropdowns */}
        <div className="flex items-center gap-3">
          {/* App filter */}
          <select
            value={selectedAppId}
            onChange={(e) => setSelectedAppId(e.target.value)}
            className="bg-[#111111] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-[#FF2020] font-mono"
          >
            <option value="ALL">All Applications</option>
            {apps.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#111111] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-[#FF2020] font-mono"
          >
            <option value="ALL">All Statuses</option>
            <option value="unused">Unused</option>
            <option value="active">Active</option>
            <option value="expired">Expired</option>
            <option value="banned">Banned</option>
          </select>
        </div>
      </div>

      {/* Keys Table */}
      {loading ? (
        <div className="text-center py-20 text-xs text-[#888888] font-mono">
          Loading licenses...
        </div>
      ) : filteredKeys.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10">
          <KeyRound size={32} className="mx-auto text-[#666666] mb-3" />
          <h3 className="text-base font-bold text-white mb-1">No License Keys Found</h3>
          <p className="text-xs text-[#888888]">
            {searchTerm || statusFilter !== 'ALL' || selectedAppId !== 'ALL'
              ? 'Try modifying your search query or filters.'
              : 'Create your first license key above.'}
          </p>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">License Key</th>
                  <th className="py-3.5 px-4">Application</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Duration</th>
                  <th className="py-3.5 px-4">HWID Bound</th>
                  <th className="py-3.5 px-4">Created</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredKeys.map((item) => {
                  const statusColors = {
                    unused: 'amber',
                    active: 'green',
                    expired: 'gray',
                    banned: 'red',
                  };

                  return (
                    <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                      {/* Key */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white select-all">{item.key}</span>
                          <button
                            onClick={() => copyKeyText(item.key, item.id)}
                            className="text-[#888888] hover:text-[#FF2020] transition-colors"
                            title="Copy key"
                          >
                            {copiedKeyId === item.id ? (
                              <Check size={12} className="text-emerald-400" />
                            ) : (
                              <Copy size={12} />
                            )}
                          </button>
                        </div>
                        {item.username && (
                          <div className="mt-1 flex items-center gap-1">
                            <span className="text-[10px] bg-emerald-950/50 border border-emerald-500/30 text-emerald-300 px-1.5 py-0.5 rounded font-mono inline-flex items-center gap-1">
                              <UserCheck size={10} />
                              <span>User: {item.username}</span>
                            </span>
                          </div>
                        )}
                        {item.notes && (
                          <span className="text-[10px] text-[#666666] block truncate max-w-xs font-sans mt-0.5">
                            {item.notes}
                          </span>
                        )}
                      </td>

                      {/* Application */}
                      <td className="py-3 px-4 text-[#cccccc]">
                        {item.appName || item.appId}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        <Badge variant={statusColors[item.status] as any}>
                          {item.status.toUpperCase()}
                        </Badge>
                      </td>

                      {/* Duration */}
                      <td className="py-3 px-4 text-[#aaaaaa]">
                        <span className="font-bold text-white">
                          {item.durationDays === -1 ? 'Lifetime' : `${item.durationDays} Days`}
                        </span>
                        {item.expiresAt ? (
                          <span className="block text-[10px] text-emerald-400 font-mono">
                            Expires: {new Date(item.expiresAt).toLocaleDateString()}
                          </span>
                        ) : (
                          <span className="block text-[10px] text-[#666666] font-mono">
                            Starts on activation
                          </span>
                        )}
                      </td>

                      {/* HWID */}
                      <td className="py-3 px-4">
                        {item.hwid ? (
                          <div className="flex items-center gap-1 text-[#FF2020] text-[11px]">
                            <Cpu size={12} />
                            <span className="truncate max-w-[120px]" title={item.hwid}>
                              {item.hwid}
                            </span>
                          </div>
                        ) : (
                          <span className="text-[#555555]">Unbound</span>
                        )}
                      </td>

                      {/* Created */}
                      <td className="py-3 px-4 text-[#888888]">
                        {new Date(item.createdAt).toLocaleDateString()}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Register User & Pass with this key action */}
                          {!item.username && item.status !== 'banned' && (
                            <button
                              onClick={() => openRegisterModal(item)}
                              className="p-1.5 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-400 hover:text-emerald-300 border border-emerald-500/30 transition-all cursor-pointer"
                              title="Register User & Password with this Key (Inherits exact duration)"
                            >
                              <UserPlus size={13} />
                            </button>
                          )}
                          {item.hwid && (
                            <button
                              onClick={() => handleResetHwid(item.id)}
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#aaaaaa] hover:text-white"
                              title="Reset HWID"
                            >
                              <RotateCcw size={13} />
                            </button>
                          )}
                          {item.status !== 'banned' && (
                            <button
                              onClick={() => handleBanKey(item.id)}
                              className="p-1.5 rounded-lg bg-red-950/30 hover:bg-red-900/40 text-red-400 hover:text-red-300"
                              title="Ban Key"
                            >
                              <Ban size={13} />
                            </button>
                          )}
                          <button
                            onClick={() => handleDelete(item.id)}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-red-900/40 text-[#666666] hover:text-red-400"
                            title="Delete Key (Quota not refunded)"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Generate Key Modal */}
      <Modal
        isOpen={generateModalOpen}
        onClose={() => setGenerateModalOpen(false)}
        title="Generate Software License Key"
      >
        {generatedKeyResult ? (
          <div className="text-center py-4 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-[#FF2020]/15 border border-[#FF2020]/40 text-[#FF2020] flex items-center justify-center mx-auto neon-glow-sm">
              <Check size={28} />
            </div>
            <div>
              <h4 className="text-lg font-bold text-white">License Generated Successfully!</h4>
              <p className="text-xs text-[#888888]">
                This key is active and ready for desktop client activation.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#0a0a0a] border border-[#FF2020]/40 flex items-center justify-between font-mono">
              <span className="text-base text-white font-bold select-all">
                {generatedKeyResult.key}
              </span>
              <Button
                variant="primary"
                size="sm"
                onClick={() => copyKeyText(generatedKeyResult.key, 'modal')}
              >
                {copiedKeyId === 'modal' ? <Check size={14} /> : <Copy size={14} />}
                <span>{copiedKeyId === 'modal' ? 'Copied' : 'Copy Key'}</span>
              </Button>
            </div>

            <div className="text-xs text-[#666666] font-mono text-left space-y-1">
              <div>&bull; Duration: {generatedKeyResult.durationDays === -1 ? 'Lifetime' : `${generatedKeyResult.durationDays} Days`}</div>
              <div>&bull; Max Devices: {generatedKeyResult.maxDevices}</div>
              {generatedKeyResult.username && <div>&bull; Username: {generatedKeyResult.username}</div>}
            </div>

            <Button
              variant="secondary"
              className="w-full mt-4"
              onClick={() => {
                setGeneratedKeyResult(null);
                setGenerateModalOpen(false);
              }}
            >
              Done
            </Button>
          </div>
        ) : (
          <form onSubmit={handleGenerateKey} className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-500/40 text-red-400 text-xs flex items-center gap-2">
                <AlertTriangle size={16} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Application selector */}
            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">
                Target Application *
              </label>
              <select
                required
                value={targetAppId}
                onChange={(e) => setTargetAppId(e.target.value)}
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2.5 px-3 text-sm text-white focus:outline-none focus:border-[#FF2020] font-mono"
              >
                {apps.map((app) => (
                  <option key={app.id} value={app.id}>
                    {app.name} (v{app.version})
                  </option>
                ))}
              </select>
            </div>

            {/* License Type */}
            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">
                License Architecture
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setLicenseType('key')}
                  className={`py-2 px-3 rounded-lg text-xs font-mono font-medium border text-center transition-all ${
                    licenseType === 'key'
                      ? 'bg-[#FF2020]/15 border-[#FF2020] text-white'
                      : 'bg-[#111] border-white/10 text-[#888]'
                  }`}
                >
                  Standard Key
                </button>
                <button
                  type="button"
                  onClick={() => setLicenseType('credentials')}
                  className={`py-2 px-3 rounded-lg text-xs font-mono font-medium border text-center transition-all ${
                    licenseType === 'credentials'
                      ? 'bg-[#FF2020]/15 border-[#FF2020] text-white'
                      : 'bg-[#111] border-white/10 text-[#888]'
                  }`}
                >
                  User + Password
                </button>
              </div>
            </div>

            {/* Duration presets */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-[#aaaaaa]">Duration / Validity</label>
                <span className="text-[11px] font-mono text-[#FF2020]">
                  {durationPreset === '-1'
                    ? 'Permanent Lifetime'
                    : durationPreset === 'custom'
                    ? `${customDays} Days (Custom)`
                    : `${durationPreset} Days`}
                </span>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
                {[
                  { label: '1 Day', val: '1' },
                  { label: '3 Days', val: '3' },
                  { label: '7 Days', val: '7' },
                  { label: '15 Days', val: '15' },
                  { label: '30 Days', val: '30' },
                  { label: '60 Days', val: '60' },
                  { label: '90 Days', val: '90' },
                  { label: '180 Days', val: '180' },
                  { label: '365 Days', val: '365' },
                  { label: 'Lifetime', val: '-1' },
                  { label: 'Custom', val: 'custom' },
                ].map((item) => (
                  <button
                    type="button"
                    key={item.val}
                    onClick={() => setDurationPreset(item.val)}
                    className={`py-1.5 px-1 rounded-lg text-xs font-mono border transition-all text-center ${
                      durationPreset === item.val
                        ? 'bg-[#FF2020] text-white border-[#FF2020] shadow-[0_0_8px_rgba(255,32,32,0.4)]'
                        : 'bg-[#111] text-[#888] border-white/10 hover:text-white hover:border-white/20'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {durationPreset === 'custom' && (
                <div className="mt-2.5">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={3650}
                      value={customDays}
                      onChange={(e) => setCustomDays(Math.max(1, parseInt(e.target.value) || 1))}
                      placeholder="Enter custom days (e.g. 45)"
                      className="w-full bg-[#0a0a0a] border border-[#FF2020]/60 rounded-lg py-2 px-3 text-sm text-white font-mono focus:outline-none focus:border-[#FF2020]"
                    />
                    <span className="text-xs text-[#888888] font-mono shrink-0">Days</span>
                  </div>
                </div>
              )}

              {/* Exact Duration Inheritance Guarantee Box */}
              <div className="mt-2 p-2.5 rounded-lg bg-[#0e0e0e] border border-white/10 text-[11px] font-mono text-[#aaaaaa] flex items-start gap-2">
                <Clock size={14} className="text-[#FF2020] shrink-0 mt-0.5" />
                <div>
                  <span className="text-white font-semibold">Duration Guarantee: </span>
                  {durationPreset === '-1' ? (
                    <span>Any client account (Username & Password) registered using this key will receive <strong className="text-[#00ff88]">Lifetime Access</strong>.</span>
                  ) : (
                    <span>Any client account (Username & Password) registered using this key will automatically inherit exactly <strong className="text-[#00ff88]">{durationPreset === 'custom' ? customDays : durationPreset} Days</strong> validity starting from their registration date.</span>
                  )}
                </div>
              </div>
            </div>

            {/* Credentials Fields if applicable */}
            {licenseType === 'credentials' && (
              <div className="space-y-3 p-3 rounded-xl bg-[#141414] border border-white/5">
                <div>
                  <label className="block text-[11px] font-mono text-[#aaaaaa] mb-1">
                    Preset Username (Optional)
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="client_username"
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2 px-3 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-[#aaaaaa] mb-1">
                    Preset Password (Optional)
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="client_password"
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2 px-3 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
                  />
                </div>
              </div>
            )}

            {/* Max Devices & Notes */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">
                  Device Limit (HWID)
                </label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={maxDevices}
                  onChange={(e) => setMaxDevices(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2 px-3 text-sm text-white font-mono focus:outline-none focus:border-[#FF2020]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">
                  Internal Notes
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. VIP Customer, Discord #001"
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2 px-3 text-sm text-white focus:outline-none focus:border-[#FF2020]"
                />
              </div>
            </div>

            <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setGenerateModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                variant="primary"
                size="sm"
                isLoading={submitting}
                disabled={isQuotaExceeded}
              >
                {isQuotaExceeded ? 'Quota Exceeded' : 'Generate Key'}
              </Button>
            </div>
          </form>
        )}
      </Modal>

      {/* Modal: Register User & Password Account from License Key */}
      <Modal
        isOpen={registerModalOpen}
        onClose={() => {
          setRegisterModalOpen(false);
          setRegKeyTarget(null);
          setRegSuccessCred(null);
        }}
        title="Register User & Password with License Key"
      >
        {regSuccessCred ? (
          <div className="text-center py-4 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(16,185,129,0.3)]">
              <Check size={28} />
            </div>
            <div>
              <h4 className="text-lg font-bold text-white">Client Account Registered!</h4>
              <p className="text-xs text-[#888888] mt-1">
                This user account has been successfully created and linked to the license key.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#0e0e0e] border border-emerald-500/30 text-left font-mono space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-[#888888]">Username:</span>
                <span className="text-white font-bold">{regSuccessCred.username}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#888888]">License Key:</span>
                <span className="text-emerald-400 font-bold">{regKeyTarget?.key}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#888888]">Inherited Duration:</span>
                <span className="text-white">
                  {regSuccessCred.durationDays === -1 ? 'Lifetime' : `${regSuccessCred.durationDays} Days`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#888888]">Account Expiration:</span>
                <span className="text-emerald-300 font-bold">
                  {regSuccessCred.expiresAt
                    ? new Date(regSuccessCred.expiresAt).toLocaleDateString() + ' ' + new Date(regSuccessCred.expiresAt).toLocaleTimeString()
                    : 'Permanent (Never)'}
                </span>
              </div>
            </div>

            <Button
              variant="secondary"
              className="w-full mt-3"
              onClick={() => {
                setRegisterModalOpen(false);
                setRegKeyTarget(null);
                setRegSuccessCred(null);
              }}
            >
              Done
            </Button>
          </div>
        ) : (
          <form onSubmit={handleRegisterUserFromKey} className="space-y-4">
            {regError && (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-500/40 text-red-400 text-xs flex items-center gap-2">
                <AlertTriangle size={16} className="shrink-0" />
                <span>{regError}</span>
              </div>
            )}

            {/* Target Key Info Card with Exact Inherited Duration Highlight */}
            {regKeyTarget && (
              <div className="p-3.5 rounded-xl bg-[#0a0a0a] border border-[#FF2020]/40 font-mono space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#888888]">License Key:</span>
                  <span className="text-white font-bold select-all">{regKeyTarget.key}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#888888]">Application:</span>
                  <span className="text-[#aaaaaa]">{regKeyTarget.appName || regKeyTarget.appId}</span>
                </div>
                <div className="flex items-center justify-between text-xs pt-1.5 border-t border-white/10">
                  <span className="text-[#888888]">Key Configured Duration:</span>
                  <span className="text-[#00ff88] font-bold">
                    {regKeyTarget.durationDays === -1 ? 'Lifetime Access' : `${regKeyTarget.durationDays} Days`}
                  </span>
                </div>
                <p className="text-[11px] text-[#aaaaaa] pt-1">
                  Upon registration, this account will automatically be granted exactly{' '}
                  <strong className="text-white">
                    {regKeyTarget.durationDays === -1 ? 'Lifetime' : `${regKeyTarget.durationDays} Days`}
                  </strong>{' '}
                  of access starting today.
                </p>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5 font-mono">
                Desired Username *
              </label>
              <input
                type="text"
                required
                value={regUsername}
                onChange={(e) => setRegUsername(e.target.value)}
                placeholder="e.g. customer_john"
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2.5 px-3 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5 font-mono">
                Account Password *
              </label>
              <input
                type="password"
                required
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2.5 px-3 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
              />
            </div>

            <div className="pt-3 flex items-center justify-end gap-3 border-t border-white/10">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setRegisterModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                variant="primary"
                size="sm"
                isLoading={regSubmitting}
              >
                <UserCheck size={14} />
                <span>Register with Key Duration</span>
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
