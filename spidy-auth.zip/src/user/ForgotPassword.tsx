import React, { useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import { SpidyLogo } from '../shared/Components/SpidyLogo';
import { Button } from '../shared/Components/CommonUI';
import { Mail, AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';

interface ForgotPasswordProps {
  onBackToLogin: () => void;
}

export const ForgotPassword: React.FC<ForgotPasswordProps> = ({ onBackToLogin }) => {
  const { resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await resetPassword(email.trim());
      setSuccess(true);
    } catch (err: any) {
      setError(err.message?.replace('Firebase: ', '') || 'Failed to send reset link');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080808] flex items-center justify-center p-4 cyber-grid relative">
      <div className="w-full max-w-md glass-card rounded-2xl p-8 border border-white/10 shadow-2xl relative z-10">
        <button
          onClick={onBackToLogin}
          className="inline-flex items-center gap-1.5 text-xs text-[#888888] hover:text-white transition-colors mb-6 font-mono"
        >
          <ArrowLeft size={14} />
          <span>Back to Sign In</span>
        </button>

        <div className="flex flex-col items-center text-center mb-6">
          <SpidyLogo size="lg" />
          <h2 className="text-2xl font-extrabold text-white mt-4 tracking-tight">Reset Password</h2>
          <p className="text-xs text-[#888888] mt-1">Enter your email to receive recovery instructions</p>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-lg bg-red-950/40 border border-red-500/40 text-red-400 text-xs flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success ? (
          <div className="text-center py-6">
            <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 size={24} />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Recovery Email Dispatched</h3>
            <p className="text-xs text-[#999999] mb-6">
              Check your inbox at <span className="text-white font-mono">{email}</span> for the password reset link.
            </p>
            <Button variant="secondary" className="w-full" onClick={onBackToLogin}>
              Return to Sign In
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">Registered Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 text-[#666666]" size={16} />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="developer@example.com"
                  className="w-full bg-[#111111] border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-sm text-white placeholder-[#555555] focus:outline-none focus:border-[#FF2020] transition-colors"
                />
              </div>
            </div>

            <Button type="submit" variant="primary" className="w-full py-2.5 mt-2" isLoading={loading}>
              Send Reset Instructions
            </Button>
          </form>
        )}
      </div>
    </div>
  );
};
