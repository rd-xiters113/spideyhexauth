import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  createCredential,
  getCredentials,
  revokeCredential,
  deleteCredential,
  getApplications,
  getLicenseKeys,
  registerCredentialWithKey,
  lookupLicenseKeyForRegistration,
} from '../shared/DatabaseService';
import { ApplicationItem, CredentialItem, LicenseKeyItem } from '../shared/Types';
import { Button, Modal, Badge } from '../shared/Components/CommonUI';
import {
  UserCheck,
  Plus,
  Trash2,
  Ban,
  Clock,
  Key,
  Cpu,
  RotateCcw,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

export const CredentialsManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const [credentials, setCredentials] = useState<CredentialItem[]>([]);
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [availableKeys, setAvailableKeys] = useState<LicenseKeyItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Create Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [creationMode, setCreationMode] = useState<'key' | 'manual'>('key');
  const [selectedAppId, setSelectedAppId] = useState('');
  
  // Registration via License Key
  const [inputKey, setInputKey] = useState('');
  const [keyLookupResult, setKeyLookupResult] = useState<{
    valid: boolean;
    message?: string;
    keyData?: LicenseKeyItem;
    durationDays?: number;
    isLifetime?: boolean;
  } | null>(null);

  // Common credentials fields
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [manualDurationDays, setManualDurationDays] = useState(30);
  const [deviceLimit, setDeviceLimit] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const loadData = async () => {
    if (!currentUser) return;
    try {
      setLoading(true);
      const [userApps, userCreds, userKeys] = await Promise.all([
        getApplications(currentUser.uid),
        getCredentials(currentUser.uid),
        getLicenseKeys(currentUser.uid),
      ]);
      setApps(userApps);
      setCredentials(userCreds);
      setAvailableKeys(userKeys.filter((k) => k.status === 'unused' || (!k.username && k.status !== 'banned')));
      if (userApps.length > 0 && !selectedAppId) {
        setSelectedAppId(userApps[0].id);
      }
    } catch (err: any) {
      console.error('Failed to load credentials:', err);
    } finally {
      setLoading(false);
    }
  };

  // When app or inputKey changes, do a lookup
  useEffect(() => {
    if (creationMode === 'key' && selectedAppId && inputKey.trim()) {
      const timer = setTimeout(async () => {
        const res = await lookupLicenseKeyForRegistration(selectedAppId, inputKey.trim());
        setKeyLookupResult(res);
      }, 300);
      return () => clearTimeout(timer);
    } else {
      setKeyLookupResult(null);
    }
  }, [creationMode, selectedAppId, inputKey]);

  const handleSelectPreexistingKey = (keyCode: string) => {
    setInputKey(keyCode);
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!selectedAppId) {
      setError('Please select an application');
      return;
    }

    setError(null);
    setSubmitting(true);

    try {
      if (creationMode === 'key') {
        if (!inputKey.trim()) {
          throw new Error('Please enter or select a valid license key');
        }
        await registerCredentialWithKey({
          ownerId: currentUser.uid,
          ownerEmail: currentUser.email || '',
          appId: selectedAppId,
          keyCode: inputKey.trim(),
          username: username.trim(),
          passwordPlain: password,
        });
      } else {
        await createCredential(
          currentUser.uid,
          currentUser.email || '',
          selectedAppId,
          username.trim(),
          password,
          manualDurationDays,
          deviceLimit
        );
      }

      setUsername('');
      setPassword('');
      setInputKey('');
      setKeyLookupResult(null);
      setModalOpen(false);
      await loadData();
    } catch (err: any) {
      setError(err.message || 'Failed to create credential account');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRevoke = async (id: string) => {
    if (!currentUser) return;
    if (!confirm('Suspend this client user account?')) return;
    try {
      await revokeCredential(id, currentUser.uid, currentUser.email || '');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to revoke');
    }
  };

  const handleDelete = async (id: string) => {
    if (!currentUser) return;
    if (!confirm('Permanently delete this user credential?')) return;
    try {
      await deleteCredential(id, currentUser.uid, currentUser.email || '');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete');
    }
  };

  // Filter keys for selected application
  const appAvailableKeys = availableKeys.filter((k) => k.appId === selectedAppId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <UserCheck className="text-[#FF2020]" />
            <span>Application Client Credentials</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Create username & password accounts for client desktop software. Accounts registered via license keys inherit the exact key duration.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="primary"
            size="md"
            onClick={() => {
              setError(null);
              setCreationMode('key');
              setModalOpen(true);
            }}
            disabled={apps.length === 0}
          >
            <KeyRound size={16} />
            <span>Register with License Key</span>
          </Button>
        </div>
      </div>

      {/* List / Table */}
      {loading ? (
        <div className="text-center py-20 text-xs text-[#888888] font-mono">Loading accounts...</div>
      ) : credentials.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10 max-w-lg mx-auto">
          <UserCheck size={36} className="text-[#666666] mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-1">No Username Credentials Found</h3>
          <p className="text-xs text-[#888888] mb-4">
            Create username & password accounts for end-users who login directly through your client desktop app.
          </p>
          <Button variant="primary" size="sm" onClick={() => setModalOpen(true)} disabled={apps.length === 0}>
            Register Account
          </Button>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Username</th>
                <th className="py-3.5 px-4">Application</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Duration</th>
                <th className="py-3.5 px-4">Expiration</th>
                <th className="py-3.5 px-4">Hardware ID</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {credentials.map((cred) => (
                <tr key={cred.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 font-bold text-white flex items-center gap-1.5">
                    <UserCheck size={14} className="text-emerald-400" />
                    <span>{cred.username}</span>
                  </td>
                  <td className="py-3 px-4 text-[#888888]">{cred.appId}</td>
                  <td className="py-3 px-4">
                    <Badge variant={cred.status === 'active' ? 'green' : 'red'}>
                      {cred.status.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-[#aaaaaa]">
                    {cred.durationDays === -1 ? 'Lifetime' : `${cred.durationDays} Days`}
                  </td>
                  <td className="py-3 px-4">
                    {cred.expiresAt ? (
                      <span className="text-emerald-300 font-mono">
                        {new Date(cred.expiresAt).toLocaleDateString()}
                      </span>
                    ) : (
                      <span className="text-[#888888]">Permanent</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    {cred.currentHwid ? (
                      <span className="text-[#FF2020] truncate max-w-[120px] inline-block">
                        {cred.currentHwid}
                      </span>
                    ) : (
                      <span className="text-[#555555]">Unbound</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {cred.status === 'active' && (
                        <button
                          onClick={() => handleRevoke(cred.id)}
                          className="p-1 rounded bg-red-950/40 text-red-400 hover:text-red-300"
                          title="Suspend Account"
                        >
                          <Ban size={13} />
                        </button>
                      )}
                      <button
                        onClick={() => handleDelete(cred.id)}
                        className="p-1 rounded bg-white/5 text-[#888] hover:text-red-400"
                        title="Delete"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Create / Register Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Register Application Client Account">
        {error && (
          <div className="p-3 mb-4 rounded-lg bg-red-950/40 text-red-400 text-xs border border-red-500/40 flex items-center gap-2">
            <AlertTriangle size={16} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Mode Selector */}
        <div className="grid grid-cols-2 gap-2 mb-4 p-1 rounded-xl bg-[#0e0e0e] border border-white/10">
          <button
            type="button"
            onClick={() => setCreationMode('key')}
            className={`py-2 px-3 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center gap-1.5 ${
              creationMode === 'key'
                ? 'bg-[#FF2020] text-white shadow-[0_0_12px_rgba(255,32,32,0.4)]'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            <KeyRound size={13} />
            <span>Via License Key (Exact Duration)</span>
          </button>
          <button
            type="button"
            onClick={() => setCreationMode('manual')}
            className={`py-2 px-3 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center gap-1.5 ${
              creationMode === 'manual'
                ? 'bg-[#FF2020] text-white shadow-[0_0_12px_rgba(255,32,32,0.4)]'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            <Plus size={13} />
            <span>Manual Direct Account</span>
          </button>
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1 font-mono">Target Application *</label>
            <select
              value={selectedAppId}
              onChange={(e) => setSelectedAppId(e.target.value)}
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
            >
              {apps.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.id})
                </option>
              ))}
            </select>
          </div>

          {/* Key Registration Fields */}
          {creationMode === 'key' && (
            <div className="space-y-3 p-3.5 rounded-xl bg-[#0f0f0f] border border-[#FF2020]/30 font-mono">
              <div>
                <label className="block text-xs font-medium text-[#aaaaaa] mb-1">
                  License Key Code *
                </label>
                <input
                  type="text"
                  required
                  value={inputKey}
                  onChange={(e) => setInputKey(e.target.value)}
                  placeholder="SPIDY-XXXX-XXXX-XXXX"
                  className="w-full bg-[#080808] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
                />
              </div>

              {/* Quick Pick from Unused Keys */}
              {appAvailableKeys.length > 0 && (
                <div>
                  <span className="text-[10px] text-[#666666] block mb-1">Or pick an unredeemed key:</span>
                  <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                    {appAvailableKeys.map((k) => (
                      <button
                        type="button"
                        key={k.id}
                        onClick={() => handleSelectPreexistingKey(k.key)}
                        className={`text-[10px] px-2 py-1 rounded border font-mono transition-all ${
                          inputKey === k.key
                            ? 'bg-[#FF2020]/20 border-[#FF2020] text-white'
                            : 'bg-white/5 border-white/10 text-[#888888] hover:text-white'
                        }`}
                      >
                        {k.key} ({k.durationDays === -1 ? 'Lifetime' : `${k.durationDays}d`})
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Live Duration Inherited Banner */}
              {keyLookupResult && (
                <div
                  className={`p-2.5 rounded-lg border text-xs ${
                    keyLookupResult.valid
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : 'bg-red-950/40 border-red-500/40 text-red-300'
                  }`}
                >
                  {keyLookupResult.valid ? (
                    <div className="space-y-1">
                      <div className="font-bold flex items-center gap-1.5">
                        <CheckCircle2 size={14} className="text-emerald-400" />
                        <span>Valid Key Verified!</span>
                      </div>
                      <div className="text-[11px] text-white">
                        Inherited Duration:{' '}
                        <strong className="text-emerald-400">
                          {keyLookupResult.isLifetime ? 'Lifetime Access' : `${keyLookupResult.durationDays} Days`}
                        </strong>
                      </div>
                      <div className="text-[10px] text-emerald-200/80">
                        The registered user will automatically receive this exact validity starting today.
                      </div>
                    </div>
                  ) : (
                    <span>{keyLookupResult.message}</span>
                  )}
                </div>
              )}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1 font-mono">Desired Username *</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. client_pro_01"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1 font-mono">Account Password *</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
            />
          </div>

          {/* Manual mode duration setting */}
          {creationMode === 'manual' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#aaaaaa] mb-1 font-mono">Duration (Days, -1 for Lifetime)</label>
                <input
                  type="number"
                  min={-1}
                  value={manualDurationDays}
                  onChange={(e) => setManualDurationDays(parseInt(e.target.value) || 30)}
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#aaaaaa] mb-1 font-mono">Device Limit</label>
                <input
                  type="number"
                  min={1}
                  value={deviceLimit}
                  onChange={(e) => setDeviceLimit(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-[#FF2020]"
                />
              </div>
            </div>
          )}

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
            <Button type="button" variant="ghost" size="sm" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
              {creationMode === 'key' ? 'Register with Key Duration' : 'Create Account'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
