import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import { getActivityLogs } from '../shared/DatabaseService';
import { ActivityLogItem } from '../shared/Types';
import { Button, Badge } from '../shared/Components/CommonUI';
import {
  Settings as SettingsIcon,
  Shield,
  Key,
  Mail,
  Copy,
  Check,
  Terminal,
  LogOut,
} from 'lucide-react';

export const Settings: React.FC = () => {
  const { userProfile, currentUser, logout, resendVerificationEmail } = useAuth();
  const [logs, setLogs] = useState<ActivityLogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState(false);
  const [verificationSent, setVerificationSent] = useState(false);

  useEffect(() => {
    if (!currentUser) return;
    getActivityLogs(25, currentUser.uid).then((items) => {
      setLogs(items);
      setLoading(false);
    });
  }, [currentUser]);

  const copyUid = () => {
    if (currentUser?.uid) {
      navigator.clipboard.writeText(currentUser.uid);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleResend = async () => {
    await resendVerificationEmail();
    setVerificationSent(true);
    setTimeout(() => setVerificationSent(false), 4000);
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="pb-4 border-b border-white/10">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <SettingsIcon className="text-[#FF2020]" />
          <span>Developer Account Settings</span>
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Review your security profile, account credentials, and authenticated operation logs.
        </p>
      </div>

      {/* Account Info Card */}
      <div className="glass-card rounded-2xl p-6 border border-white/10 space-y-5">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Shield size={18} className="text-[#FF2020]" />
          <span>Security & Identity</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
          <div className="p-3 rounded-xl bg-[#111111] border border-white/5">
            <span className="text-[#666666] text-[10px] uppercase block mb-1">Developer UID</span>
            <div className="flex items-center justify-between">
              <span className="text-white truncate max-w-[200px]">{currentUser?.uid}</span>
              <button onClick={copyUid} className="text-[#888888] hover:text-white">
                {copiedId ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              </button>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#111111] border border-white/5">
            <span className="text-[#666666] text-[10px] uppercase block mb-1">Registered Email</span>
            <span className="text-white block">{currentUser?.email}</span>
          </div>

          <div className="p-3 rounded-xl bg-[#111111] border border-white/5">
            <span className="text-[#666666] text-[10px] uppercase block mb-1">Email Verification</span>
            <div className="flex items-center justify-between">
              {currentUser?.emailVerified ? (
                <Badge variant="green">VERIFIED</Badge>
              ) : (
                <div className="flex items-center gap-2">
                  <Badge variant="amber">UNVERIFIED</Badge>
                  <button
                    onClick={handleResend}
                    className="text-[11px] text-[#FF2020] hover:underline"
                  >
                    {verificationSent ? 'Sent' : 'Resend Email'}
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#111111] border border-white/5">
            <span className="text-[#666666] text-[10px] uppercase block mb-1">Subscription Tier</span>
            <div className="flex items-center gap-2">
              <span className="text-white font-bold">{userProfile?.plan || 'FREE'}</span>
              <span className="text-[#888888]">({userProfile?.keysUsed || 0} keys generated)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Account Audit Stream */}
      <div className="glass-card rounded-2xl p-6 border border-white/10">
        <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
          <Terminal size={18} className="text-[#FF2020]" />
          <span>Security Audit Trail</span>
        </h3>

        {loading ? (
          <div className="text-center py-6 text-xs text-[#888888] font-mono">Loading telemetry...</div>
        ) : logs.length === 0 ? (
          <p className="text-xs text-[#666666] py-6 text-center font-mono">No security events recorded yet.</p>
        ) : (
          <div className="divide-y divide-white/5 font-mono text-xs">
            {logs.map((log) => (
              <div key={log.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <span className="text-white font-semibold">{log.action}</span>
                  <span className="text-[#888888] text-[11px] ml-2 font-sans">{log.details}</span>
                </div>
                <span className="text-[10px] text-[#555555]">
                  {new Date(log.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Logout Action */}
      <div className="pt-4 flex items-center justify-between">
        <span className="text-xs text-[#666666]">End authenticated session on this browser</span>
        <Button variant="danger" size="sm" onClick={() => logout()}>
          <LogOut size={14} />
          <span>Sign Out</span>
        </Button>
      </div>
    </div>
  );
};
