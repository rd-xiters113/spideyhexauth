import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  createReseller,
  getResellers,
  getApplications,
} from '../shared/DatabaseService';
import { ApplicationItem, ResellerItem } from '../shared/Types';
import { Button, Modal, Badge } from '../shared/Components/CommonUI';
import { Users, Plus, Shield, KeyRound, AlertCircle } from 'lucide-react';

export const Resellers: React.FC = () => {
  const { currentUser } = useAuth();
  const [resellers, setResellers] = useState<ResellerItem[]>([]);
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedAppId, setSelectedAppId] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [quota, setQuota] = useState(50);
  const [permissions, setPermissions] = useState('GENERATE_KEYS,VIEW_KEYS');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const loadData = async () => {
    if (!currentUser) return;
    try {
      setLoading(true);
      const [userApps, userResellers] = await Promise.all([
        getApplications(currentUser.uid),
        getResellers(currentUser.uid),
      ]);
      setApps(userApps);
      setResellers(userResellers);
      if (userApps.length > 0 && !selectedAppId) {
        setSelectedAppId(userApps[0].id);
      }
    } catch (e) {
      console.warn('Error loading resellers:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!selectedAppId) {
      setError('Select an application');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await createReseller(
        currentUser.uid,
        currentUser.email || '',
        selectedAppId,
        username.trim(),
        email.trim(),
        quota,
        permissions
      );
      setUsername('');
      setEmail('');
      setModalOpen(false);
      await loadData();
    } catch (err: any) {
      setError(err.message || 'Failed to create reseller');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Users className="text-[#FF2020]" />
            <span>Authorized Software Resellers</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Delegate license generation to third-party distributors restricted strictly to your software.
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          onClick={() => {
            setError(null);
            setModalOpen(true);
          }}
          disabled={apps.length === 0}
        >
          <Plus size={16} />
          <span>Appoint Reseller</span>
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-20 text-xs text-[#888888] font-mono">Loading resellers...</div>
      ) : resellers.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10 max-w-lg mx-auto">
          <Users size={36} className="text-[#666666] mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-1">No Resellers Appointed</h3>
          <p className="text-xs text-[#888888] mb-4">
            Authorize partners and distributors to issue software licenses under a defined quota without granting access to other applications.
          </p>
          <Button variant="secondary" size="sm" onClick={() => setModalOpen(true)} disabled={apps.length === 0}>
            Add First Reseller
          </Button>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Reseller Handle</th>
                <th className="py-3.5 px-4">Email</th>
                <th className="py-3.5 px-4">Assigned Application</th>
                <th className="py-3.5 px-4">Quota (Used / Total)</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {resellers.map((res) => (
                <tr key={res.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 font-bold text-white">{res.resellerUsername}</td>
                  <td className="py-3 px-4 text-[#888888]">{res.resellerEmail}</td>
                  <td className="py-3 px-4 text-[#cccccc]">{res.appId}</td>
                  <td className="py-3 px-4 text-[#aaaaaa]">
                    {res.keysUsed} / {res.keysQuota} keys
                  </td>
                  <td className="py-3 px-4">
                    <Badge variant={res.status === 'active' ? 'green' : 'red'}>
                      {res.status.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-[#666666]">
                    {new Date(res.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Appoint Software Reseller">
        {error && (
          <div className="p-3 mb-4 rounded-lg bg-red-950/40 text-red-400 text-xs border border-red-500/40">
            {error}
          </div>
        )}
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Target Application *</label>
            <select
              value={selectedAppId}
              onChange={(e) => setSelectedAppId(e.target.value)}
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
            >
              {apps.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Reseller Username *</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. EU_Distributor"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Reseller Email *</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="reseller@partner.com"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Assigned Key Quota</label>
            <input
              type="number"
              min={1}
              value={quota}
              onChange={(e) => setQuota(parseInt(e.target.value) || 50)}
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
            <Button type="button" variant="ghost" size="sm" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
              Appoint Reseller
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
