import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  createApplication,
  getApplications,
  deleteApplication,
} from '../shared/DatabaseService';
import { ApplicationItem } from '../shared/Types';
import { Button, Modal, Badge } from '../shared/Components/CommonUI';
import {
  Layers,
  Plus,
  Key,
  Shield,
  Eye,
  EyeOff,
  Copy,
  Check,
  Trash2,
  ExternalLink,
  Code,
  AlertCircle,
} from 'lucide-react';

interface ApplicationsProps {
  onNavigateKeysWithApp?: (appId: string) => void;
}

export const Applications: React.FC<ApplicationsProps> = ({ onNavigateKeysWithApp }) => {
  const { currentUser } = useAuth();
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [createModalOpen, setCreateModalOpen] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [version, setVersion] = useState('1.0.0');
  const [hwidLock, setHwidLock] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Secret visibility map
  const [revealedSecrets, setRevealedSecrets] = useState<Record<string, boolean>>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    loadApps();
  }, [currentUser]);

  const loadApps = async () => {
    if (!currentUser) return;
    try {
      setLoading(true);
      const items = await getApplications(currentUser.uid);
      setApps(items);
    } catch (err: any) {
      console.error('Failed to load apps:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateApp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setError(null);
    setSubmitting(true);
    try {
      await createApplication(
        currentUser.uid,
        currentUser.email || '',
        name.trim(),
        description.trim(),
        version.trim(),
        hwidLock
      );
      setName('');
      setDescription('');
      setVersion('1.0.0');
      setCreateModalOpen(false);
      await loadApps();
    } catch (err: any) {
      setError(err.message || 'Failed to create application');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (appId: string) => {
    if (!currentUser) return;
    if (!confirm('Are you sure you want to delete this application? All associated license configurations will be affected.')) return;
    try {
      await deleteApplication(appId, currentUser.uid, currentUser.email || '');
      await loadApps();
    } catch (err: any) {
      alert(err.message || 'Failed to delete application');
    }
  };

  const toggleRevealSecret = (appId: string) => {
    setRevealedSecrets((prev) => ({
      ...prev,
      [appId]: !prev[appId],
    }));
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Layers className="text-[#FF2020]" />
            <span>Application Management</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Register independent software applications with isolated secrets and hardware-locking rules.
          </p>
        </div>

        <Button variant="primary" size="md" onClick={() => setCreateModalOpen(true)}>
          <Plus size={16} />
          <span>New Application</span>
        </Button>
      </div>

      {/* Applications List */}
      {loading ? (
        <div className="text-center py-20 text-xs text-[#888888] font-mono">
          Loading applications...
        </div>
      ) : apps.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10 max-w-lg mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-[#FF2020]/10 border border-[#FF2020]/30 text-[#FF2020] flex items-center justify-center mx-auto mb-4">
            <Layers size={32} />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">No Applications Registered</h3>
          <p className="text-xs text-[#888888] mb-6">
            Create your first application profile to begin generating license keys, configuring HWID locks, and connecting SDK clients.
          </p>
          <Button variant="primary" size="md" onClick={() => setCreateModalOpen(true)}>
            <Plus size={16} />
            <span>Create First Application</span>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {apps.map((app) => {
            const isSecretVisible = revealedSecrets[app.id];
            return (
              <div
                key={app.id}
                className="glass-card rounded-2xl p-6 border border-white/10 flex flex-col justify-between relative group hover:border-[#FF2020]/40 transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-bold text-white tracking-tight">{app.name}</h3>
                        <Badge variant="gray">v{app.version}</Badge>
                        {app.status === 'active' ? (
                          <Badge variant="green">ACTIVE</Badge>
                        ) : (
                          <Badge variant="red">DISABLED</Badge>
                        )}
                      </div>
                      <p className="text-xs text-[#888888] mt-1 line-clamp-2">
                        {app.description || 'No description provided.'}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDelete(app.id)}
                      className="p-1.5 rounded-lg text-[#666666] hover:text-red-400 hover:bg-white/5 transition-colors"
                      title="Delete application"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>

                  {/* App ID & Secret Box */}
                  <div className="mt-4 p-3.5 rounded-xl bg-[#0e0e0e] border border-white/5 space-y-2.5 font-mono text-xs">
                    {/* App ID */}
                    <div className="flex items-center justify-between">
                      <span className="text-[#666666] text-[11px]">APPLICATION ID:</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white select-all">{app.id}</span>
                        <button
                          onClick={() => copyToClipboard(app.id, app.id)}
                          className="text-[#888888] hover:text-white"
                          title="Copy App ID"
                        >
                          {copiedKey === app.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>
                    </div>

                    {/* App Secret */}
                    <div className="flex items-center justify-between border-t border-white/5 pt-2">
                      <span className="text-[#666666] text-[11px]">APPLICATION SECRET:</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono">
                          {isSecretVisible ? app.appSecret : '••••••••••••••••••••••••'}
                        </span>
                        <button
                          onClick={() => toggleRevealSecret(app.id)}
                          className="text-[#888888] hover:text-white"
                          title={isSecretVisible ? 'Hide secret' : 'Reveal secret'}
                        >
                          {isSecretVisible ? <EyeOff size={12} /> : <Eye size={12} />}
                        </button>
                        <button
                          onClick={() => copyToClipboard(app.appSecret, app.appSecret)}
                          className="text-[#888888] hover:text-white"
                          title="Copy Secret"
                        >
                          {copiedKey === app.appSecret ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>
                    </div>

                    {/* HWID Status */}
                    <div className="flex items-center justify-between border-t border-white/5 pt-2">
                      <span className="text-[#666666] text-[11px]">HWID PROTECTION:</span>
                      <span className={app.hwidLockEnabled ? 'text-[#FF2020]' : 'text-[#888888]'}>
                        {app.hwidLockEnabled ? 'HARDWARE LOCKED' : 'DISABLED'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-xs font-mono text-[#666666]">
                  <span>Created {new Date(app.createdAt).toLocaleDateString()}</span>
                  {onNavigateKeysWithApp && (
                    <button
                      onClick={() => onNavigateKeysWithApp(app.id)}
                      className="text-[#FF2020] hover:underline inline-flex items-center gap-1 cursor-pointer"
                    >
                      <span>Manage Keys</span>
                      <ExternalLink size={12} />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Application Modal */}
      <Modal
        isOpen={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        title="Register New Software Application"
      >
        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/40 border border-red-500/40 text-red-400 text-xs flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleCreateApp} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">
              Software Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Spidy Cheats, Nova Bot, CyberGuard"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2.5 px-3 text-sm text-white placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">
              Application Version
            </label>
            <input
              type="text"
              required
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              placeholder="1.0.0"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2.5 px-3 text-sm text-white font-mono placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#aaaaaa] mb-1.5">
              Description / Notes
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of application features and architecture"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2.5 px-3 text-sm text-white placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
            />
          </div>

          {/* HWID Toggle */}
          <div className="p-3 rounded-xl bg-[#141414] border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Shield size={18} className="text-[#FF2020]" />
              <div>
                <span className="text-xs font-bold text-white block">Enable HWID Lock</span>
                <span className="text-[11px] text-[#888888] block">
                  Binds client hardware fingerprint on initial activation to stop key sharing
                </span>
              </div>
            </div>
            <input
              type="checkbox"
              checked={hwidLock}
              onChange={(e) => setHwidLock(e.target.checked)}
              className="w-4 h-4 accent-[#FF2020] cursor-pointer"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setCreateModalOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
              Deploy Application
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
