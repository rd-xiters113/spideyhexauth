import React, { useState, useEffect } from 'react';
import { useAuth } from '../shared/AuthContext';
import { getApplications } from '../shared/DatabaseService';
import { ApplicationItem } from '../shared/Types';
import { apiService, ApiResponse } from '../shared/ApiService';
import { Button, Badge } from '../shared/Components/CommonUI';
import {
  Terminal,
  Code,
  Play,
  Copy,
  Check,
  ShieldAlert,
  Send,
  Cpu,
  Layers,
} from 'lucide-react';

export const ApiSdkDocs: React.FC = () => {
  const { currentUser } = useAuth();
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [activeTab, setActiveTab] = useState<'sdk' | 'api-tester' | 'rest-docs'>('sdk');
  const [selectedLanguage, setSelectedLanguage] = useState<'csharp' | 'cpp' | 'python' | 'javascript'>('csharp');
  const [copiedCode, setCopiedCode] = useState(false);

  // API Tester States
  const [testEndpoint, setTestEndpoint] = useState<string>('init');
  const [selectedAppId, setSelectedAppId] = useState('');
  const [testKey, setTestKey] = useState('SPIDY-TEST-KEY-0001');
  const [testHwid, setTestHwid] = useState('HWID-883F-9201-B45A');
  const [testUsername, setTestUsername] = useState('demo_user');
  const [testPassword, setTestPassword] = useState('password123');
  const [apiResponse, setApiResponse] = useState<ApiResponse | null>(null);
  const [testing, setTesting] = useState(false);
  const [requestLatency, setRequestLatency] = useState<number | null>(null);

  useEffect(() => {
    if (!currentUser) return;
    getApplications(currentUser.uid).then((items) => {
      setApps(items);
      if (items.length > 0) {
        setSelectedAppId(items[0].id);
      }
    });
  }, [currentUser]);

  const activeApp = apps.find((a) => a.id === selectedAppId);

  const handleTestApi = async () => {
    setTesting(true);
    setApiResponse(null);
    const start = performance.now();
    try {
      let res: ApiResponse;
      const appId = activeApp?.id || 'demo_app';
      const secret = activeApp?.appSecret || 'demo_secret';

      if (testEndpoint === 'init') {
        res = await apiService.initApp(appId, secret);
      } else if (testEndpoint === 'verify') {
        res = await apiService.verifyLicense(appId, testKey, testHwid);
      } else if (testEndpoint === 'login-key') {
        res = await apiService.login(appId, { key: testKey, hwid: testHwid });
      } else if (testEndpoint === 'login-creds') {
        res = await apiService.login(appId, { username: testUsername, password: testPassword, hwid: testHwid });
      } else if (testEndpoint === 'register') {
        res = await apiService.register(appId, { key: testKey, username: testUsername, password: testPassword, hwid: testHwid });
      } else if (testEndpoint === 'hwid-reset') {
        res = await apiService.resetHwid(appId, testKey);
      } else if (testEndpoint === 'version') {
        res = await apiService.checkVersion(appId);
      } else if (testEndpoint === 'subscription') {
        res = await apiService.checkSubscription(currentUser?.email || 'user@example.com');
      } else {
        res = { success: false, error: 'Unknown endpoint' };
      }

      const latency = Math.round(performance.now() - start);
      setRequestLatency(latency);
      setApiResponse(res);
    } catch (err: any) {
      setRequestLatency(Math.round(performance.now() - start));
      setApiResponse({ success: false, error: err.message || 'Network request failed' });
    } finally {
      setTesting(false);
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const csharpSdkCode = `// ========================================================
// SPIDY AUTH OFFICIAL C# SDK (v2.5 Production)
// Architecture: Zero-Trust Hardware Binding & REST Sessions
// ========================================================
using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace SpidyAuth
{
    public class SpidyClient
    {
        private readonly string _appId;
        private readonly string _appSecret;
        private readonly string _version;
        private readonly string _apiBase;
        private readonly HttpClient _http;
        private string _sessionToken;

        public SpidyClient(string appId, string appSecret, string version = "1.0.0", string apiBase = "${window.location.origin}/api")
        {
            _appId = appId;
            _appSecret = appSecret;
            _version = version;
            _apiBase = apiBase.TrimEnd('/');
            _http = new HttpClient();
        }

        // 1. Initialize Application Session
        public async Task<SpidyResponse> InitializeAsync()
        {
            var payload = new { appId = _appId, appSecret = _appSecret };
            return await PostAsync("/v1/application/init", payload);
        }

        // 2. Authenticate with License Key
        public async Task<SpidyResponse> LoginWithLicenseAsync(string licenseKey)
        {
            string hwid = GetMachineHardwareId();
            var payload = new { appId = _appId, key = licenseKey, hwid = hwid };
            var result = await PostAsync("/v1/license/login", payload);
            if (result.Success && result.SessionToken != null)
            {
                _sessionToken = result.SessionToken;
            }
            return result;
        }

        // 3. Authenticate with Username & Password
        public async Task<SpidyResponse> LoginWithCredentialsAsync(string username, string password)
        {
            string hwid = GetMachineHardwareId();
            var payload = new { appId = _appId, username = username, password = password, hwid = hwid };
            var result = await PostAsync("/v1/license/login", payload);
            if (result.Success && result.SessionToken != null)
            {
                _sessionToken = result.SessionToken;
            }
            return result;
        }

        // 4. Register Client using License Key
        public async Task<SpidyResponse> RegisterAsync(string licenseKey, string username, string password)
        {
            string hwid = GetMachineHardwareId();
            var payload = new { appId = _appId, key = licenseKey, username = username, password = password, hwid = hwid };
            return await PostAsync("/v1/license/register", payload);
        }

        // 5. Terminate Session
        public async Task<SpidyResponse> LogoutAsync()
        {
            var payload = new { appId = _appId, sessionToken = _sessionToken };
            _sessionToken = null;
            return await PostAsync("/v1/license/logout", payload);
        }

        // 6. Check Latest Remote Version
        public async Task<SpidyResponse> CheckVersionAsync()
        {
            var response = await _http.GetAsync($"{_apiBase}/v1/application/version?appId={_appId}");
            var body = await response.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<SpidyResponse>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        // Hardware Identification (HWID)
        private string GetMachineHardwareId()
        {
            string raw = Environment.MachineName + "_" + Environment.UserName + "_" + Environment.ProcessorCount;
            using var sha = SHA256.Create();
            byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(raw));
            return BitConverter.ToString(bytes).Replace("-", "").Substring(0, 24);
        }

        private async Task<SpidyResponse> PostAsync(string endpoint, object data)
        {
            var content = new StringContent(JsonSerializer.Serialize(data), Encoding.UTF8, "application/json");
            var response = await _http.PostAsync($"{_apiBase}{endpoint}", content);
            var body = await response.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<SpidyResponse>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
    }

    public class SpidyResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string Error { get; set; }
        public string SessionToken { get; set; }
        public JsonElement Data { get; set; }
    }
}`;

  const pythonSdkCode = `# ========================================================
# SPIDY AUTH PYTHON CLIENT (v2.5)
# ========================================================
import requests
import hashlib
import platform

class SpidyClient:
    def __init__(self, app_id: str, app_secret: str, api_base: str = "${window.location.origin}/api"):
        self.app_id = app_id
        self.app_secret = app_secret
        self.api_base = api_base.rstrip('/')
        self.session_token = None

    def _get_hwid(self) -> str:
        raw = f"{platform.node()}_{platform.processor()}_{platform.machine()}"
        return hashlib.sha256(raw.encode()).hexdigest()[:24].upper()

    def initialize(self):
        url = f"{self.api_base}/v1/application/init"
        res = requests.post(url, json={"appId": self.app_id, "appSecret": self.app_secret})
        return res.json()

    def login_with_license(self, license_key: str):
        url = f"{self.api_base}/v1/license/login"
        payload = {"appId": self.app_id, "key": license_key, "hwid": self._get_hwid()}
        res = requests.post(url, json=payload)
        data = res.json()
        if data.get("success"):
            self.session_token = data.get("sessionToken")
        return data

    def login_with_credentials(self, username: str, password: str):
        url = f"{self.api_base}/v1/license/login"
        payload = {"appId": self.app_id, "username": username, "password": password, "hwid": self._get_hwid()}
        return requests.post(url, json=payload).json()
`;

  const cppSdkCode = `// ========================================================
// SPIDY AUTH C++ CLIENT HEADER (v2.5)
// ========================================================
#pragma once
#include <string>
#include <iostream>

class SpidyClient {
private:
    std::string m_appId;
    std::string m_appSecret;
    std::string m_apiBase;
    std::string m_sessionToken;

    std::string GetHwid();

public:
    SpidyClient(const std::string& appId, const std::string& appSecret, const std::string& apiBase);
    bool Initialize();
    bool LoginWithLicense(const std::string& licenseKey);
    bool LoginWithCredentials(const std::string& username, const std::string& password);
    void Logout();
    bool CheckVersion();
};
`;

  const jsSdkCode = `// ========================================================
// SPIDY AUTH JAVASCRIPT / TYPESCRIPT CLIENT (v2.5)
// ========================================================
export class SpidyClient {
  constructor(appId, appSecret, apiBase = '${window.location.origin}/api') {
    this.appId = appId;
    this.appSecret = appSecret;
    this.apiBase = apiBase;
    this.sessionToken = null;
  }

  async initialize() {
    const res = await fetch(\`\${this.apiBase}/v1/application/init\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId: this.appId, appSecret: this.appSecret }),
    });
    return res.json();
  }

  async loginWithLicense(key, hwid = 'browser-client') {
    const res = await fetch(\`\${this.apiBase}/v1/license/login\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId: this.appId, key, hwid }),
    });
    const data = await res.json();
    if (data.success) this.sessionToken = data.sessionToken;
    return data;
  }
}
`;

  const getCurrentCode = () => {
    switch (selectedLanguage) {
      case 'csharp':
        return csharpSdkCode;
      case 'python':
        return pythonSdkCode;
      case 'cpp':
        return cppSdkCode;
      case 'javascript':
        return jsSdkCode;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Terminal className="text-[#FF2020]" />
            <span>Developer SDK & REST API</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Enterprise SDK libraries, real-time interactive endpoint testing, and zero-trust documentation.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 bg-[#121212] p-1 rounded-xl border border-white/10">
          <button
            onClick={() => setActiveTab('sdk')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
              activeTab === 'sdk'
                ? 'bg-[#FF2020] text-white shadow-[0_0_12px_rgba(255,32,32,0.4)]'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            SDK Libraries
          </button>
          <button
            onClick={() => setActiveTab('api-tester')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
              activeTab === 'api-tester'
                ? 'bg-[#FF2020] text-white shadow-[0_0_12px_rgba(255,32,32,0.4)]'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            Live API Simulator
          </button>
          <button
            onClick={() => setActiveTab('rest-docs')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
              activeTab === 'rest-docs'
                ? 'bg-[#FF2020] text-white shadow-[0_0_12px_rgba(255,32,32,0.4)]'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            REST Endpoints
          </button>
        </div>
      </div>

      {/* TAB 1: SDK LIBRARIES */}
      {activeTab === 'sdk' && (
        <div className="space-y-6">
          {/* Security Architecture Notice (Part 18 Requirement) */}
          <div className="p-4 rounded-xl bg-[#141414] border border-amber-500/30 text-amber-200 text-xs flex items-start gap-3">
            <ShieldAlert size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-amber-400 block font-mono">
                DESKTOP CLIENT SECURITY PRINCIPLE:
              </strong>
              <p className="text-[#aaaaaa] mt-0.5 leading-relaxed">
                Desktop application secrets (like <code>appSecret</code>) cannot be completely hidden from reverse engineering or memory inspection. Always enforce server-side HWID verification, validate license expiration on each protected action, and issue short-lived session tokens. Never embed Firebase Admin SDK or administrative database credentials inside desktop binaries.
              </p>
            </div>
          </div>

          {/* Language Selector & Code Box */}
          <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-2xl">
            <div className="px-5 py-3.5 bg-[#121212] border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {(['csharp', 'python', 'cpp', 'javascript'] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setSelectedLanguage(lang)}
                    className={`px-3 py-1 rounded-md text-xs font-mono uppercase tracking-wider transition-all ${
                      selectedLanguage === lang
                        ? 'bg-[#FF2020]/20 text-[#FF2020] border border-[#FF2020]/40'
                        : 'text-[#777777] hover:text-white'
                    }`}
                  >
                    {lang === 'csharp' ? 'C# (.NET)' : lang === 'cpp' ? 'C++' : lang}
                  </button>
                ))}
              </div>

              <button
                onClick={() => copyCode(getCurrentCode())}
                className="text-xs font-mono text-[#888888] hover:text-white flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 transition-colors"
              >
                {copiedCode ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copiedCode ? 'Copied' : 'Copy SDK Code'}</span>
              </button>
            </div>

            <pre className="p-6 text-xs sm:text-sm font-mono text-[#dddddd] bg-[#090909] overflow-x-auto leading-relaxed max-h-[500px]">
              <code>{getCurrentCode()}</code>
            </pre>
          </div>
        </div>
      )}

      {/* TAB 2: LIVE API SIMULATOR */}
      {activeTab === 'api-tester' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Request Builder */}
          <div className="glass-card rounded-2xl p-6 border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Play size={16} className="text-[#FF2020]" />
                <span>Request Dispatcher</span>
              </h3>
              <Badge variant="red">REAL-TIME</Badge>
            </div>

            {/* Target App */}
            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1">
                Select Active Application
              </label>
              <select
                value={selectedAppId}
                onChange={(e) => setSelectedAppId(e.target.value)}
                className="w-full bg-[#0e0e0e] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
              >
                {apps.map((app) => (
                  <option key={app.id} value={app.id}>
                    {app.name} ({app.id})
                  </option>
                ))}
              </select>
            </div>

            {/* Endpoint */}
            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Target Endpoint</label>
              <select
                value={testEndpoint}
                onChange={(e) => setTestEndpoint(e.target.value)}
                className="w-full bg-[#0e0e0e] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
              >
                <option value="init">POST /api/v1/application/init (Initialize session)</option>
                <option value="verify">POST /api/v1/license/verify (Check key & HWID)</option>
                <option value="login-key">POST /api/v1/license/login (Key auth & bind)</option>
                <option value="login-creds">POST /api/v1/license/login (User/pwd auth)</option>
                <option value="register">POST /api/v1/license/register (Key account registration)</option>
                <option value="hwid-reset">POST /api/v1/license/hwid-reset (Reset hardware bind)</option>
                <option value="version">GET /api/v1/application/version (Query software version)</option>
                <option value="subscription">GET /api/v1/subscription/status (Check user plan)</option>
              </select>
            </div>

            {/* Dynamic Inputs based on Endpoint */}
            {(testEndpoint === 'verify' || testEndpoint === 'login-key' || testEndpoint === 'register' || testEndpoint === 'hwid-reset') && (
              <div>
                <label className="block text-xs font-medium text-[#aaaaaa] mb-1">License Key</label>
                <input
                  type="text"
                  value={testKey}
                  onChange={(e) => setTestKey(e.target.value)}
                  placeholder="SPIDY-XXXX-XXXX-XXXX-XXXX"
                  className="w-full bg-[#0e0e0e] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:border-[#FF2020]"
                />
              </div>
            )}

            {(testEndpoint === 'verify' || testEndpoint === 'login-key' || testEndpoint === 'login-creds' || testEndpoint === 'register') && (
              <div>
                <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Client Hardware ID (HWID)</label>
                <input
                  type="text"
                  value={testHwid}
                  onChange={(e) => setTestHwid(e.target.value)}
                  placeholder="HWID-XXXXXXXXXXXX"
                  className="w-full bg-[#0e0e0e] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:border-[#FF2020]"
                />
              </div>
            )}

            {(testEndpoint === 'login-creds' || testEndpoint === 'register') && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Username</label>
                  <input
                    type="text"
                    value={testUsername}
                    onChange={(e) => setTestUsername(e.target.value)}
                    className="w-full bg-[#0e0e0e] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Password</label>
                  <input
                    type="password"
                    value={testPassword}
                    onChange={(e) => setTestPassword(e.target.value)}
                    className="w-full bg-[#0e0e0e] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
                  />
                </div>
              </div>
            )}

            <Button
              variant="primary"
              className="w-full py-2.5 font-mono"
              onClick={handleTestApi}
              isLoading={testing}
            >
              <Send size={14} />
              <span>Execute Live API Request</span>
            </Button>
          </div>

          {/* Right: Response Inspector */}
          <div className="glass-card rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Terminal size={16} className="text-[#FF2020]" />
                  <span>Response Inspector</span>
                </h3>
                {requestLatency !== null && (
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                    {requestLatency} ms
                  </span>
                )}
              </div>

              {testing ? (
                <div className="py-20 text-center text-xs font-mono text-[#888888]">
                  <div className="w-6 h-6 border-2 border-[#FF2020] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                  <span>Executing server request...</span>
                </div>
              ) : apiResponse ? (
                <pre className="p-4 rounded-xl bg-[#0a0a0a] border border-white/10 text-xs font-mono text-emerald-400 overflow-x-auto max-h-[350px]">
                  {JSON.stringify(apiResponse, null, 2)}
                </pre>
              ) : (
                <div className="py-20 text-center text-xs font-mono text-[#666666]">
                  Click "Execute Live API Request" to test endpoint response.
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-white/5 text-[11px] font-mono text-[#666666] flex items-center justify-between">
              <span>Status: {apiResponse ? (apiResponse.success ? '200 OK' : '403 Rejected') : 'Standby'}</span>
              <span>Spidy Engine v2.5</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: REST ENDPOINTS REFERENCE */}
      {activeTab === 'rest-docs' && (
        <div className="space-y-4">
          {[
            {
              method: 'POST',
              path: '/api/v1/application/init',
              desc: 'Initializes application session and returns application name, version, and HWID policy.',
              body: '{\n  "appId": "app_xxx",\n  "appSecret": "sec_xxx"\n}',
            },
            {
              method: 'POST',
              path: '/api/v1/license/verify',
              desc: 'Verifies whether a license key is active, expired, or banned, and checks HWID matching.',
              body: '{\n  "appId": "app_xxx",\n  "key": "SPIDY-XXXX-XXXX-XXXX-XXXX",\n  "hwid": "optional-hwid"\n}',
            },
            {
              method: 'POST',
              path: '/api/v1/license/login',
              desc: 'Authenticates a user with a license key or credentials, binding hardware ID on first use and returning a session token.',
              body: '{\n  "appId": "app_xxx",\n  "key": "SPIDY-XXXX-XXXX-XXXX-XXXX",\n  "hwid": "MACHINE-HWID-STRING"\n}',
            },
            {
              method: 'POST',
              path: '/api/v1/license/register',
              desc: 'Registers username and hashed password credentials to an unused license key.',
              body: '{\n  "appId": "app_xxx",\n  "key": "SPIDY-XXXX-XXXX-XXXX-XXXX",\n  "username": "client_pro",\n  "password": "plain_password",\n  "hwid": "HWID-STRING"\n}',
            },
            {
              method: 'POST',
              path: '/api/v1/license/logout',
              desc: 'Invalidates and closes an active software session token.',
              body: '{\n  "appId": "app_xxx",\n  "sessionToken": "ses_xxx"\n}',
            },
            {
              method: 'POST',
              path: '/api/v1/license/hwid-reset',
              desc: 'Resets the bound hardware fingerprint for a key.',
              body: '{\n  "appId": "app_xxx",\n  "key": "SPIDY-XXXX-XXXX-XXXX-XXXX"\n}',
            },
            {
              method: 'GET',
              path: '/api/v1/application/version?appId=app_xxx',
              desc: 'Queries latest release version and updates from the server.',
              body: 'None (Query parameters)',
            },
            {
              method: 'GET',
              path: '/api/v1/subscription/status?email=user@example.com',
              desc: 'Checks admin allowlist subscription status for an account.',
              body: 'None (Query parameters)',
            },
          ].map((ep) => (
            <div key={ep.path} className="glass-card rounded-xl p-5 border border-white/10 font-mono">
              <div className="flex items-center gap-3 mb-2">
                <span
                  className={`px-2 py-0.5 rounded text-xs font-bold ${
                    ep.method === 'POST' ? 'bg-[#FF2020]/20 text-[#FF2020]' : 'bg-blue-500/20 text-blue-400'
                  }`}
                >
                  {ep.method}
                </span>
                <span className="text-white font-bold text-sm">{ep.path}</span>
              </div>
              <p className="text-xs text-[#888888] font-sans mb-3">{ep.desc}</p>
              <div className="p-3 rounded-lg bg-[#0a0a0a] border border-white/5 text-xs text-[#aaaaaa]">
                <span className="text-[#666666] text-[10px] uppercase block mb-1">Payload / Body:</span>
                <pre className="overflow-x-auto leading-relaxed">{ep.body}</pre>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
