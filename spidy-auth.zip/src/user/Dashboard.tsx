import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import { StatCard, Button, Badge } from '../shared/Components/CommonUI';
import {
  getApplications,
  getLicenseKeys,
  getActivityLogs,
} from '../shared/DatabaseService';
import { ApplicationItem, LicenseKeyItem, ActivityLogItem } from '../shared/Types';
import {
  Layers,
  KeyRound,
  ShieldCheck,
  Clock,
  Zap,
  AlertTriangle,
  ArrowRight,
  Plus,
  Terminal,
  Copy,
  Check,
  Lock,
} from 'lucide-react';

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { userProfile, currentUser, remainingKeys, resendVerificationEmail } = useAuth();
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [keys, setKeys] = useState<LicenseKeyItem[]>([]);
  const [activities, setActivities] = useState<ActivityLogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState(false);
  const [verificationSent, setVerificationSent] = useState(false);

  useEffect(() => {
    if (!currentUser) return;
    loadDashboardData();
  }, [currentUser]);

  const loadDashboardData = async () => {
    if (!currentUser) return;
    try {
      setLoading(true);
      const [userApps, userKeys, logs] = await Promise.all([
        getApplications(currentUser.uid),
        getLicenseKeys(currentUser.uid),
        getActivityLogs(10, currentUser.uid),
      ]);
      setApps(userApps);
      setKeys(userKeys);
      setActivities(logs);
    } catch (e) {
      console.warn('Dashboard load error:', e);
    } finally {
      setLoading(false);
    }
  };

  const activeKeysCount = keys.filter((k) => k.status === 'active').length;
  const expiredKeysCount = keys.filter((k) => k.status === 'expired').length;
  const isFreePlan = userProfile?.plan === 'FREE';
  const isQuotaExceeded = isFreePlan && (userProfile?.keysUsed || 0) >= 50;

  const copyUid = () => {
    if (currentUser?.uid) {
      navigator.clipboard.writeText(currentUser.uid);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleResendEmail = async () => {
    await resendVerificationEmail();
    setVerificationSent(true);
    setTimeout(() => setVerificationSent(false), 4000);
  };

  return (
    <div className="space-y-8">
      {/* Header Profile Ribbon */}
      <div className="glass-card rounded-2xl p-6 border border-white/10 relative overflow-hidden flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#FF2020] to-[#880000] flex items-center justify-center text-white text-xl font-bold shadow-[0_0_20px_rgba(255,32,32,0.4)]">
            {userProfile?.displayName?.charAt(0).toUpperCase() || 'D'}
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl font-extrabold text-white">
                {userProfile?.displayName || 'Developer'}
              </h2>
              {userProfile?.plan === 'PREMIUM' ? (
                <Badge variant="red">PREMIUM</Badge>
              ) : (
                <Badge variant="gray">STARTER FREE</Badge>
              )}
              {currentUser?.emailVerified ? (
                <Badge variant="green">VERIFIED</Badge>
              ) : (
                <button
                  onClick={handleResendEmail}
                  className="text-[11px] font-mono text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30 transition-colors"
                >
                  {verificationSent ? 'Link Dispatched' : 'Verify Email'}
                </button>
              )}
            </div>
            <p className="text-xs text-[#888888] mt-1 font-mono">{userProfile?.email}</p>
            <div className="flex items-center gap-2 mt-1.5 text-[11px] text-[#666666] font-mono">
              <span>UID: {currentUser?.uid?.substring(0, 16)}...</span>
              <button onClick={copyUid} className="text-[#888888] hover:text-white transition-colors">
                {copiedId ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
              </button>
              <span>&bull;</span>
              <span>Joined: {userProfile?.createdAt ? new Date(userProfile.createdAt).toLocaleDateString() : 'Today'}</span>
            </div>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-3">
          <Button variant="secondary" size="sm" onClick={() => onNavigate('applications')}>
            <Plus size={14} />
            <span>New App</span>
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => onNavigate('license-keys')}
            disabled={isQuotaExceeded}
          >
            <KeyRound size={14} />
            <span>Generate Key</span>
          </Button>
        </div>
      </div>

      {/* Quota Exceeded Warning Banner (Part 4) */}
      {isQuotaExceeded && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/60 text-red-200 text-sm flex items-start gap-3 neon-glow-sm">
          <AlertTriangle className="text-[#FF2020] shrink-0 mt-0.5" size={20} />
          <div className="flex-1">
            <h4 className="font-bold text-[#FF2020]">Free Plan Limit Reached (50 / 50 Keys)</h4>
            <p className="text-xs text-[#cccccc] mt-1">
              You have reached your Free Plan key generation limit. Upgrade to Premium to access additional features and unlock unlimited key generation.
            </p>
          </div>
          <Button variant="primary" size="sm" onClick={() => onNavigate('subscription')}>
            <span>Upgrade to Premium</span>
            <ArrowRight size={14} />
          </Button>
        </div>
      )}

      {/* Live Quota Bar (Part 4) */}
      <div className="glass-card rounded-xl p-5 border border-white/10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Zap size={16} className="text-[#FF2020]" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              License Quota Telemetry
            </h3>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="text-[#888888]">
              Plan:{' '}
              <strong className={isFreePlan ? 'text-white' : 'text-[#FF2020]'}>
                {userProfile?.plan || 'FREE'}
              </strong>
            </span>
            <span className="text-[#888888]">
              Keys Used:{' '}
              <strong className="text-white font-semibold">
                {userProfile?.keysUsed || 0} / {isFreePlan ? 50 : 'UNLIMITED'}
              </strong>
            </span>
            {isFreePlan && (
              <span className="text-[#888888]">
                Remaining Keys:{' '}
                <strong className={remainingKeys > 5 ? 'text-emerald-400' : 'text-[#FF2020]'}>
                  {remainingKeys}
                </strong>
              </span>
            )}
          </div>
        </div>

        {/* Progress bar */}
        {isFreePlan ? (
          <div className="w-full bg-[#1c1c1c] rounded-full h-2.5 overflow-hidden p-0.5 border border-white/5">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                (userProfile?.keysUsed || 0) >= 50
                  ? 'bg-red-500 shadow-[0_0_12px_rgba(255,32,32,0.8)]'
                  : 'bg-gradient-to-r from-emerald-500 to-[#FF2020]'
              }`}
              style={{ width: `${Math.min(100, ((userProfile?.keysUsed || 0) / 50) * 100)}%` }}
            />
          </div>
        ) : (
          <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono py-1">
            <ShieldCheck size={14} />
            <span>Premium Tier Active: Unrestricted license generation quota granted.</span>
          </div>
        )}
      </div>

      {/* Key Metric Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          title="Applications"
          value={apps.length}
          subtitle="Software projects registered"
          icon={Layers}
          badge="ISOLATED"
          badgeColor="blue"
        />
        <StatCard
          title="Total Keys Created"
          value={userProfile?.keysUsed || keys.length}
          subtitle={`Lifetime generation count`}
          icon={KeyRound}
          badge={isFreePlan ? `${50 - (userProfile?.keysUsed || 0)} LEFT` : 'UNLIMITED'}
          badgeColor={isFreePlan ? 'amber' : 'red'}
        />
        <StatCard
          title="Active Licenses"
          value={activeKeysCount}
          subtitle="Currently authorized clients"
          icon={ShieldCheck}
          badge="HEALTHY"
          badgeColor="green"
        />
        <StatCard
          title="Expired / Banned"
          value={expiredKeysCount}
          subtitle="Revoked or timed-out"
          icon={Clock}
          badge="TERMINATED"
          badgeColor="gray"
        />
      </div>

      {/* Applications Quick Overview & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Registered Apps Preview */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-6 border border-white/10">
          <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
            <div className="flex items-center gap-2">
              <Layers size={18} className="text-[#FF2020]" />
              <h3 className="text-base font-bold text-white">Your Applications</h3>
            </div>
            <button
              onClick={() => onNavigate('applications')}
              className="text-xs text-[#FF2020] hover:underline font-mono inline-flex items-center gap-1"
            >
              <span>Manage All</span>
              <ArrowRight size={12} />
            </button>
          </div>

          {apps.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-sm text-[#888888] mb-4">No applications registered yet.</p>
              <Button variant="primary" size="sm" onClick={() => onNavigate('applications')}>
                <Plus size={14} />
                <span>Create First Application</span>
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {apps.slice(0, 4).map((app) => (
                <div
                  key={app.id}
                  className="p-4 rounded-xl bg-[#121212] border border-white/5 hover:border-white/15 transition-all flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{app.name}</span>
                      <span className="text-[11px] font-mono text-[#888888] bg-white/5 px-2 py-0.5 rounded">
                        v{app.version}
                      </span>
                      {app.hwidLockEnabled && (
                        <span className="text-[10px] font-mono text-[#FF2020] bg-[#FF2020]/10 px-1.5 py-0.5 rounded border border-[#FF2020]/30">
                          HWID ON
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-[#777777] mt-1 font-mono">ID: {app.id}</p>
                  </div>

                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => onNavigate('license-keys')}
                    className="text-xs font-mono"
                  >
                    View Keys
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right 1 Col: Security Audit Logs */}
        <div className="glass-card rounded-2xl p-6 border border-white/10">
          <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
            <div className="flex items-center gap-2">
              <Terminal size={18} className="text-[#FF2020]" />
              <h3 className="text-base font-bold text-white">Security Stream</h3>
            </div>
          </div>

          {activities.length === 0 ? (
            <p className="text-xs text-[#888888] py-8 text-center">No recent activity logged.</p>
          ) : (
            <div className="space-y-3.5">
              {activities.slice(0, 5).map((log) => (
                <div key={log.id} className="text-xs border-l-2 border-[#FF2020]/60 pl-3 py-0.5">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-white font-medium">{log.action}</span>
                    <span className="text-[10px] text-[#666666]">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[#888888] text-[11px] mt-0.5 line-clamp-1">{log.details}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
