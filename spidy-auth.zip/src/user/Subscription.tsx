import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  submitUpgradeRequest,
  getUpgradeRequests,
} from '../shared/DatabaseService';
import { UpgradeRequestItem } from '../shared/Types';
import { Button, Modal, Badge } from '../shared/Components/CommonUI';
import {
  Zap,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Send,
  AlertCircle,
  Lock,
  Sparkles,
} from 'lucide-react';

export const Subscription: React.FC = () => {
  const { userProfile, currentUser, remainingKeys } = useAuth();
  const [requests, setRequests] = useState<UpgradeRequestItem[]>([]);
  const [loadingRequests, setLoadingRequests] = useState(true);

  // Upgrade Modal
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('Premium 90 Days');
  const [paymentRef, setPaymentRef] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isFreePlan = userProfile?.plan === 'FREE';

  useEffect(() => {
    loadRequests();
  }, [currentUser]);

  const loadRequests = async () => {
    if (!currentUser) return;
    try {
      setLoadingRequests(true);
      const items = await getUpgradeRequests(currentUser.uid);
      setRequests(items);
    } catch (e) {
      console.warn('Error loading requests:', e);
    } finally {
      setLoadingRequests(false);
    }
  };

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setError(null);
    setSubmitting(true);
    try {
      await submitUpgradeRequest(
        currentUser.uid,
        currentUser.email || '',
        'PREMIUM',
        selectedPlan,
        paymentRef.trim(),
        message.trim()
      );
      setSuccessMsg(true);
      setPaymentRef('');
      setMessage('');
      await loadRequests();
    } catch (err: any) {
      setError(err.message || 'Failed to submit request');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="pb-4 border-b border-white/10">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <Zap className="text-[#FF2020]" />
          <span>Subscription & Quota Management</span>
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Monitor your license creation quota, view verified subscriptions, and submit upgrade applications.
        </p>
      </div>

      {/* Current Subscription Status Card */}
      <div className="glass-card rounded-2xl p-6 sm:p-8 border border-white/10 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
          <div>
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono uppercase text-[#888888]">Current Plan:</span>
              {isFreePlan ? (
                <Badge variant="gray" size="md">
                  FREE STARTER TIER
                </Badge>
              ) : (
                <Badge variant="red" size="md">
                  PREMIUM DEVELOPER ACCESS
                </Badge>
              )}
            </div>
            <h3 className="text-3xl font-extrabold font-mono text-white mt-2">
              {isFreePlan ? 'Starter Free' : 'Enterprise Premium'}
            </h3>
            {userProfile?.subscriptionExpiresAt ? (
              <p className="text-xs text-[#aaaaaa] mt-1 font-mono">
                Active until: {new Date(userProfile.subscriptionExpiresAt).toLocaleDateString()}
              </p>
            ) : (
              <p className="text-xs text-[#666666] mt-1 font-mono">
                {isFreePlan ? 'Standard lifetime free tier' : 'Permanent Lifetime Premium'}
              </p>
            )}
          </div>

          {isFreePlan && (
            <Button variant="primary" size="md" onClick={() => setUpgradeModalOpen(true)}>
              <Sparkles size={16} />
              <span>Request Premium Upgrade</span>
            </Button>
          )}
        </div>

        {/* Live Quota Bar */}
        <div className="mt-6">
          <div className="flex items-center justify-between text-xs font-mono mb-2">
            <span className="text-[#888888]">
              License Generation Quota (Immutable Meter):
            </span>
            <span className="text-white font-bold">
              {userProfile?.keysUsed || 0} / {isFreePlan ? 50 : 'UNLIMITED'}
            </span>
          </div>

          {isFreePlan ? (
            <div className="w-full bg-[#1c1c1c] rounded-full h-3 overflow-hidden p-0.5 border border-white/5">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  (userProfile?.keysUsed || 0) >= 50
                    ? 'bg-red-500 shadow-[0_0_15px_rgba(255,32,32,0.8)]'
                    : 'bg-gradient-to-r from-emerald-500 to-[#FF2020]'
                }`}
                style={{ width: `${Math.min(100, ((userProfile?.keysUsed || 0) / 50) * 100)}%` }}
              />
            </div>
          ) : (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono flex items-center gap-2">
              <ShieldCheck size={16} />
              <span>Unlimited license key generation quota unlocked by platform administrator.</span>
            </div>
          )}

          {isFreePlan && (
            <div className="mt-3 flex items-center justify-between text-xs font-mono text-[#888888]">
              <span>Keys Remaining: <strong className="text-white">{remainingKeys}</strong></span>
              <span>Deleting keys does not restore consumed quota</span>
            </div>
          )}
        </div>
      </div>

      {/* Plan Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-card rounded-2xl p-6 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold text-white text-base">Free Plan Inclusions</h4>
            <Badge variant="gray">ACTIVE</Badge>
          </div>
          <ul className="space-y-3 text-xs text-[#aaaaaa]">
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>50 Lifetime Generated License Keys</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>Hardware-ID (HWID) Binding</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>Multi-Application Partitioning</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>Standard REST API & C# Client</span>
            </li>
            <li className="flex items-center gap-2 text-[#555555]">
              <Lock size={14} />
              <span>Admin Allowlist Verification Required for Scale</span>
            </li>
          </ul>
        </div>

        <div className="glass-card rounded-2xl p-6 border border-[#FF2020]/40 neon-glow-sm">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold text-white text-base">Premium Privileges</h4>
            <Badge variant="red">ADMIN MANAGED</Badge>
          </div>
          <ul className="space-y-3 text-xs text-[#cccccc]">
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <strong className="text-white">Unlimited License Key Generation</strong>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>Reseller Network Management & Quotas</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>High-Frequency Dedicated API Throughput</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>Priority Security Architecture Support</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 size={14} className="text-[#FF2020]" />
              <span>Custom Expiration Timers & Whitelists</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Manual Upgrade Requests History (Part 16) */}
      <div className="glass-card rounded-2xl p-6 border border-white/10">
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2">
            <Clock size={18} className="text-[#FF2020]" />
            <h3 className="text-base font-bold text-white">Your Upgrade Applications</h3>
          </div>
          {isFreePlan && (
            <Button variant="secondary" size="sm" onClick={() => setUpgradeModalOpen(true)}>
              Submit New Request
            </Button>
          )}
        </div>

        {loadingRequests ? (
          <div className="text-center py-6 text-xs text-[#888888] font-mono">Loading requests...</div>
        ) : requests.length === 0 ? (
          <p className="text-xs text-[#888888] py-6 text-center">
            No upgrade requests submitted yet. Click "Request Premium Upgrade" to initiate verification with the administrator.
          </p>
        ) : (
          <div className="divide-y divide-white/5 font-mono text-xs">
            {requests.map((req) => (
              <div key={req.id} className="py-3 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{req.requestedPlan}</span>
                    <span className="text-[#888888]">({req.duration})</span>
                    {req.status === 'pending' && <Badge variant="amber">PENDING REVIEW</Badge>}
                    {req.status === 'approved' && <Badge variant="green">APPROVED</Badge>}
                    {req.status === 'rejected' && <Badge variant="red">REJECTED</Badge>}
                  </div>
                  {req.paymentReference && (
                    <p className="text-[11px] text-[#666666] mt-0.5">Ref: {req.paymentReference}</p>
                  )}
                  {req.message && (
                    <p className="text-[11px] text-[#888888] mt-0.5 font-sans">{req.message}</p>
                  )}
                </div>
                <div className="text-right text-[11px] text-[#666666]">
                  {new Date(req.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Manual Upgrade Modal (Part 16) */}
      <Modal
        isOpen={upgradeModalOpen}
        onClose={() => {
          setUpgradeModalOpen(false);
          setSuccessMsg(false);
        }}
        title="Submit Premium Upgrade Request"
      >
        {successMsg ? (
          <div className="text-center py-4 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 size={28} />
            </div>
            <h4 className="text-lg font-bold text-white">Application Received!</h4>
            <p className="text-xs text-[#888888]">
              The platform administrator has been notified. Once approved, your account email ({currentUser?.email}) will automatically unlock Premium privileges.
            </p>
            <Button
              variant="secondary"
              className="w-full"
              onClick={() => {
                setUpgradeModalOpen(false);
                setSuccessMsg(false);
              }}
            >
              Done
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmitRequest} className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-950/40 text-red-400 text-xs border border-red-500/40">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1">
                Verified Account Email
              </label>
              <input
                type="text"
                disabled
                value={currentUser?.email || ''}
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-[#888888] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1">
                Select Premium Duration *
              </label>
              <select
                value={selectedPlan}
                onChange={(e) => setSelectedPlan(e.target.value)}
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:border-[#FF2020]"
              >
                <option value="Premium 30 Days">Premium 30 Days</option>
                <option value="Premium 90 Days">Premium 90 Days</option>
                <option value="Premium 180 Days">Premium 180 Days</option>
                <option value="Premium 365 Days">Premium 365 Days</option>
                <option value="Lifetime Premium">Permanent Lifetime Premium</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1">
                Payment Reference / Transaction ID (Optional)
              </label>
              <input
                type="text"
                value={paymentRef}
                onChange={(e) => setPaymentRef(e.target.value)}
                placeholder="e.g. TX-99214 or Discord Invoice ID"
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:border-[#FF2020]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#aaaaaa] mb-1">
                Note / Message for Administrator
              </label>
              <textarea
                rows={2}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Software requirements, planned user base, or contact handle"
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white focus:border-[#FF2020]"
              />
            </div>

            <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setUpgradeModalOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
                <Send size={14} />
                <span>Submit Request</span>
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
