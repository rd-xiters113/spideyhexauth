import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  getUpgradeRequests,
  adminResolveUpgradeRequest,
} from '../shared/DatabaseService';
import { UpgradeRequestItem } from '../shared/Types';
import { Button, Badge } from '../shared/Components/CommonUI';
import { Zap, Check, X, Clock, AlertCircle } from 'lucide-react';

export const SubscriptionManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const [requests, setRequests] = useState<UpgradeRequestItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    try {
      setLoading(true);
      const items = await getUpgradeRequests(undefined, true);
      setRequests(items);
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  };

  const handleResolve = async (req: UpgradeRequestItem, approve: boolean) => {
    if (!currentUser) return;
    setProcessingId(req.id);
    try {
      let days = 90;
      if (req.duration.includes('30')) days = 30;
      else if (req.duration.includes('90')) days = 90;
      else if (req.duration.includes('180')) days = 180;
      else if (req.duration.includes('365')) days = 365;
      else if (req.duration.toLowerCase().includes('lifetime')) days = -1;

      await adminResolveUpgradeRequest(
        currentUser.uid,
        currentUser.email || '',
        req.id,
        approve,
        req.email,
        days
      );
      await loadRequests();
    } catch (err: any) {
      alert(err.message || 'Error processing request');
    } finally {
      setProcessingId(null);
    }
  };

  const pendingRequests = requests.filter((r) => r.status === 'pending');
  const resolvedRequests = requests.filter((r) => r.status !== 'pending');

  return (
    <div className="space-y-8">
      <div className="pb-4 border-b border-white/10">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <Zap className="text-[#FF2020]" />
          <span>Manual Upgrade Requests & Verification</span>
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Review developer submitted payment proofs and approve Premium status with one click.
        </p>
      </div>

      {/* Pending Requests */}
      <div className="glass-card rounded-2xl p-6 border border-white/10">
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Clock size={16} className="text-amber-400" />
            <span>Pending Review ({pendingRequests.length})</span>
          </h3>
        </div>

        {loading ? (
          <div className="text-center py-8 text-xs font-mono text-[#888888]">Loading requests...</div>
        ) : pendingRequests.length === 0 ? (
          <p className="text-xs text-[#666666] py-8 text-center font-mono">
            No pending upgrade requests awaiting verification.
          </p>
        ) : (
          <div className="space-y-3 font-mono text-xs">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                className="p-4 rounded-xl bg-[#111111] border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{req.email}</span>
                    <Badge variant="amber">PENDING</Badge>
                    <span className="text-[#FF2020] font-bold">[{req.duration}]</span>
                  </div>
                  {req.paymentReference && (
                    <p className="text-xs text-emerald-400 mt-1">
                      Payment Ref: <strong className="select-all">{req.paymentReference}</strong>
                    </p>
                  )}
                  {req.message && (
                    <p className="text-xs text-[#888888] mt-1 font-sans">{req.message}</p>
                  )}
                  <span className="text-[10px] text-[#555555] block mt-1">
                    Submitted: {new Date(req.createdAt).toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => handleResolve(req, true)}
                    isLoading={processingId === req.id}
                  >
                    <Check size={14} />
                    <span>Approve & Grant</span>
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => handleResolve(req, false)}
                    disabled={processingId === req.id}
                  >
                    <X size={14} />
                    <span>Reject</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Resolved History */}
      <div className="glass-card rounded-2xl p-6 border border-white/10">
        <h3 className="text-base font-bold text-white mb-4">Resolved Request History</h3>
        {resolvedRequests.length === 0 ? (
          <p className="text-xs text-[#666666] py-6 text-center font-mono">No past request records.</p>
        ) : (
          <div className="divide-y divide-white/5 font-mono text-xs">
            {resolvedRequests.map((r) => (
              <div key={r.id} className="py-3 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-white font-bold">{r.email}</span>
                    <span className="text-[#888888]">({r.duration})</span>
                    <Badge variant={r.status === 'approved' ? 'green' : 'red'}>
                      {r.status.toUpperCase()}
                    </Badge>
                  </div>
                  {r.reviewedBy && (
                    <span className="text-[10px] text-[#666666]">
                      Reviewed by {r.reviewedBy} on {new Date(r.reviewedAt || r.createdAt).toLocaleDateString()}
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-[#555555]">
                  {new Date(r.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
