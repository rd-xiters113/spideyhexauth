import React, { useEffect, useState } from 'react';
import { getResellers } from '../shared/DatabaseService';
import { ResellerItem } from '../shared/Types';
import { Badge } from '../shared/Components/CommonUI';
import { Users } from 'lucide-react';

export const ResellersManagement: React.FC = () => {
  const [resellers, setResellers] = useState<ResellerItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getResellers(undefined, true).then((items) => {
      setResellers(items);
      setLoading(false);
    });
  }, []);

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-white/10">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <Users className="text-[#FF2020]" />
          <span>Platform Reseller Oversight</span>
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Monitor all delegated distributor partnerships, generation limits, and software permissions.
        </p>
      </div>

      {loading ? (
        <div className="text-center py-20 text-xs font-mono text-[#888888]">Loading resellers...</div>
      ) : resellers.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10">
          <p className="text-xs text-[#888888]">No resellers registered across the platform.</p>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Reseller</th>
                <th className="py-3.5 px-4">Email</th>
                <th className="py-3.5 px-4">App ID</th>
                <th className="py-3.5 px-4">Owner ID</th>
                <th className="py-3.5 px-4">Quota (Used/Total)</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {resellers.map((r) => (
                <tr key={r.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 font-bold text-white">{r.resellerUsername}</td>
                  <td className="py-3 px-4 text-[#888888]">{r.resellerEmail}</td>
                  <td className="py-3 px-4 text-[#aaaaaa]">{r.appId}</td>
                  <td className="py-3 px-4 text-[#666666] truncate max-w-[100px]">{r.ownerId}</td>
                  <td className="py-3 px-4 text-white">
                    {r.keysUsed} / {r.keysQuota} keys
                  </td>
                  <td className="py-3 px-4">
                    <Badge variant={r.status === 'active' ? 'green' : 'red'}>
                      {r.status.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-[#666666]">
                    {new Date(r.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
