import { createRoot } from 'react-dom/client';
import { AuthProvider } from '../shared/AuthContext';
import { AdminApp } from './AdminApp';
import '../index.css';

createRoot(document.getElementById('root')!).render(
  <AuthProvider>
    <AdminApp />
  </AuthProvider>
);
