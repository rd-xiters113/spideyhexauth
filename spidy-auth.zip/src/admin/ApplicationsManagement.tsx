import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  getApplications,
  deleteApplication,
} from '../shared/DatabaseService';
import { ApplicationItem } from '../shared/Types';
import { Badge, Button } from '../shared/Components/CommonUI';
import { Layers, Search, Trash2, Cpu, Eye, EyeOff } from 'lucide-react';

export const ApplicationsManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [visibleSecrets, setVisibleSecrets] = useState<Record<string, boolean>>({});

  useEffect(() => {
    loadApps();
  }, []);

  const loadApps = async () => {
    try {
      setLoading(true);
      const data = await getApplications(undefined, true);
      setApps(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (appId: string) => {
    if (!currentUser) return;
    if (!confirm(`Delete application ${appId}?`)) return;
    try {
      await deleteApplication(appId, currentUser.uid, currentUser.email || '');
      await loadApps();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const filteredApps = apps.filter((a) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      a.name.toLowerCase().includes(term) ||
      a.id.toLowerCase().includes(term) ||
      a.ownerEmail?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Layers className="text-[#FF2020]" />
            <span>Platform Software Applications</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Master registry of all developer applications, isolated client secrets, and version metadata.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 text-[#666666]" size={16} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search app name, ID, owner..."
            className="w-full bg-[#111111] border border-white/10 rounded-lg py-2 pl-9 pr-4 text-xs text-white font-mono placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
          />
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20 text-xs font-mono text-[#888888]">Loading applications...</div>
      ) : filteredApps.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10">
          <p className="text-xs text-[#888888]">No applications found.</p>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Application</th>
                <th className="py-3.5 px-4">Application ID</th>
                <th className="py-3.5 px-4">Owner Email</th>
                <th className="py-3.5 px-4">HWID Protection</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Created</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredApps.map((app) => (
                <tr key={app.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4">
                    <span className="font-bold text-white block">{app.name}</span>
                    <span className="text-[10px] text-[#888888]">v{app.version}</span>
                  </td>
                  <td className="py-3 px-4 text-[#aaaaaa] select-all">{app.id}</td>
                  <td className="py-3 px-4 text-[#888888]">{app.ownerEmail}</td>
                  <td className="py-3 px-4">
                    {app.hwidLockEnabled ? (
                      <span className="text-[#FF2020] text-[11px]">ENFORCED</span>
                    ) : (
                      <span className="text-[#666666] text-[11px]">DISABLED</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <Badge variant={app.status === 'active' ? 'green' : 'red'}>
                      {app.status.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-[#666666]">
                    {new Date(app.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleDelete(app.id)}
                      className="p-1 rounded bg-white/5 text-[#888888] hover:text-red-400"
                      title="Delete application"
                    >
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
