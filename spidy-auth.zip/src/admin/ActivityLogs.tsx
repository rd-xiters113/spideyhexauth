import React, { useEffect, useState } from 'react';
import { getActivityLogs } from '../shared/DatabaseService';
import { ActivityLogItem } from '../shared/Types';
import { Terminal, Search } from 'lucide-react';

export const ActivityLogs: React.FC = () => {
  const [logs, setLogs] = useState<ActivityLogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    getActivityLogs(100, undefined, true).then((items) => {
      setLogs(items);
      setLoading(false);
    });
  }, []);

  const filteredLogs = logs.filter((l) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      l.action.toLowerCase().includes(term) ||
      l.actorEmail.toLowerCase().includes(term) ||
      l.details.toLowerCase().includes(term) ||
      l.targetType.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Terminal className="text-[#FF2020]" />
            <span>Master Security & Audit Logs</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Tamper-evident audit trail capturing all administrative authorizations, key generation, and account mutations.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 text-[#666666]" size={16} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search action, email, target..."
            className="w-full bg-[#111111] border border-white/10 rounded-lg py-2 pl-9 pr-4 text-xs text-white font-mono placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
          />
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20 text-xs font-mono text-[#888888]">Loading audit trail...</div>
      ) : filteredLogs.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10">
          <p className="text-xs text-[#888888]">No matching security events found.</p>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">Action</th>
                <th className="py-3.5 px-4">Actor</th>
                <th className="py-3.5 px-4">Role</th>
                <th className="py-3.5 px-4">Target</th>
                <th className="py-3.5 px-4">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 text-[#666666] whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-bold text-white whitespace-nowrap">
                    <span className="text-[#FF2020] mr-1">&gt;</span>
                    {log.action}
                  </td>
                  <td className="py-3 px-4 text-[#aaaaaa]">{log.actorEmail}</td>
                  <td className="py-3 px-4 text-[10px] uppercase text-[#777777]">{log.actorRole}</td>
                  <td className="py-3 px-4 text-[#888888]">
                    {log.targetType} ({log.targetId?.substring(0, 8)}...)
                  </td>
                  <td className="py-3 px-4 text-[#bbbbbb] font-sans truncate max-w-sm">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
