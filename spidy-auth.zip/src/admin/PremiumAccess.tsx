import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  adminApprovePremium,
  adminRevokePremium,
  getPremiumAllowlist,
} from '../shared/DatabaseService';
import { PremiumAllowlistItem } from '../shared/Types';
import { Button, Badge } from '../shared/Components/CommonUI';
import {
  Sparkles,
  ShieldCheck,
  Mail,
  Clock,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Plus,
} from 'lucide-react';

export const PremiumAccess: React.FC = () => {
  const { currentUser } = useAuth();
  const [allowlist, setAllowlist] = useState<PremiumAllowlistItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [targetEmail, setTargetEmail] = useState('');
  const [durationPreset, setDurationPreset] = useState<string>('90');
  const [customDays, setCustomDays] = useState<number>(60);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    loadAllowlist();
  }, []);

  const loadAllowlist = async () => {
    try {
      setLoading(true);
      const data = await getPremiumAllowlist();
      setAllowlist(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setError(null);
    setSuccess(null);

    const email = targetEmail.trim().toLowerCase();
    if (!email) {
      setError('Please provide a valid user Gmail/account address.');
      return;
    }

    let days = parseInt(durationPreset, 10);
    if (durationPreset === 'custom') {
      days = customDays;
    }

    setSubmitting(true);
    try {
      await adminApprovePremium(
        currentUser.uid,
        currentUser.email || '',
        email,
        days
      );
      setSuccess(`Approved Premium access for ${email}!`);
      setTargetEmail('');
      await loadAllowlist();
    } catch (err: any) {
      setError(err.message || 'Failed to approve premium access');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRevoke = async (item: PremiumAllowlistItem) => {
    if (!currentUser) return;
    if (!confirm(`Revoke Premium access for ${item.email}?`)) return;
    try {
      await adminRevokePremium(currentUser.uid, currentUser.email || '', item.email);
      await loadAllowlist();
    } catch (err: any) {
      alert(err.message || 'Failed to revoke premium');
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="pb-4 border-b border-white/10">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <Sparkles className="text-[#FF2020]" />
          <span>Premium Email Allowlist Management</span>
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Approve, extend, or revoke verified developer email accounts to unlock unrestricted software licensing and quotas.
        </p>
      </div>

      {/* Approval Card (Part 14) */}
      <div className="glass-card rounded-2xl p-6 sm:p-8 border border-[#FF2020]/40 neon-glow-sm">
        <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
          <ShieldCheck size={18} className="text-[#FF2020]" />
          <span>Authorize Premium Subscription</span>
        </h3>
        <p className="text-xs text-[#888888] mb-6">
          Enter the user's Gmail address. The verified account will automatically upgrade to Premium and receive unlimited key quota upon next authentication.
        </p>

        {error && (
          <div className="p-3 mb-4 rounded-lg bg-red-950/40 text-red-400 text-xs border border-red-500/40 flex items-center gap-2">
            <AlertCircle size={16} />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3 mb-4 rounded-lg bg-emerald-950/40 text-emerald-400 text-xs border border-emerald-500/40 flex items-center gap-2">
            <CheckCircle2 size={16} />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleApprove} className="space-y-5">
          <div>
            <label className="block text-xs font-mono text-[#aaaaaa] mb-1.5 uppercase">
              User Gmail / Account Address *
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3 text-[#666666]" size={16} />
              <input
                type="email"
                required
                value={targetEmail}
                onChange={(e) => setTargetEmail(e.target.value)}
                placeholder="developer@gmail.com"
                className="w-full bg-[#0a0a0a] border border-white/15 rounded-xl py-2.5 pl-11 pr-4 text-sm text-white font-mono placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-[#aaaaaa] mb-2 uppercase">
              Select Subscription Duration
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
              {[
                { label: '30 Days', val: '30' },
                { label: '90 Days', val: '90' },
                { label: '180 Days', val: '180' },
                { label: '365 Days', val: '365' },
                { label: 'Lifetime', val: '-1' },
                { label: 'Custom', val: 'custom' },
              ].map((item) => (
                <button
                  type="button"
                  key={item.val}
                  onClick={() => setDurationPreset(item.val)}
                  className={`py-2 px-3 rounded-lg text-xs font-mono border font-medium transition-all ${
                    durationPreset === item.val
                      ? 'bg-[#FF2020] text-white border-[#FF2020] shadow-[0_0_12px_rgba(255,32,32,0.4)]'
                      : 'bg-[#111111] text-[#888888] border-white/10 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {durationPreset === 'custom' && (
              <div className="mt-3">
                <input
                  type="number"
                  min={1}
                  value={customDays}
                  onChange={(e) => setCustomDays(parseInt(e.target.value) || 1)}
                  placeholder="Enter number of custom days"
                  className="w-full max-w-xs bg-[#0a0a0a] border border-white/15 rounded-lg py-2 px-3 text-xs text-white font-mono focus:border-[#FF2020]"
                />
              </div>
            )}
          </div>

          <Button type="submit" variant="primary" size="lg" className="w-full font-mono py-3" isLoading={submitting}>
            <Sparkles size={16} />
            <span>APPROVE PREMIUM ACCESS</span>
          </Button>
        </form>
      </div>

      {/* Active Allowlist Table */}
      <div className="glass-card rounded-2xl p-6 border border-white/10">
        <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
          <ShieldCheck size={18} className="text-[#FF2020]" />
          <span>Active Approved Email Records</span>
        </h3>

        {loading ? (
          <div className="text-center py-8 text-xs font-mono text-[#888888]">Loading allowlist...</div>
        ) : allowlist.length === 0 ? (
          <p className="text-xs text-[#666666] py-8 text-center font-mono">
            No emails currently registered in the premium allowlist.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
                <tr>
                  <th className="py-3 px-4">Authorized Email</th>
                  <th className="py-3 px-4">Duration</th>
                  <th className="py-3 px-4">Approved By</th>
                  <th className="py-3 px-4">Expires At</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {allowlist.map((item) => (
                  <tr key={item.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4 font-bold text-white">{item.email}</td>
                    <td className="py-3 px-4 text-[#aaaaaa]">
                      {item.durationDays === -1 ? 'Lifetime' : `${item.durationDays} Days`}
                    </td>
                    <td className="py-3 px-4 text-[#777777]">{item.approvedBy}</td>
                    <td className="py-3 px-4 text-[#888888]">
                      {item.expiresAt ? new Date(item.expiresAt).toLocaleDateString() : 'Permanent'}
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={item.status === 'active' ? 'green' : 'red'}>
                        {item.status.toUpperCase()}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {item.status === 'active' && (
                        <button
                          onClick={() => handleRevoke(item)}
                          className="px-2.5 py-1 rounded bg-white/5 hover:bg-red-950/40 text-xs text-[#888888] hover:text-red-400 transition-colors"
                        >
                          Revoke
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
