import React, { useEffect, useState } from 'react';
import { StatCard, Badge, Button } from '../shared/Components/CommonUI';
import {
  getAllUsers,
  getApplications,
  getLicenseKeys,
  getResellers,
  getPremiumAllowlist,
  getActivityLogs,
} from '../shared/DatabaseService';
import {
  UserProfile,
  ApplicationItem,
  LicenseKeyItem,
  ResellerItem,
  PremiumAllowlistItem,
  ActivityLogItem,
} from '../shared/Types';
import {
  Users,
  Layers,
  KeyRound,
  ShieldCheck,
  Zap,
  Clock,
  Sparkles,
  ArrowRight,
  Terminal,
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [keys, setKeys] = useState<LicenseKeyItem[]>([]);
  const [resellers, setResellers] = useState<ResellerItem[]>([]);
  const [allowlist, setAllowlist] = useState<PremiumAllowlistItem[]>([]);
  const [logs, setLogs] = useState<ActivityLogItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAllStats();
  }, []);

  const loadAllStats = async () => {
    try {
      setLoading(true);
      const [u, a, k, r, p, l] = await Promise.all([
        getAllUsers(),
        getApplications(undefined, true),
        getLicenseKeys(undefined, undefined, true),
        getResellers(undefined, true),
        getPremiumAllowlist(),
        getActivityLogs(15, undefined, true),
      ]);
      setUsers(u);
      setApps(a);
      setKeys(k);
      setResellers(r);
      setAllowlist(p);
      setLogs(l);
    } catch (e) {
      console.error('Failed to load admin stats:', e);
    } finally {
      setLoading(false);
    }
  };

  const totalUsers = users.length;
  const premiumUsers = users.filter((u) => u.plan === 'PREMIUM').length;
  const freeUsers = users.filter((u) => u.plan === 'FREE').length;
  const activeKeys = keys.filter((k) => k.status === 'active').length;
  const totalKeysGenerated = users.reduce((acc, u) => acc + (u.keysUsed || 0), 0);

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FF2020] animate-pulse" />
            <h2 className="text-2xl font-extrabold text-white font-mono tracking-tight">
              Platform Executive Dashboard
            </h2>
          </div>
          <p className="text-xs text-[#888888] mt-1">
            Real-time telemetry, user management, and security oversight across all applications.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="secondary" size="sm" onClick={() => loadAllStats()}>
            <span>Refresh Live Stats</span>
          </Button>
          <Button variant="primary" size="sm" onClick={() => onNavigate('premium-access')}>
            <Sparkles size={14} />
            <span>Approve Premium Email</span>
          </Button>
        </div>
      </div>

      {/* Primary Statistics Grid (Part 12) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          title="Total Registered Users"
          value={totalUsers}
          subtitle="All developer accounts"
          icon={Users}
          badge="DATABASE"
          badgeColor="blue"
        />
        <StatCard
          title="Total Applications"
          value={apps.length}
          subtitle="Client software products"
          icon={Layers}
          badge="ACTIVE APPS"
          badgeColor="red"
        />
        <StatCard
          title="Total Generated Keys"
          value={totalKeysGenerated || keys.length}
          subtitle="Lifetime license keys"
          icon={KeyRound}
          badge="METERED"
          badgeColor="amber"
        />
        <StatCard
          title="Active Client Licenses"
          value={activeKeys}
          subtitle="Currently authorized"
          icon={ShieldCheck}
          badge="HWID BOUND"
          badgeColor="green"
        />
      </div>

      {/* Secondary Tiers Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <StatCard
          title="Premium Subscriptions"
          value={premiumUsers}
          subtitle="Admin approved tier"
          icon={Zap}
          badge="UNLIMITED"
          badgeColor="red"
        />
        <StatCard
          title="Starter Free Users"
          value={freeUsers}
          subtitle="50 keys lifetime quota"
          icon={Clock}
          badge="QUOTA 50"
          badgeColor="gray"
        />
        <StatCard
          title="App Resellers"
          value={resellers.length}
          subtitle="Delegated distributors"
          icon={Users}
          badge="NETWORK"
          badgeColor="blue"
        />
      </div>

      {/* Live Data Streams (Part 12: Recent Registrations, Keys, Activations, Activity) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left: Recent User Registrations & Premium Activations */}
        <div className="glass-card rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Users size={16} className="text-[#FF2020]" />
              <span>Recent Developer Accounts</span>
            </h3>
            <button
              onClick={() => onNavigate('users')}
              className="text-xs text-[#FF2020] hover:underline font-mono inline-flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight size={12} />
            </button>
          </div>

          {users.length === 0 ? (
            <p className="text-xs text-[#888888] py-8 text-center">No users registered yet.</p>
          ) : (
            <div className="divide-y divide-white/5 font-mono text-xs">
              {users.slice(0, 5).map((u) => (
                <div key={u.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-bold">{u.displayName}</span>
                      <span className="text-[11px] text-[#888888]">({u.email})</span>
                      {u.plan === 'PREMIUM' ? (
                        <Badge variant="red">PREMIUM</Badge>
                      ) : (
                        <Badge variant="gray">FREE</Badge>
                      )}
                    </div>
                    <span className="text-[10px] text-[#666666]">
                      Keys Used: {u.keysUsed || 0} / {u.maxKeysQuota || 50}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#666666]">
                    {new Date(u.createdAt).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right: Master Security & Telemetry Stream */}
        <div className="glass-card rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Terminal size={16} className="text-[#FF2020]" />
              <span>Platform Audit Trail</span>
            </h3>
            <button
              onClick={() => onNavigate('activity-logs')}
              className="text-xs text-[#FF2020] hover:underline font-mono inline-flex items-center gap-1"
            >
              <span>View Full Audit</span>
              <ArrowRight size={12} />
            </button>
          </div>

          {logs.length === 0 ? (
            <p className="text-xs text-[#888888] py-8 text-center">No audit logs recorded yet.</p>
          ) : (
            <div className="space-y-3 font-mono text-xs">
              {logs.slice(0, 5).map((log) => (
                <div key={log.id} className="border-l-2 border-[#FF2020] pl-3 py-0.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-[11px]">{log.action}</span>
                    <span className="text-[10px] text-[#666666]">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[#888888] text-[11px] truncate mt-0.5 font-sans">{log.details}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
