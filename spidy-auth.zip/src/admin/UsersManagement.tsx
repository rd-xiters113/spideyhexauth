import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  getAllUsers,
  adminUpdateUserStatus,
  adminApprovePremium,
  adminRevokePremium,
  getActivityLogs,
} from '../shared/DatabaseService';
import { UserProfile, ActivityLogItem } from '../shared/Types';
import { Button, Modal, Badge } from '../shared/Components/CommonUI';
import {
  Users,
  Search,
  Shield,
  Ban,
  CheckCircle,
  Copy,
  Check,
  Eye,
  Sparkles,
  RotateCcw,
} from 'lucide-react';

export const UsersManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Inspector Modal
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [userLogs, setUserLogs] = useState<ActivityLogItem[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const data = await getAllUsers();
      setUsers(data);
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async (user: UserProfile) => {
    if (!currentUser) return;
    const newStatus = user.accountStatus === 'active' ? 'suspended' : 'active';
    if (!confirm(`Are you sure you want to change account status for ${user.email} to ${newStatus}?`)) return;

    try {
      await adminUpdateUserStatus(currentUser.uid, currentUser.email || '', user.id, newStatus);
      await loadUsers();
    } catch (err: any) {
      alert(err.message || 'Failed to update status');
    }
  };

  const handleQuickGrantPremium = async (user: UserProfile) => {
    if (!currentUser) return;
    if (!confirm(`Grant 90 Days Premium to ${user.email}?`)) return;
    try {
      await adminApprovePremium(currentUser.uid, currentUser.email || '', user.email, 90);
      alert(`Premium granted to ${user.email}`);
      await loadUsers();
    } catch (e: any) {
      alert(e.message || 'Error granting premium');
    }
  };

  const handleQuickRevokePremium = async (user: UserProfile) => {
    if (!currentUser) return;
    if (!confirm(`Revoke Premium access for ${user.email}? Account will return to Free.`)) return;
    try {
      await adminRevokePremium(currentUser.uid, currentUser.email || '', user.email);
      alert(`Premium revoked for ${user.email}`);
      await loadUsers();
    } catch (e: any) {
      alert(e.message || 'Error revoking premium');
    }
  };

  const inspectUser = async (user: UserProfile) => {
    setSelectedUser(user);
    setLoadingLogs(true);
    try {
      const logs = await getActivityLogs(20, user.id);
      setUserLogs(logs);
    } catch (e) {
      console.warn(e);
    } finally {
      setLoadingLogs(false);
    }
  };

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredUsers = users.filter((u) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      u.email.toLowerCase().includes(term) ||
      u.displayName.toLowerCase().includes(term) ||
      u.id.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <Users className="text-[#FF2020]" />
            <span>Developer Users Management</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Supervise accounts, inspect activity streams, toggle suspension, and manage quotas.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 text-[#666666]" size={16} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search email, name, UID..."
            className="w-full bg-[#111111] border border-white/10 rounded-lg py-2 pl-9 pr-4 text-xs text-white font-mono placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
          />
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20 text-xs font-mono text-[#888888]">Loading accounts...</div>
      ) : filteredUsers.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10">
          <p className="text-xs text-[#888888]">No matching users found.</p>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">User / Email</th>
                  <th className="py-3.5 px-4">User ID</th>
                  <th className="py-3.5 px-4">Plan & Quota</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Role</th>
                  <th className="py-3.5 px-4">Registered</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">{u.displayName}</div>
                      <div className="text-[11px] text-[#888888]">{u.email}</div>
                    </td>
                    <td className="py-3 px-4 text-[#aaaaaa]">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate max-w-[120px]">{u.id}</span>
                        <button
                          onClick={() => copyText(u.id, u.id)}
                          className="text-[#666666] hover:text-white"
                        >
                          {copiedId === u.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        {u.plan === 'PREMIUM' ? (
                          <Badge variant="red">PREMIUM</Badge>
                        ) : (
                          <Badge variant="gray">FREE</Badge>
                        )}
                        <span className="text-[#888888] text-[11px]">
                          {u.keysUsed || 0}/{u.maxKeysQuota || 50}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={u.accountStatus === 'active' ? 'green' : 'red'}>
                        {u.accountStatus?.toUpperCase() || 'ACTIVE'}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-[#888888] uppercase text-[10px]">
                      {u.role}
                    </td>
                    <td className="py-3 px-4 text-[#666666]">
                      {new Date(u.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => inspectUser(u)}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#aaaaaa] hover:text-white"
                          title="Inspect Activity"
                        >
                          <Eye size={13} />
                        </button>
                        {u.plan === 'FREE' ? (
                          <button
                            onClick={() => handleQuickGrantPremium(u)}
                            className="p-1.5 rounded-lg bg-[#FF2020]/15 hover:bg-[#FF2020]/25 text-[#FF2020]"
                            title="Grant 90d Premium"
                          >
                            <Sparkles size={13} />
                          </button>
                        ) : (
                          <button
                            onClick={() => handleQuickRevokePremium(u)}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-amber-400"
                            title="Revoke Premium"
                          >
                            <RotateCcw size={13} />
                          </button>
                        )}
                        <button
                          onClick={() => handleToggleStatus(u)}
                          className={`p-1.5 rounded-lg ${
                            u.accountStatus === 'active'
                              ? 'bg-red-950/40 hover:bg-red-900/50 text-red-400'
                              : 'bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-400'
                          }`}
                          title={u.accountStatus === 'active' ? 'Suspend Account' : 'Reactivate Account'}
                        >
                          <Ban size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Inspector Modal */}
      <Modal
        isOpen={!!selectedUser}
        onClose={() => setSelectedUser(null)}
        title={`User Inspector: ${selectedUser?.displayName}`}
        maxWidth="max-w-xl"
      >
        {selectedUser && (
          <div className="space-y-4 font-mono text-xs">
            <div className="p-3.5 rounded-xl bg-[#0a0a0a] border border-white/5 space-y-2">
              <div className="flex justify-between">
                <span className="text-[#666666]">Email:</span>
                <span className="text-white">{selectedUser.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#666666]">User ID:</span>
                <span className="text-white select-all">{selectedUser.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#666666]">Plan:</span>
                <span className="text-[#FF2020] font-bold">{selectedUser.plan}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#666666]">Keys Used / Quota:</span>
                <span className="text-white">{selectedUser.keysUsed || 0} / {selectedUser.maxKeysQuota}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#666666]">Status:</span>
                <span className={selectedUser.accountStatus === 'active' ? 'text-emerald-400' : 'text-red-400'}>
                  {selectedUser.accountStatus.toUpperCase()}
                </span>
              </div>
            </div>

            <h4 className="text-white font-bold pt-2">Recent Security Telemetry:</h4>
            {loadingLogs ? (
              <div className="text-center py-4 text-[#888888]">Loading activity...</div>
            ) : userLogs.length === 0 ? (
              <p className="text-[#666666] text-center py-4">No recent activity found.</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {userLogs.map((log) => (
                  <div key={log.id} className="p-2 rounded bg-[#0f0f0f] border border-white/5">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-[#FF2020] font-bold">{log.action}</span>
                      <span className="text-[#666666]">{new Date(log.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-[#888888] text-[10px] mt-0.5 font-sans">{log.details}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};
