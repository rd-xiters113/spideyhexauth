import React, { useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import { AdminLogin } from './AdminLogin';
import { AdminDashboard } from './AdminDashboard';
import { UsersManagement } from './UsersManagement';
import { ApplicationsManagement } from './ApplicationsManagement';
import { LicenseManagement } from './LicenseManagement';
import { CredentialsManagement } from './CredentialsManagement';
import { PremiumAccess } from './PremiumAccess';
import { SubscriptionManagement } from './SubscriptionManagement';
import { ResellersManagement } from './ResellersManagement';
import { ActivityLogs } from './ActivityLogs';
import { PlatformSettings } from './PlatformSettings';
import { SpidyLogo } from '../shared/Components/SpidyLogo';
import { Badge, Button } from '../shared/Components/CommonUI';
import {
  LayoutDashboard,
  Users,
  Layers,
  KeyRound,
  UserCheck,
  Sparkles,
  Zap,
  Network,
  Terminal,
  Settings as SettingsIcon,
  LogOut,
  ShieldCheck,
  ShieldAlert,
  Menu,
  X,
  ExternalLink,
} from 'lucide-react';

interface AdminAppProps {
  onExitToUser?: () => void;
}

export const AdminApp: React.FC<AdminAppProps> = ({ onExitToUser }) => {
  const { currentUser, userProfile, loading, isAdmin, isSuperAdmin, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#060606] flex items-center justify-center cyber-grid">
        <div className="flex flex-col items-center gap-3">
          <SpidyLogo size="lg" />
          <div className="w-6 h-6 border-2 border-[#FF2020] border-t-transparent rounded-full animate-spin mt-4" />
          <span className="text-xs text-[#888888] font-mono">Verifying Administrative Signature...</span>
        </div>
      </div>
    );
  }

  // If not logged in at all, render AdminLogin
  if (!currentUser) {
    return <AdminLogin />;
  }

  // If logged in but NOT an authorized administrator, reject access (Part 11 requirement)
  if (!isAdmin && !isSuperAdmin) {
    return (
      <div className="min-h-screen bg-[#080808] flex items-center justify-center p-4 cyber-grid">
        <div className="w-full max-w-md glass-card rounded-2xl p-8 border border-red-500/40 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-red-950/40 border border-red-500/50 text-red-400 flex items-center justify-center mx-auto">
            <ShieldAlert size={32} />
          </div>
          <h2 className="text-xl font-bold text-white">Access Denied: Non-Admin Account</h2>
          <p className="text-xs text-[#aaaaaa] leading-relaxed">
            Your account (<span className="text-white font-mono">{currentUser.email}</span>) is not authorized as an administrator on this platform. Admin roles are enforced server-side.
          </p>
          <div className="pt-2 flex flex-col gap-2">
            {onExitToUser ? (
              <button
                onClick={onExitToUser}
                className="py-2.5 px-4 rounded-lg bg-[#FF2020] hover:bg-[#ff3838] text-white text-xs font-mono font-bold transition-all cursor-pointer"
              >
                Return to Developer Portal
              </button>
            ) : (
              <a
                href="/"
                className="py-2.5 px-4 rounded-lg bg-[#FF2020] hover:bg-[#ff3838] text-white text-xs font-mono font-bold transition-all text-center"
              >
                Return to Developer Portal
              </a>
            )}
            <Button variant="ghost" size="sm" onClick={() => logout()}>
              Switch Account
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Sidebar items for Admin Panel (Part 11)
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'Users Management', icon: Users },
    { id: 'applications', label: 'Applications', icon: Layers },
    { id: 'licenses', label: 'License Keys', icon: KeyRound },
    { id: 'credentials', label: 'User & Passwords', icon: UserCheck },
    { id: 'premium-access', label: 'Premium Access', icon: Sparkles },
    { id: 'subscriptions', label: 'Subscriptions', icon: Zap },
    { id: 'resellers', label: 'Resellers', icon: Network },
    { id: 'activity-logs', label: 'Activity Logs', icon: Terminal },
    { id: 'settings', label: 'Platform Settings', icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen bg-[#060606] text-white flex flex-col antialiased">
      {/* Top Admin Navbar */}
      <header className="h-16 border-b border-[#FF2020]/30 bg-[#0a0a0a]/90 backdrop-blur-md sticky top-0 z-40 px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 rounded-lg text-[#888888] hover:text-white lg:hidden hover:bg-white/5"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <SpidyLogo size="md" />
          <span className="hidden sm:inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FF2020]/20 text-[#FF2020] border border-[#FF2020]/40">
            ADMIN PANEL
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Back to User Site */}
          {onExitToUser ? (
            <button
              onClick={onExitToUser}
              className="text-xs font-mono text-[#888888] hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              <span>&larr; User Portal</span>
            </button>
          ) : (
            <a
              href="/"
              className="text-xs font-mono text-[#888888] hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
            >
              <span>User Portal</span>
              <ExternalLink size={12} />
            </a>
          )}

          {/* Admin Badge */}
          <Badge variant="red">
            {isSuperAdmin ? 'SUPER ADMIN' : 'ADMINISTRATOR'}
          </Badge>

          {/* Logout */}
          <button
            onClick={() => logout()}
            className="p-1.5 rounded-lg text-[#888888] hover:text-red-400 hover:bg-white/5 transition-colors"
            title="Sign Out"
          >
            <LogOut size={16} />
          </button>
        </div>
      </header>

      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Desktop Sidebar (Part 11) */}
        <aside className="w-64 border-r border-[#FF2020]/20 bg-[#090909] p-4 hidden lg:flex flex-col justify-between shrink-0">
          <div className="space-y-1">
            <div className="px-3 py-2 text-[10px] font-mono text-[#FF2020] uppercase tracking-wider font-bold">
              Master Control
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-mono font-medium transition-all ${
                    isActive
                      ? 'bg-[#FF2020] text-white shadow-[0_0_15px_rgba(255,32,32,0.4)] font-bold'
                      : 'text-[#888888] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon size={16} className={isActive ? 'text-white' : 'text-[#777777]'} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="p-3 rounded-xl bg-[#121212] border border-white/5 text-[11px] font-mono text-[#666666]">
            <div>Admin: {currentUser?.email?.split('@')[0]}</div>
            <div className="text-[10px] text-[#444444] mt-0.5">Role: {isSuperAdmin ? 'Super Admin' : 'Admin'}</div>
          </div>
        </aside>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative w-72 bg-[#0c0c0c] border-r border-white/10 p-5 flex flex-col justify-between z-10">
              <div className="space-y-2">
                <div className="flex items-center justify-between pb-4 border-b border-white/10">
                  <SpidyLogo size="sm" />
                  <button onClick={() => setMobileMenuOpen(false)} className="text-[#888888]">
                    <X size={20} />
                  </button>
                </div>

                <div className="pt-4 space-y-1">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-mono transition-all ${
                          isActive
                            ? 'bg-[#FF2020] text-white font-bold'
                            : 'text-[#888888] hover:text-white'
                        }`}
                      >
                        <Icon size={16} />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <Button variant="danger" size="sm" className="w-full" onClick={() => logout()}>
                <LogOut size={14} />
                <span>Sign Out</span>
              </Button>
            </div>
          </div>
        )}

        {/* Main Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'dashboard' && <AdminDashboard onNavigate={(t) => setActiveTab(t)} />}
          {activeTab === 'users' && <UsersManagement />}
          {activeTab === 'applications' && <ApplicationsManagement />}
          {activeTab === 'licenses' && <LicenseManagement />}
          {activeTab === 'credentials' && <CredentialsManagement />}
          {activeTab === 'premium-access' && <PremiumAccess />}
          {activeTab === 'subscriptions' && <SubscriptionManagement />}
          {activeTab === 'resellers' && <ResellersManagement />}
          {activeTab === 'activity-logs' && <ActivityLogs />}
          {activeTab === 'settings' && <PlatformSettings />}
        </main>
      </div>
    </div>
  );
};
