import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import { getCredentials, revokeCredential, deleteCredential } from '../shared/DatabaseService';
import { CredentialItem } from '../shared/Types';
import { Badge } from '../shared/Components/CommonUI';
import { UserCheck, Trash2, Ban } from 'lucide-react';

export const CredentialsManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const [credentials, setCredentials] = useState<CredentialItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCreds();
  }, []);

  const loadCreds = async () => {
    try {
      setLoading(true);
      const data = await getCredentials(undefined, undefined, true);
      setCredentials(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleRevoke = async (id: string) => {
    if (!currentUser) return;
    if (!confirm('Admin suspend credential account?')) return;
    try {
      await revokeCredential(id, currentUser.uid, currentUser.email || '');
      await loadCreds();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleDelete = async (id: string) => {
    if (!currentUser) return;
    if (!confirm('Permanently delete credential?')) return;
    try {
      await deleteCredential(id, currentUser.uid, currentUser.email || '');
      await loadCreds();
    } catch (e: any) {
      alert(e.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-white/10">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <UserCheck className="text-[#FF2020]" />
          <span>Platform Application Credentials</span>
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Global oversight of client application accounts and hardware bindings across all registered software.
        </p>
      </div>

      {loading ? (
        <div className="text-center py-20 text-xs font-mono text-[#888888]">Loading credentials...</div>
      ) : credentials.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10">
          <p className="text-xs text-[#888888]">No application credentials registered.</p>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Username</th>
                <th className="py-3.5 px-4">App ID</th>
                <th className="py-3.5 px-4">Owner ID</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Hardware ID</th>
                <th className="py-3.5 px-4">Expires</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {credentials.map((cred) => (
                <tr key={cred.id} className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 font-bold text-white">{cred.username}</td>
                  <td className="py-3 px-4 text-[#aaaaaa]">{cred.appId}</td>
                  <td className="py-3 px-4 text-[#666666] truncate max-w-[100px]">{cred.ownerId}</td>
                  <td className="py-3 px-4">
                    <Badge variant={cred.status === 'active' ? 'green' : 'red'}>
                      {cred.status.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-[#FF2020] truncate max-w-[120px]">
                    {cred.currentHwid || 'Unbound'}
                  </td>
                  <td className="py-3 px-4 text-[#888888]">
                    {cred.expiresAt ? new Date(cred.expiresAt).toLocaleDateString() : 'Permanent'}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {cred.status === 'active' && (
                        <button
                          onClick={() => handleRevoke(cred.id)}
                          className="p-1 rounded bg-red-950/40 text-red-400"
                          title="Suspend"
                        >
                          <Ban size={13} />
                        </button>
                      )}
                      <button
                        onClick={() => handleDelete(cred.id)}
                        className="p-1 rounded bg-white/5 text-[#888] hover:text-red-400"
                        title="Delete"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
