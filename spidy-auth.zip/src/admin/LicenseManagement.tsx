import React, { useEffect, useState } from 'react';
import { useAuth } from '../shared/AuthContext';
import {
  getLicenseKeys,
  getApplications,
  getAllUsers,
  generateLicenseKey,
  updateLicenseStatus,
  resetLicenseHwid,
  deleteLicenseKey,
} from '../shared/DatabaseService';
import { LicenseKeyItem, ApplicationItem, UserProfile } from '../shared/Types';
import { Button, Modal, Badge } from '../shared/Components/CommonUI';
import {
  KeyRound,
  Plus,
  Search,
  Filter,
  Copy,
  Check,
  RotateCcw,
  Ban,
  Trash2,
  Cpu,
} from 'lucide-react';

export const LicenseManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const [keys, setKeys] = useState<LicenseKeyItem[]>([]);
  const [apps, setApps] = useState<ApplicationItem[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Admin Key Generation Modal (Part 15)
  const [modalOpen, setModalOpen] = useState(false);
  const [targetAppId, setTargetAppId] = useState('');
  const [targetOwnerId, setTargetOwnerId] = useState('');
  const [durationDays, setDurationDays] = useState(30);
  const [maxDevices, setMaxDevices] = useState(1);
  const [notes, setNotes] = useState('Admin Generated License');
  const [customKey, setCustomKey] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      setLoading(true);
      const [k, a, u] = await Promise.all([
        getLicenseKeys(undefined, undefined, true),
        getApplications(undefined, true),
        getAllUsers(),
      ]);
      setKeys(k);
      setApps(a);
      setUsers(u);
      if (a.length > 0 && !targetAppId) setTargetAppId(a[0].id);
      if (u.length > 0 && !targetOwnerId) setTargetOwnerId(u[0].id);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAdminGenerateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setSubmitting(true);
    try {
      const targetApp = apps.find((a) => a.id === targetAppId);
      const targetOwner = users.find((u) => u.id === targetOwnerId) || {
        id: currentUser.uid,
        email: currentUser.email || '',
      };

      await generateLicenseKey({
        ownerId: targetOwner.id,
        ownerEmail: targetOwner.email,
        appId: targetAppId,
        appName: targetApp?.name,
        type: 'key',
        durationDays,
        maxDevices,
        notes: notes.trim(),
        customKey: customKey.trim() || undefined,
      });

      setModalOpen(false);
      setCustomKey('');
      await loadAll();
    } catch (err: any) {
      alert(err.message || 'Key generation error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetHwid = async (keyId: string) => {
    if (!currentUser) return;
    if (!confirm('Admin reset HWID hardware lock?')) return;
    try {
      await resetLicenseHwid(keyId, currentUser.uid, currentUser.email || '');
      await loadAll();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleBan = async (keyId: string) => {
    if (!currentUser) return;
    const reason = prompt('Enter administrative ban reason:', 'Administrator security termination');
    if (!reason) return;
    try {
      await updateLicenseStatus(keyId, 'banned', currentUser.uid, currentUser.email || '', reason);
      await loadAll();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleDelete = async (keyId: string) => {
    if (!currentUser) return;
    if (!confirm('Delete license key from database?')) return;
    try {
      await deleteLicenseKey(keyId, currentUser.uid, currentUser.email || '');
      await loadAll();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const copyKey = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredKeys = keys.filter((k) => {
    if (statusFilter !== 'ALL' && k.status !== statusFilter) return false;
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      k.key.toLowerCase().includes(term) ||
      k.appId.toLowerCase().includes(term) ||
      k.ownerId.toLowerCase().includes(term) ||
      k.hwid?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
            <KeyRound className="text-[#FF2020]" />
            <span>Master Platform License Management</span>
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Global license key control, administrative key issuance, HWID hardware resets, and security bans.
          </p>
        </div>

        <Button variant="primary" size="md" onClick={() => setModalOpen(true)}>
          <Plus size={16} />
          <span>Admin License Generator</span>
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-2.5 text-[#666666]" size={16} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search license key, HWID, owner ID..."
            className="w-full bg-[#111111] border border-white/10 rounded-lg py-2 pl-9 pr-4 text-xs text-white font-mono placeholder-[#555555] focus:outline-none focus:border-[#FF2020]"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-[#111111] border border-white/10 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-[#FF2020] font-mono"
        >
          <option value="ALL">All License Statuses</option>
          <option value="unused">Unused</option>
          <option value="active">Active</option>
          <option value="expired">Expired</option>
          <option value="banned">Banned</option>
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="text-center py-20 text-xs font-mono text-[#888888]">Loading licenses...</div>
      ) : filteredKeys.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center border border-white/10">
          <p className="text-xs text-[#888888]">No matching license keys found.</p>
        </div>
      ) : (
        <div className="glass-card rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#121212] border-b border-white/10 text-[#888888] uppercase text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">License Key</th>
                  <th className="py-3.5 px-4">App ID</th>
                  <th className="py-3.5 px-4">Owner ID</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Duration</th>
                  <th className="py-3.5 px-4">HWID</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredKeys.map((item) => (
                  <tr key={item.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5 font-bold text-white">
                        <span>{item.key}</span>
                        <button onClick={() => copyKey(item.key, item.id)} className="text-[#666] hover:text-white">
                          {copiedId === item.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>
                      {item.notes && <span className="text-[10px] text-[#666666] block">{item.notes}</span>}
                    </td>
                    <td className="py-3 px-4 text-[#aaaaaa]">{item.appName || item.appId}</td>
                    <td className="py-3 px-4 text-[#777777] truncate max-w-[100px]">{item.ownerId}</td>
                    <td className="py-3 px-4">
                      <Badge variant={item.status === 'active' ? 'green' : item.status === 'banned' ? 'red' : 'gray'}>
                        {item.status.toUpperCase()}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-[#888888]">
                      {item.durationDays === -1 ? 'Lifetime' : `${item.durationDays}d`}
                    </td>
                    <td className="py-3 px-4">
                      {item.hwid ? (
                        <span className="text-[#FF2020] truncate max-w-[100px] block" title={item.hwid}>
                          {item.hwid}
                        </span>
                      ) : (
                        <span className="text-[#555555]">Unbound</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {item.hwid && (
                          <button
                            onClick={() => handleResetHwid(item.id)}
                            className="p-1 rounded bg-white/5 text-[#888] hover:text-white"
                            title="Reset HWID"
                          >
                            <RotateCcw size={12} />
                          </button>
                        )}
                        {item.status !== 'banned' && (
                          <button
                            onClick={() => handleBan(item.id)}
                            className="p-1 rounded bg-red-950/40 text-red-400"
                            title="Ban Key"
                          >
                            <Ban size={12} />
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="p-1 rounded bg-white/5 text-[#888] hover:text-red-400"
                          title="Delete"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Admin License Generator Modal (Part 15) */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Admin License Key Issuance">
        <form onSubmit={handleAdminGenerateKey} className="space-y-4 font-mono text-xs">
          <div>
            <label className="block text-[#aaaaaa] mb-1">Target Application *</label>
            <select
              value={targetAppId}
              onChange={(e) => setTargetAppId(e.target.value)}
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-white"
            >
              {apps.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.id})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[#aaaaaa] mb-1">Assign to Application Owner *</label>
            <select
              value={targetOwnerId}
              onChange={(e) => setTargetOwnerId(e.target.value)}
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-white"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.displayName} ({u.email})
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[#aaaaaa]">Duration / Validity (-1 = Lifetime)</label>
              <span className="text-[#FF2020] font-bold">
                {durationDays === -1 ? 'Lifetime' : `${durationDays} Days`}
              </span>
            </div>
            <div className="flex flex-wrap gap-1 mb-2">
              {[
                { label: '1d', val: 1 },
                { label: '7d', val: 7 },
                { label: '15d', val: 15 },
                { label: '30d', val: 30 },
                { label: '60d', val: 60 },
                { label: '90d', val: 90 },
                { label: '180d', val: 180 },
                { label: '365d', val: 365 },
                { label: 'Lifetime', val: -1 },
              ].map((p) => (
                <button
                  type="button"
                  key={p.val}
                  onClick={() => setDurationDays(p.val)}
                  className={`px-2 py-0.5 rounded text-[10px] border transition-all ${
                    durationDays === p.val
                      ? 'bg-[#FF2020] text-white border-[#FF2020]'
                      : 'bg-white/5 border-white/10 text-[#888] hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
            <input
              type="number"
              value={durationDays}
              onChange={(e) => setDurationDays(parseInt(e.target.value) || 1)}
              placeholder="Custom days (e.g. 45)"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-white"
            />
            <p className="text-[10px] text-[#888888] mt-1">
              When an end-user registers with this key, their account will inherit this exact duration ({durationDays === -1 ? 'Lifetime' : `${durationDays} Days`}).
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[#aaaaaa] mb-1">Max Devices</label>
              <input
                type="number"
                min={1}
                value={maxDevices}
                onChange={(e) => setMaxDevices(parseInt(e.target.value) || 1)}
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#aaaaaa] mb-1">Custom Key String (Optional)</label>
            <input
              type="text"
              value={customKey}
              onChange={(e) => setCustomKey(e.target.value)}
              placeholder="Leave blank for SPIDY-XXXX auto generation"
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-white"
            />
          </div>

          <div>
            <label className="block text-[#aaaaaa] mb-1">Admin Audit Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-white"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
            <Button type="button" variant="ghost" size="sm" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
              Issue License Key
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
