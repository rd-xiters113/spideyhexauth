import React, { useState } from 'react';
import { useAuth, BOOTSTRAP_SUPERADMIN_EMAIL } from '../shared/AuthContext';
import { logActivity } from '../shared/DatabaseService';
import { db } from '../shared/FirebaseConfig';
import { doc, setDoc } from 'firebase/firestore';
import { Button, Badge } from '../shared/Components/CommonUI';
import { Settings as SettingsIcon, ShieldCheck, UserPlus, Server, Lock } from 'lucide-react';

export const PlatformSettings: React.FC = () => {
  const { currentUser, isSuperAdmin } = useAuth();
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'admin' | 'superadmin'>('admin');
  const [submitting, setSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!isSuperAdmin) {
      alert('Only Super Administrators can appoint new administrators.');
      return;
    }
    const email = newAdminEmail.trim().toLowerCase();
    if (!email) return;

    setSubmitting(true);
    setStatusMsg(null);
    try {
      const adminId = 'adm_' + email.replace(/[^a-zA-Z0-9]/g, '_');
      await setDoc(doc(db, 'admins', adminId), {
        id: adminId,
        email,
        role: newAdminRole,
        addedAt: new Date().toISOString(),
        addedBy: currentUser.email,
      });

      await logActivity(
        currentUser.uid,
        currentUser.email || '',
        'superadmin',
        'APPOINT_ADMINISTRATOR',
        'Admin',
        adminId,
        `Assigned ${newAdminRole} role to ${email}`
      );

      setStatusMsg(`Successfully assigned ${newAdminRole} privilege to ${email}`);
      setNewAdminEmail('');
    } catch (e: any) {
      alert(e.message || 'Error appointing admin');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="pb-4 border-b border-white/10">
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
          <SettingsIcon className="text-[#FF2020]" />
          <span>Platform Security & Bootstrap Settings</span>
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Review server-side administrative bootstrap configuration, RBAC permissions, and engine health.
        </p>
      </div>

      {/* System Status */}
      <div className="glass-card rounded-2xl p-6 border border-white/10 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Server size={18} className="text-[#FF2020]" />
          <span>Platform Operational Status</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
          <div className="p-3.5 rounded-xl bg-[#0e0e0e] border border-white/5">
            <span className="text-[#666666] text-[10px] uppercase block mb-1">Database Engine</span>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-white font-bold">Firebase Enterprise</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#0e0e0e] border border-white/5">
            <span className="text-[#666666] text-[10px] uppercase block mb-1">Auth Subsystem</span>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-white font-bold">Firebase Identity</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#0e0e0e] border border-white/5">
            <span className="text-[#666666] text-[10px] uppercase block mb-1">REST API Gateway</span>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-white font-bold">Express v2.5 Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bootstrapped Super Admin Card (Part 20) */}
      <div className="glass-card rounded-2xl p-6 border border-white/10 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <ShieldCheck size={18} className="text-[#FF2020]" />
          <span>Initial Bootstrap Authorization</span>
        </h3>
        <p className="text-xs text-[#888888]">
          To avoid security vulnerabilities, Spidy Auth prohibits default passwords or automatic first-user promotions. The platform is anchored to a trusted server-side bootstrap administrator:
        </p>

        <div className="p-4 rounded-xl bg-[#0d0d0d] border border-[#FF2020]/30 font-mono text-xs flex items-center justify-between">
          <div>
            <span className="text-[#666666] text-[10px] uppercase block mb-1">Bootstrapped Authority</span>
            <span className="text-white font-bold">Root System Administrator (Secured)</span>
          </div>
          <Badge variant="red">SUPERADMIN ROOT</Badge>
        </div>
      </div>

      {/* Appoint Administrator (Super Admin only) */}
      {isSuperAdmin && (
        <div className="glass-card rounded-2xl p-6 border border-white/10 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <UserPlus size={18} className="text-[#FF2020]" />
            <span>Appoint Administrator (Super Admin Privilege)</span>
          </h3>
          <p className="text-xs text-[#888888]">
            Grant administrative privileges to trusted developer team members.
          </p>

          {statusMsg && (
            <div className="p-3 rounded-lg bg-emerald-950/40 text-emerald-400 text-xs border border-emerald-500/30">
              {statusMsg}
            </div>
          )}

          <form onSubmit={handleAddAdmin} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-mono text-[#aaaaaa] mb-1">
                  Team Member Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  placeholder="co-engineer@company.com"
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#aaaaaa] mb-1">Assigned Role</label>
                <select
                  value={newAdminRole}
                  onChange={(e) => setNewAdminRole(e.target.value as any)}
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono"
                >
                  <option value="admin">Administrator</option>
                  <option value="superadmin">Super Administrator</option>
                </select>
              </div>
            </div>

            <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
              <UserPlus size={14} />
              <span>Grant Administrative Access</span>
            </Button>
          </form>
        </div>
      )}
    </div>
  );
};
