import React from 'react';

interface SpidyLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const SpidyLogo: React.FC<SpidyLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const sizeMap = {
    sm: { icon: 24, font: 'text-base', sub: 'text-[9px]' },
    md: { icon: 34, font: 'text-xl', sub: 'text-[11px]' },
    lg: { icon: 46, font: 'text-2xl', sub: 'text-xs' },
    xl: { icon: 60, font: 'text-3xl', sub: 'text-sm' },
  };

  const dim = sizeMap[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Spider-inspired cyber technology icon */}
      <div className="relative flex items-center justify-center">
        <div className="absolute inset-0 bg-[#FF2020] opacity-25 blur-md rounded-full pointer-events-none" />
        <svg
          width={dim.icon}
          height={dim.icon}
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="relative drop-shadow-[0_0_12px_rgba(255,32,32,0.8)] transition-transform duration-300 hover:scale-105"
        >
          {/* Cyber Octagonal Core Shield */}
          <polygon
            points="32,4 52,14 58,34 50,54 32,60 14,54 6,34 12,14"
            fill="#120505"
            stroke="#FF2020"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />

          {/* Inner Cyber Web Nodes */}
          <line x1="32" y1="4" x2="32" y2="60" stroke="#FF2020" strokeWidth="1.2" strokeOpacity="0.4" />
          <line x1="6" y1="34" x2="58" y2="34" stroke="#FF2020" strokeWidth="1.2" strokeOpacity="0.4" />
          <line x1="12" y1="14" x2="50" y2="54" stroke="#FF2020" strokeWidth="1" strokeOpacity="0.3" />
          <line x1="52" y1="14" x2="14" y2="54" stroke="#FF2020" strokeWidth="1" strokeOpacity="0.3" />

          {/* Central Spider Abdomen & Eye Cluster */}
          <circle cx="32" cy="27" r="6" fill="#FF2020" />
          <circle cx="32" cy="40" r="9" fill="#990000" stroke="#FF2020" strokeWidth="1.5" />
          <circle cx="32" cy="27" r="2.5" fill="#FFFFFF" />
          
          {/* Upper Left Cyber Leg */}
          <path
            d="M26 24 L14 12 L6 18"
            stroke="#FF2020"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Mid-Upper Left Cyber Leg */}
          <path
            d="M24 28 L10 27 L3 35"
            stroke="#FF2020"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Mid-Lower Left Cyber Leg */}
          <path
            d="M25 36 L12 43 L8 53"
            stroke="#FF2020"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Lower Left Cyber Leg */}
          <path
            d="M28 44 L18 55 L14 62"
            stroke="#FF2020"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Upper Right Cyber Leg */}
          <path
            d="M38 24 L50 12 L58 18"
            stroke="#FF2020"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Mid-Upper Right Cyber Leg */}
          <path
            d="M40 28 L54 27 L61 35"
            stroke="#FF2020"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Mid-Lower Right Cyber Leg */}
          <path
            d="M39 36 L52 43 L56 53"
            stroke="#FF2020"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Lower Right Cyber Leg */}
          <path
            d="M36 44 L46 55 L50 62"
            stroke="#FF2020"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className={`font-extrabold tracking-wider leading-none flex items-center ${dim.font}`}>
            <span className="text-white">SPIDY</span>
            <span className="text-[#FF2020] ml-1 drop-shadow-[0_0_8px_rgba(255,32,32,0.8)]">AUTH</span>
          </div>
          <span className={`text-[#888888] font-mono tracking-widest uppercase mt-0.5 ${dim.sub}`}>
            SECURITY &bull; LICENSING
          </span>
        </div>
      )}
    </div>
  );
};
