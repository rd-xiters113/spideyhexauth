import React from 'react';
import { LucideIcon } from 'lucide-react';

// --- STAT CARD ---
interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: LucideIcon;
  badge?: string;
  badgeColor?: 'red' | 'green' | 'amber' | 'blue' | 'gray';
  trend?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  badge,
  badgeColor = 'red',
  trend,
}) => {
  const badgeClasses = {
    red: 'bg-[#FF2020]/15 text-[#FF2020] border-[#FF2020]/30',
    green: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
    amber: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    blue: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
    gray: 'bg-white/5 text-[#999999] border-white/10',
  };

  return (
    <div className="glass-card glass-card-hover rounded-xl p-5 relative overflow-hidden group">
      {/* Subtle background glow */}
      <div className="absolute -top-12 -right-12 w-28 h-28 bg-[#FF2020] opacity-[0.06] rounded-full blur-2xl group-hover:opacity-[0.12] transition-opacity" />

      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-[#888888] tracking-wider uppercase">{title}</p>
          <h3 className="text-2xl lg:text-3xl font-extrabold text-white mt-1.5 tracking-tight font-mono">
            {value}
          </h3>
          {subtitle && <p className="text-xs text-[#666666] mt-1">{subtitle}</p>}
          {trend && <p className="text-xs text-[#FF2020] mt-1 font-mono">{trend}</p>}
        </div>
        {Icon && (
          <div className="p-2.5 rounded-lg bg-[#181818] border border-white/5 text-[#FF2020] group-hover:scale-110 transition-transform shadow-inner">
            <Icon size={22} />
          </div>
        )}
      </div>

      {badge && (
        <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between">
          <span className={`text-[11px] font-mono font-medium px-2 py-0.5 rounded border ${badgeClasses[badgeColor]}`}>
            {badge}
          </span>
        </div>
      )}
    </div>
  );
};

// --- BADGE ---
interface BadgeProps {
  children: React.ReactNode;
  variant?: 'red' | 'green' | 'amber' | 'blue' | 'gray';
  size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({ children, variant = 'red', size = 'sm' }) => {
  const styles = {
    red: 'bg-[#FF2020]/15 text-[#FF2020] border-[#FF2020]/30',
    green: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
    amber: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    blue: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
    gray: 'bg-white/5 text-[#999999] border-white/10',
  };

  const sizes = {
    sm: 'text-[11px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
  };

  return (
    <span className={`inline-flex items-center gap-1 font-mono font-semibold rounded border ${styles[variant]} ${sizes[size]}`}>
      {children}
    </span>
  );
};

// --- MODAL ---
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  maxWidth?: string;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  maxWidth = 'max-w-lg',
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />
      {/* Modal Dialog */}
      <div
        className={`relative z-10 w-full ${maxWidth} bg-[#111111] border border-white/10 rounded-2xl shadow-2xl overflow-hidden neon-border`}
      >
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-[#151515]">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#FF2020]" />
            {title}
          </h3>
          <button
            onClick={onClose}
            className="text-[#888888] hover:text-white transition-colors p-1 rounded-lg hover:bg-white/5"
          >
            ✕
          </button>
        </div>
        <div className="p-6 max-h-[80vh] overflow-y-auto">{children}</div>
      </div>
    </div>
  );
};

// --- BUTTONS ---
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  className = '',
  disabled,
  ...props
}) => {
  const base = 'inline-flex items-center justify-center gap-2 font-semibold transition-all duration-200 rounded-lg cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed';

  const variants = {
    primary: 'bg-[#FF2020] hover:bg-[#ff3838] text-white shadow-[0_0_15px_rgba(255,32,32,0.35)] hover:shadow-[0_0_20px_rgba(255,32,32,0.5)] active:scale-[0.98]',
    secondary: 'bg-[#181818] hover:bg-[#222222] text-white border border-white/10 hover:border-white/20',
    danger: 'bg-red-950/40 hover:bg-red-900/50 text-red-400 border border-red-500/30',
    ghost: 'bg-transparent hover:bg-white/5 text-[#888888] hover:text-white',
  };

  const sizes = {
    sm: 'text-xs px-3 py-1.5',
    md: 'text-sm px-4 py-2.5',
    lg: 'text-base px-6 py-3',
  };

  return (
    <button
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <>
          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          <span>Processing...</span>
        </>
      ) : (
        children
      )}
    </button>
  );
};
