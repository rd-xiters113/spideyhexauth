import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  increment,
  onSnapshot,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './FirebaseConfig';
import {
  ApplicationItem,
  LicenseKeyItem,
  CredentialItem,
  PremiumAllowlistItem,
  UpgradeRequestItem,
  ResellerItem,
  ActivityLogItem,
  UserProfile,
} from './Types';

// Cryptographic token & key generator helper
export function generateRandomKey(prefix = 'SPIDY'): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const segment = (len = 4) => {
    let res = '';
    const array = new Uint8Array(len);
    window.crypto.getRandomValues(array);
    for (let i = 0; i < len; i++) {
      res += chars[array[i] % chars.length];
    }
    return res;
  };
  return `${prefix}-${segment(4)}-${segment(4)}-${segment(4)}-${segment(4)}`;
}

export function generateSecret(len = 32): string {
  const chars = 'abcdef0123456789';
  const array = new Uint8Array(len);
  window.crypto.getRandomValues(array);
  let res = '';
  for (let i = 0; i < len; i++) {
    res += chars[array[i] % chars.length];
  }
  return res;
}

// Simple SHA-256 hash helper for application credentials
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + '_spidy_salt_v1');
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Activity Logging Helper
export async function logActivity(
  actorId: string,
  actorEmail: string,
  actorRole: string,
  action: string,
  targetType: string,
  targetId: string,
  details: string
): Promise<void> {
  try {
    const logId = 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    await setDoc(doc(db, 'activity_logs', logId), {
      id: logId,
      actorId,
      actorEmail,
      actorRole,
      action,
      targetType,
      targetId,
      details,
      timestamp: new Date().toISOString(),
    });
  } catch (e) {
    console.warn('Logging error:', e);
  }
}

// --- APPLICATIONS ---
export async function createApplication(
  ownerId: string,
  ownerEmail: string,
  name: string,
  description: string,
  version: string,
  hwidLockEnabled: boolean
): Promise<ApplicationItem> {
  const appId = 'app_' + generateSecret(16);
  const appSecret = 'sec_' + generateSecret(32);
  const now = new Date().toISOString();

  const newApp: ApplicationItem = {
    id: appId,
    name,
    description,
    version,
    ownerId,
    ownerEmail,
    appSecret,
    status: 'active',
    hwidLockEnabled,
    createdAt: now,
    updatedAt: now,
  };

  try {
    await setDoc(doc(db, 'applications', appId), newApp);
    await logActivity(ownerId, ownerEmail, 'user', 'CREATE_APPLICATION', 'Application', appId, `Created app "${name}" v${version}`);
    return newApp;
  } catch (error) {
    return handleFirestoreError(error, OperationType.CREATE, 'applications');
  }
}

export async function getApplications(ownerId?: string, isAdmin = false): Promise<ApplicationItem[]> {
  try {
    let q;
    if (isAdmin && !ownerId) {
      q = query(collection(db, 'applications'), orderBy('createdAt', 'desc'));
    } else {
      q = query(collection(db, 'applications'), where('ownerId', '==', ownerId));
    }
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as ApplicationItem);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'applications');
  }
}

export async function deleteApplication(appId: string, actorId: string, actorEmail: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'applications', appId));
    await logActivity(actorId, actorEmail, 'user', 'DELETE_APPLICATION', 'Application', appId, `Deleted application ${appId}`);
  } catch (error) {
    return handleFirestoreError(error, OperationType.DELETE, 'applications');
  }
}

// --- LICENSE KEYS & QUOTA ENFORCEMENT ---
export interface GenerateKeyParams {
  ownerId: string;
  ownerEmail: string;
  appId: string;
  appName?: string;
  type: 'key' | 'credentials';
  durationDays: number;
  maxDevices?: number;
  notes?: string;
  username?: string;
  password?: string;
  customKey?: string;
}

export async function generateLicenseKey(params: GenerateKeyParams): Promise<LicenseKeyItem> {
  // 1. Quota & Subscription Verification (Part 4)
  const userRef = doc(db, 'users', params.ownerId);
  const userSnap = await getDoc(userRef);

  if (!userSnap.exists()) {
    throw new Error('User account not found');
  }

  const user = userSnap.data() as UserProfile;

  if (user.accountStatus === 'suspended') {
    throw new Error('Account is suspended. Please contact platform support.');
  }

  // Enforce Free Quota
  if (user.plan === 'FREE') {
    if ((user.keysUsed || 0) >= 50) {
      throw new Error('You have reached your Free Plan key generation limit (50 keys). Upgrade to Premium to access additional features.');
    }
  }

  // 2. Generate Key
  const keyId = 'lic_' + generateSecret(16);
  const keyCode = params.customKey?.trim() || generateRandomKey('SPIDY');
  const now = new Date().toISOString();

  let passwordHash = undefined;
  if (params.password) {
    passwordHash = await hashPassword(params.password);
  }

  const newKey: LicenseKeyItem = {
    id: keyId,
    key: keyCode,
    appId: params.appId,
    appName: params.appName || 'Application',
    ownerId: params.ownerId,
    type: params.type,
    durationDays: params.durationDays,
    status: 'unused',
    hwid: null,
    maxDevices: params.maxDevices || 1,
    currentDevices: 0,
    notes: params.notes || '',
    username: params.username || null,
    passwordHash: passwordHash || null,
    createdAt: now,
  };

  try {
    // Write key
    await setDoc(doc(db, 'license_keys', keyId), newKey);

    // Increment used quota on user profile (Immutable consumption - deleting won't restore quota)
    await updateDoc(userRef, {
      keysUsed: increment(1),
    });

    await logActivity(
      params.ownerId,
      params.ownerEmail,
      user.role,
      'GENERATE_LICENSE_KEY',
      'LicenseKey',
      keyId,
      `Generated key ${keyCode} for app ${params.appName || params.appId} (Used: ${(user.keysUsed || 0) + 1}/${user.maxKeysQuota})`
    );

    return newKey;
  } catch (error) {
    return handleFirestoreError(error, OperationType.WRITE, 'license_keys');
  }
}

export async function getLicenseKeys(ownerId?: string, appId?: string, isAdmin = false): Promise<LicenseKeyItem[]> {
  try {
    let q;
    if (isAdmin && !ownerId) {
      if (appId) {
        q = query(collection(db, 'license_keys'), where('appId', '==', appId));
      } else {
        q = query(collection(db, 'license_keys'), orderBy('createdAt', 'desc'));
      }
    } else {
      if (appId) {
        q = query(collection(db, 'license_keys'), where('ownerId', '==', ownerId), where('appId', '==', appId));
      } else {
        q = query(collection(db, 'license_keys'), where('ownerId', '==', ownerId));
      }
    }
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as LicenseKeyItem);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'license_keys');
  }
}

export async function updateLicenseStatus(
  keyId: string,
  status: 'unused' | 'active' | 'expired' | 'banned',
  actorId: string,
  actorEmail: string,
  bannedReason?: string
): Promise<void> {
  try {
    const keyRef = doc(db, 'license_keys', keyId);
    const updatePayload: Record<string, any> = { status };
    if (status === 'banned') {
      updatePayload.bannedReason = bannedReason || 'Violated software terms';
    }
    await updateDoc(keyRef, updatePayload);
    await logActivity(actorId, actorEmail, 'user', 'UPDATE_LICENSE_STATUS', 'LicenseKey', keyId, `Status changed to ${status}`);
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, 'license_keys');
  }
}

export async function resetLicenseHwid(keyId: string, actorId: string, actorEmail: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'license_keys', keyId), {
      hwid: null,
      currentDevices: 0,
    });
    await logActivity(actorId, actorEmail, 'user', 'RESET_HWID', 'LicenseKey', keyId, 'HWID hardware lock was reset.');
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, 'license_keys');
  }
}

// Note: Deleting a key explicitly does NOT decrement used quota
export async function deleteLicenseKey(keyId: string, actorId: string, actorEmail: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'license_keys', keyId));
    await logActivity(actorId, actorEmail, 'user', 'DELETE_LICENSE_KEY', 'LicenseKey', keyId, `Deleted license key (Quota not refunded)`);
  } catch (error) {
    return handleFirestoreError(error, OperationType.DELETE, 'license_keys');
  }
}

// --- USERNAME & PASSWORD APP CREDENTIALS (Part 9) ---
export async function createCredential(
  ownerId: string,
  ownerEmail: string,
  appId: string,
  username: string,
  passwordPlain: string,
  durationDays: number,
  deviceLimit = 1
): Promise<CredentialItem> {
  const credId = 'cred_' + generateSecret(16);
  const passwordHash = await hashPassword(passwordPlain);
  const now = new Date().toISOString();

  let expiresAt = null;
  if (durationDays > 0) {
    const exp = new Date();
    exp.setDate(exp.getDate() + durationDays);
    expiresAt = exp.toISOString();
  }

  const newCred: CredentialItem = {
    id: credId,
    appId,
    ownerId,
    username,
    passwordHash,
    durationDays,
    status: 'active',
    deviceLimit,
    currentHwid: null,
    expiresAt,
    createdAt: now,
  };

  try {
    await setDoc(doc(db, 'credentials', credId), newCred);
    await logActivity(ownerId, ownerEmail, 'user', 'CREATE_CREDENTIAL', 'Credential', credId, `Created credential user "${username}"`);
    return newCred;
  } catch (error) {
    return handleFirestoreError(error, OperationType.CREATE, 'credentials');
  }
}

/**
 * Look up a license key to inspect its duration and validity before user registration
 */
export async function lookupLicenseKeyForRegistration(
  appId: string,
  keyCode: string
): Promise<{
  valid: boolean;
  message?: string;
  keyData?: LicenseKeyItem;
  durationDays?: number;
  isLifetime?: boolean;
}> {
  const cleanKey = keyCode.trim();
  if (!cleanKey) {
    return { valid: false, message: 'Please enter a license key' };
  }

  try {
    const q = query(
      collection(db, 'license_keys'),
      where('appId', '==', appId),
      where('key', '==', cleanKey)
    );
    const snap = await getDocs(q);

    if (snap.empty) {
      return { valid: false, message: 'License key does not exist for this application' };
    }

    const keyData = snap.docs[0].data() as LicenseKeyItem;

    if (keyData.status === 'banned') {
      return { valid: false, message: 'This license key has been banned' };
    }

    if (keyData.status === 'expired') {
      return { valid: false, message: 'This license key has already expired' };
    }

    if (keyData.username && keyData.status === 'active') {
      return {
        valid: false,
        message: `This key is already registered to user "${keyData.username}"`,
      };
    }

    return {
      valid: true,
      keyData,
      durationDays: keyData.durationDays,
      isLifetime: keyData.durationDays === -1,
    };
  } catch (error) {
    return { valid: false, message: 'Error checking license key' };
  }
}

/**
 * Register a Username & Password account using a License Key.
 * Crucial guarantee: The user account automatically inherits the EXACT duration configured on the license key!
 */
export async function registerCredentialWithKey(params: {
  ownerId: string;
  ownerEmail: string;
  appId: string;
  keyCode: string;
  username: string;
  passwordPlain: string;
  hwid?: string;
}): Promise<CredentialItem> {
  const { ownerId, ownerEmail, appId, keyCode, username, passwordPlain, hwid } = params;
  const cleanKey = keyCode.trim();
  const cleanUser = username.trim();

  if (!cleanKey || !cleanUser || !passwordPlain) {
    throw new Error('Please fill in all required registration fields (Key, Username, Password)');
  }

  // 1. Verify key in Firestore
  const q = query(
    collection(db, 'license_keys'),
    where('appId', '==', appId),
    where('key', '==', cleanKey)
  );
  const snap = await getDocs(q);

  if (snap.empty) {
    throw new Error('License key not found for this application');
  }

  const keyDoc = snap.docs[0];
  const keyData = keyDoc.data() as LicenseKeyItem;

  if (keyData.status === 'banned') {
    throw new Error('This license key has been banned by the administrator');
  }

  if (keyData.username && keyData.status === 'active') {
    throw new Error(`This license key is already registered to user "${keyData.username}"`);
  }

  // 2. Check if username is already taken in this app
  const credCheckQ = query(
    collection(db, 'credentials'),
    where('appId', '==', appId),
    where('username', '==', cleanUser)
  );
  const credCheckSnap = await getDocs(credCheckQ);
  if (!credCheckSnap.empty) {
    throw new Error(`The username "${cleanUser}" is already taken in this application. Please choose another.`);
  }

  // 3. Compute password hash
  const passwordHash = await hashPassword(passwordPlain);
  const now = new Date();

  // 4. Inherit EXACT duration configured on the license key
  let expiresAt: string | null = null;
  if (keyData.durationDays > 0) {
    const exp = new Date(now);
    exp.setDate(exp.getDate() + keyData.durationDays);
    expiresAt = exp.toISOString();
  }

  const credId = 'cred_' + generateSecret(16);
  const newCred: CredentialItem = {
    id: credId,
    appId,
    ownerId: keyData.ownerId || ownerId,
    username: cleanUser,
    passwordHash,
    durationDays: keyData.durationDays,
    status: 'active',
    deviceLimit: keyData.maxDevices || 1,
    currentHwid: hwid || null,
    expiresAt,
    createdAt: now.toISOString(),
  };

  try {
    // Write credential
    await setDoc(doc(db, 'credentials', credId), newCred);

    // Update license key record to mark it redeemed & link to username
    await updateDoc(doc(db, 'license_keys', keyDoc.id), {
      status: 'active',
      username: cleanUser,
      passwordHash,
      hwid: hwid || null,
      activatedAt: now.toISOString(),
      expiresAt,
      lastUsedAt: now.toISOString(),
    });

    await logActivity(
      ownerId,
      ownerEmail,
      'user',
      'REGISTER_USER_VIA_KEY',
      'Credential',
      credId,
      `Registered user "${cleanUser}" using key ${cleanKey} inheriting duration: ${keyData.durationDays === -1 ? 'Lifetime' : `${keyData.durationDays} Days`}`
    );

    return newCred;
  } catch (error) {
    return handleFirestoreError(error, OperationType.WRITE, 'credentials');
  }
}

export async function getCredentials(ownerId?: string, appId?: string, isAdmin = false): Promise<CredentialItem[]> {
  try {
    let q;
    if (isAdmin && !ownerId) {
      q = query(collection(db, 'credentials'), orderBy('createdAt', 'desc'));
    } else {
      if (appId) {
        q = query(collection(db, 'credentials'), where('ownerId', '==', ownerId), where('appId', '==', appId));
      } else {
        q = query(collection(db, 'credentials'), where('ownerId', '==', ownerId));
      }
    }
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as CredentialItem);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'credentials');
  }
}

export async function revokeCredential(credId: string, actorId: string, actorEmail: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'credentials', credId), { status: 'suspended' });
    await logActivity(actorId, actorEmail, 'user', 'REVOKE_CREDENTIAL', 'Credential', credId, 'Suspended application credentials');
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, 'credentials');
  }
}

export async function deleteCredential(credId: string, actorId: string, actorEmail: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'credentials', credId));
    await logActivity(actorId, actorEmail, 'user', 'DELETE_CREDENTIAL', 'Credential', credId, 'Deleted credential');
  } catch (error) {
    return handleFirestoreError(error, OperationType.DELETE, 'credentials');
  }
}

// --- RESELLER MANAGEMENT (Part 10) ---
export async function createReseller(
  ownerId: string,
  ownerEmail: string,
  appId: string,
  resellerUsername: string,
  resellerEmail: string,
  keysQuota: number,
  permissions = 'GENERATE_KEYS,VIEW_KEYS'
): Promise<ResellerItem> {
  const resellerId = 'res_' + generateSecret(16);
  const now = new Date().toISOString();

  const item: ResellerItem = {
    id: resellerId,
    ownerId,
    appId,
    resellerUsername,
    resellerEmail,
    keysQuota,
    keysUsed: 0,
    permissions,
    status: 'active',
    createdAt: now,
  };

  try {
    await setDoc(doc(db, 'resellers', resellerId), item);
    await logActivity(ownerId, ownerEmail, 'user', 'CREATE_RESELLER', 'Reseller', resellerId, `Created reseller "${resellerUsername}" (${keysQuota} quota)`);
    return item;
  } catch (error) {
    return handleFirestoreError(error, OperationType.CREATE, 'resellers');
  }
}

export async function getResellers(ownerId?: string, isAdmin = false): Promise<ResellerItem[]> {
  try {
    let q;
    if (isAdmin && !ownerId) {
      q = query(collection(db, 'resellers'), orderBy('createdAt', 'desc'));
    } else {
      q = query(collection(db, 'resellers'), where('ownerId', '==', ownerId));
    }
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as ResellerItem);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'resellers');
  }
}

// --- PREMIUM EMAIL ALLOWLIST & SUBSCRIPTION APPROVAL (Part 5 & Part 14) ---
export async function adminApprovePremium(
  adminId: string,
  adminEmail: string,
  targetEmail: string,
  durationDays: number // -1 for lifetime, 30, 90, 180, 365
): Promise<PremiumAllowlistItem> {
  const normalizedEmail = targetEmail.trim().toLowerCase();
  const allowId = 'allow_' + normalizedEmail.replace(/[^a-zA-Z0-9]/g, '_');
  const now = new Date();

  let expiresAt = null;
  if (durationDays > 0) {
    const exp = new Date(now);
    exp.setDate(exp.getDate() + durationDays);
    expiresAt = exp.toISOString();
  }

  const record: PremiumAllowlistItem = {
    id: allowId,
    email: normalizedEmail,
    plan: 'PREMIUM',
    durationDays,
    approvedBy: adminEmail,
    approvedAt: now.toISOString(),
    expiresAt,
    status: 'active',
  };

  try {
    await setDoc(doc(db, 'premium_allowlist', allowId), record);

    // Check if target user has an account already and update profile
    const usersQ = query(collection(db, 'users'), where('email', '==', normalizedEmail));
    const usersSnap = await getDocs(usersQ);
    if (!usersSnap.empty) {
      const userDoc = usersSnap.docs[0];
      await updateDoc(doc(db, 'users', userDoc.id), {
        plan: 'PREMIUM',
        maxKeysQuota: 999999,
        subscriptionExpiresAt: expiresAt,
      });
    }

    await logActivity(
      adminId,
      adminEmail,
      'admin',
      'APPROVE_PREMIUM_ACCESS',
      'PremiumAllowlist',
      allowId,
      `Approved Premium for ${normalizedEmail} (${durationDays === -1 ? 'Lifetime' : durationDays + ' days'})`
    );

    return record;
  } catch (error) {
    return handleFirestoreError(error, OperationType.WRITE, 'premium_allowlist');
  }
}

export async function adminRevokePremium(
  adminId: string,
  adminEmail: string,
  targetEmail: string
): Promise<void> {
  const normalizedEmail = targetEmail.trim().toLowerCase();
  const allowId = 'allow_' + normalizedEmail.replace(/[^a-zA-Z0-9]/g, '_');

  try {
    await updateDoc(doc(db, 'premium_allowlist', allowId), {
      status: 'revoked',
    });

    // Downgrade user profile if exists
    const usersQ = query(collection(db, 'users'), where('email', '==', normalizedEmail));
    const usersSnap = await getDocs(usersQ);
    if (!usersSnap.empty) {
      const userDoc = usersSnap.docs[0];
      await updateDoc(doc(db, 'users', userDoc.id), {
        plan: 'FREE',
        maxKeysQuota: 50,
        subscriptionExpiresAt: null,
      });
    }

    await logActivity(
      adminId,
      adminEmail,
      'admin',
      'REVOKE_PREMIUM_ACCESS',
      'PremiumAllowlist',
      allowId,
      `Revoked Premium access for ${normalizedEmail}`
    );
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, 'premium_allowlist');
  }
}

export async function getPremiumAllowlist(): Promise<PremiumAllowlistItem[]> {
  try {
    const snap = await getDocs(collection(db, 'premium_allowlist'));
    return snap.docs.map((d) => d.data() as PremiumAllowlistItem);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'premium_allowlist');
  }
}

// --- MANUAL UPGRADE REQUESTS (Part 16) ---
export async function submitUpgradeRequest(
  userId: string,
  email: string,
  requestedPlan: string,
  duration: string,
  paymentReference = '',
  message = ''
): Promise<UpgradeRequestItem> {
  const reqId = 'req_' + generateSecret(16);
  const now = new Date().toISOString();

  const reqItem: UpgradeRequestItem = {
    id: reqId,
    userId,
    email,
    requestedPlan,
    duration,
    paymentReference,
    message,
    status: 'pending',
    createdAt: now,
  };

  try {
    await setDoc(doc(db, 'upgrade_requests', reqId), reqItem);
    await logActivity(userId, email, 'user', 'SUBMIT_UPGRADE_REQUEST', 'UpgradeRequest', reqId, `Requested ${requestedPlan} (${duration})`);
    return reqItem;
  } catch (error) {
    return handleFirestoreError(error, OperationType.CREATE, 'upgrade_requests');
  }
}

export async function getUpgradeRequests(userId?: string, isAdmin = false): Promise<UpgradeRequestItem[]> {
  try {
    let q;
    if (isAdmin && !userId) {
      q = query(collection(db, 'upgrade_requests'), orderBy('createdAt', 'desc'));
    } else {
      q = query(collection(db, 'upgrade_requests'), where('userId', '==', userId));
    }
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as UpgradeRequestItem);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'upgrade_requests');
  }
}

export async function adminResolveUpgradeRequest(
  adminId: string,
  adminEmail: string,
  requestId: string,
  approved: boolean,
  targetEmail: string,
  durationDays: number
): Promise<void> {
  try {
    const now = new Date().toISOString();
    await updateDoc(doc(db, 'upgrade_requests', requestId), {
      status: approved ? 'approved' : 'rejected',
      reviewedAt: now,
      reviewedBy: adminEmail,
    });

    if (approved) {
      await adminApprovePremium(adminId, adminEmail, targetEmail, durationDays);
    }

    await logActivity(
      adminId,
      adminEmail,
      'admin',
      approved ? 'APPROVE_UPGRADE_REQUEST' : 'REJECT_UPGRADE_REQUEST',
      'UpgradeRequest',
      requestId,
      `${approved ? 'Approved' : 'Rejected'} upgrade request for ${targetEmail}`
    );
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, 'upgrade_requests');
  }
}

// --- ACTIVITY LOGS & TELEMETRY ---
export async function getActivityLogs(limitCount = 50, actorId?: string, isAdmin = false): Promise<ActivityLogItem[]> {
  try {
    let q;
    if (isAdmin && !actorId) {
      q = query(collection(db, 'activity_logs'), orderBy('timestamp', 'desc'), limit(limitCount));
    } else {
      q = query(collection(db, 'activity_logs'), where('actorId', '==', actorId), limit(limitCount));
    }
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as ActivityLogItem);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'activity_logs');
  }
}

// --- USERS MANAGEMENT (Admin) ---
export async function getAllUsers(): Promise<UserProfile[]> {
  try {
    const snap = await getDocs(collection(db, 'users'));
    return snap.docs.map((d) => d.data() as UserProfile);
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, 'users');
  }
}

export async function adminUpdateUserStatus(
  adminId: string,
  adminEmail: string,
  targetUserId: string,
  status: 'active' | 'suspended'
): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', targetUserId), {
      accountStatus: status,
    });
    await logActivity(adminId, adminEmail, 'admin', 'CHANGE_USER_STATUS', 'User', targetUserId, `Changed account status to ${status}`);
  } catch (error) {
    return handleFirestoreError(error, OperationType.UPDATE, 'users');
  }
}
