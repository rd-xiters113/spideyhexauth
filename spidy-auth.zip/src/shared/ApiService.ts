// Client REST API service for applications, tests and SDK preview

export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  error?: string;
  data?: T;
  [key: string]: any;
}

export class SpidyApiClient {
  private baseUrl: string;

  constructor(baseUrl = '') {
    this.baseUrl = baseUrl;
  }

  async initApp(appId: string, appSecret: string): Promise<ApiResponse> {
    const res = await fetch(`${this.baseUrl}/api/v1/application/init`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId, appSecret }),
    });
    return res.json();
  }

  async verifyLicense(appId: string, key: string, hwid?: string): Promise<ApiResponse> {
    const res = await fetch(`${this.baseUrl}/api/v1/license/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId, key, hwid }),
    });
    return res.json();
  }

  async login(appId: string, params: { key?: string; username?: string; password?: string; hwid: string }): Promise<ApiResponse> {
    const res = await fetch(`${this.baseUrl}/api/v1/license/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId, ...params }),
    });
    return res.json();
  }

  async register(appId: string, params: { key: string; username: string; password: string; hwid: string }): Promise<ApiResponse> {
    const res = await fetch(`${this.baseUrl}/api/v1/license/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId, ...params }),
    });
    return res.json();
  }

  async resetHwid(appId: string, key: string): Promise<ApiResponse> {
    const res = await fetch(`${this.baseUrl}/api/v1/license/hwid-reset`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId, key }),
    });
    return res.json();
  }

  async checkVersion(appId: string): Promise<ApiResponse> {
    const res = await fetch(`${this.baseUrl}/api/v1/application/version?appId=${encodeURIComponent(appId)}`);
    return res.json();
  }

  async checkSubscription(email: string): Promise<ApiResponse> {
    const res = await fetch(`${this.baseUrl}/api/v1/subscription/status?email=${encodeURIComponent(email)}`);
    return res.json();
  }
}

export const apiService = new SpidyApiClient();
