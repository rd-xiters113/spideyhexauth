import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, collection, query, where, getDocs, onSnapshot } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType, testFirestoreConnection } from './FirebaseConfig';
import { UserProfile, SubscriptionPlan, UserRole } from './Types';

// Initial bootstrapped super admin from runtime
export const BOOTSTRAP_SUPERADMIN_EMAIL = 'romaanchudary1@gmail.com';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  refreshProfile: () => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, displayName?: string) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  resendVerificationEmail: () => Promise<void>;
  remainingKeys: number;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Test connection on mount
  useEffect(() => {
    testFirestoreConnection();
  }, []);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await syncUserProfile(user);
      } else {
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Real-time listener for user profile changes once authenticated
  useEffect(() => {
    if (!currentUser) return;

    const userDocRef = doc(db, 'users', currentUser.uid);
    const unsubDoc = onSnapshot(userDocRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        setUserProfile(data);
        // Check allowlist in background to ensure sync
        checkPremiumAllowlistSync(currentUser.email || '', data);
      }
    }, (error) => {
      console.warn('Profile listener error:', error);
    });

    return () => unsubDoc();
  }, [currentUser]);

  // Synchronize or create user profile on login
  const syncUserProfile = async (user: FirebaseUser) => {
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const snap = await getDoc(userDocRef);

      const isBootstrappedAdmin = user.email?.toLowerCase() === BOOTSTRAP_SUPERADMIN_EMAIL.toLowerCase();

      if (!snap.exists()) {
        // Automatic Free Plan Assignment (Part 4)
        const newProfile: UserProfile = {
          id: user.uid,
          email: user.email || '',
          displayName: user.displayName || user.email?.split('@')[0] || 'User',
          createdAt: new Date().toISOString(),
          accountStatus: 'active',
          plan: 'FREE',
          keysUsed: 0,
          maxKeysQuota: 50,
          role: isBootstrappedAdmin ? 'superadmin' : 'user',
          subscriptionExpiresAt: null,
          lastLoginAt: new Date().toISOString(),
        };

        // If bootstrapped admin, record in admins collection too
        if (isBootstrappedAdmin) {
          try {
            await setDoc(doc(db, 'admins', user.uid), {
              id: user.uid,
              email: user.email,
              role: 'superadmin',
              addedAt: new Date().toISOString(),
              addedBy: 'SYSTEM_BOOTSTRAP',
            });
          } catch {
            // Ignore if exists
          }
        }

        await setDoc(userDocRef, newProfile);
        setUserProfile(newProfile);
        await checkPremiumAllowlistSync(user.email || '', newProfile);
      } else {
        const existing = snap.data() as UserProfile;
        
        // Ensure superadmin role if matches bootstrap email
        let updatedRole = existing.role;
        if (isBootstrappedAdmin && existing.role !== 'superadmin') {
          updatedRole = 'superadmin';
          await updateDoc(userDocRef, { role: 'superadmin' });
        }

        const currentData: UserProfile = {
          ...existing,
          role: updatedRole,
        };
        setUserProfile(currentData);
        await checkPremiumAllowlistSync(user.email || '', currentData);
      }
    } catch (err) {
      console.error('Error syncing profile:', err);
    } finally {
      setLoading(false);
    }
  };

  // Sync with Admin Premium Allowlist (Part 5 & Part 14)
  const checkPremiumAllowlistSync = async (email: string, currentProfile: UserProfile) => {
    if (!email || !currentProfile) return;

    try {
      // Query allowlist for this email
      const allowlistQ = query(
        collection(db, 'premium_allowlist'),
        where('email', '==', email.toLowerCase()),
        where('status', '==', 'active')
      );
      const allowlistSnap = await getDocs(allowlistQ);

      const now = new Date();

      if (!allowlistSnap.empty) {
        const allowRecord = allowlistSnap.docs[0].data();
        let isExpired = false;

        if (allowRecord.expiresAt) {
          const expDate = new Date(allowRecord.expiresAt);
          if (expDate < now) {
            isExpired = true;
          }
        }

        if (!isExpired) {
          // Grant Premium if not already active
          if (currentProfile.plan !== 'PREMIUM') {
            const userDocRef = doc(db, 'users', currentProfile.id);
            await updateDoc(userDocRef, {
              plan: 'PREMIUM',
              maxKeysQuota: 999999,
              subscriptionExpiresAt: allowRecord.expiresAt || null,
            });
            setUserProfile((prev) => prev ? {
              ...prev,
              plan: 'PREMIUM',
              maxKeysQuota: 999999,
              subscriptionExpiresAt: allowRecord.expiresAt || null,
            } : null);
          }
          return;
        }
      }

      // If user had Premium with an expiration that passed, downgrade to FREE
      if (currentProfile.plan === 'PREMIUM' && currentProfile.subscriptionExpiresAt) {
        const expDate = new Date(currentProfile.subscriptionExpiresAt);
        if (expDate < now) {
          const userDocRef = doc(db, 'users', currentProfile.id);
          await updateDoc(userDocRef, {
            plan: 'FREE',
            maxKeysQuota: 50,
            subscriptionExpiresAt: null,
          });
          setUserProfile((prev) => prev ? {
            ...prev,
            plan: 'FREE',
            maxKeysQuota: 50,
            subscriptionExpiresAt: null,
          } : null);
        }
      }
    } catch (e) {
      console.warn('Allowlist sync error:', e);
    }
  };

  const refreshProfile = async () => {
    if (currentUser) {
      await syncUserProfile(currentUser);
    }
  };

  const loginWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        await syncUserProfile(result.user);
      }
    } catch (err: unknown) {
      console.error('Google Sign In failed:', err);
      throw err;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    const result = await signInWithEmailAndPassword(auth, email, pass);
    if (result.user) {
      await syncUserProfile(result.user);
    }
  };

  const registerWithEmail = async (email: string, pass: string, displayName?: string) => {
    const result = await createUserWithEmailAndPassword(auth, email, pass);
    if (result.user) {
      // Send verification email
      try {
        await sendEmailVerification(result.user);
      } catch (e) {
        console.warn('Could not send verification email:', e);
      }
      await syncUserProfile(result.user);
    }
  };

  const logout = async () => {
    await signOut(auth);
    setUserProfile(null);
    setCurrentUser(null);
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const resendVerificationEmail = async () => {
    if (currentUser && !currentUser.emailVerified) {
      await sendEmailVerification(currentUser);
    }
  };

  const isSuperAdmin = 
    userProfile?.role === 'superadmin' || 
    currentUser?.email?.toLowerCase() === BOOTSTRAP_SUPERADMIN_EMAIL.toLowerCase();

  const isAdmin = isSuperAdmin || userProfile?.role === 'admin';

  const remainingKeys = userProfile 
    ? Math.max(0, userProfile.maxKeysQuota - (userProfile.keysUsed || 0)) 
    : 0;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        isAdmin,
        isSuperAdmin,
        refreshProfile,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        logout,
        resetPassword,
        resendVerificationEmail,
        remainingKeys,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
};
