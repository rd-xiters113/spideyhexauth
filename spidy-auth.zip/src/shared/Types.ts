export type UserRole = 'user' | 'admin' | 'superadmin';
export type SubscriptionPlan = 'FREE' | 'PREMIUM';
export type AccountStatus = 'active' | 'suspended';
export type LicenseType = 'key' | 'credentials';
export type LicenseStatus = 'unused' | 'active' | 'expired' | 'banned';
export type RequestStatus = 'pending' | 'approved' | 'rejected';

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  createdAt: string;
  accountStatus: AccountStatus;
  plan: SubscriptionPlan;
  keysUsed: number;
  maxKeysQuota: number; // 50 for FREE, 999999 for PREMIUM
  role: UserRole;
  subscriptionExpiresAt?: string | null;
  lastLoginAt?: string;
}

export interface AdminRecord {
  id: string;
  email: string;
  role: 'superadmin' | 'admin';
  addedAt: string;
  addedBy: string;
}

export interface ApplicationItem {
  id: string;
  name: string;
  description: string;
  version: string;
  ownerId: string;
  ownerEmail: string;
  appSecret: string;
  status: 'active' | 'disabled';
  hwidLockEnabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface LicenseKeyItem {
  id: string;
  key: string;
  appId: string;
  appName?: string;
  ownerId: string;
  type: LicenseType;
  durationDays: number; // -1 for lifetime
  status: LicenseStatus;
  hwid?: string | null;
  maxDevices: number;
  currentDevices?: number;
  notes?: string;
  username?: string | null;
  passwordHash?: string | null;
  createdAt: string;
  activatedAt?: string | null;
  expiresAt?: string | null;
  lastUsedAt?: string | null;
  bannedReason?: string | null;
}

export interface CredentialItem {
  id: string;
  appId: string;
  ownerId: string;
  username: string;
  passwordHash: string;
  durationDays: number;
  status: 'active' | 'suspended' | 'expired';
  deviceLimit: number;
  currentHwid?: string | null;
  expiresAt?: string | null;
  createdAt: string;
}

export interface PremiumAllowlistItem {
  id: string;
  email: string;
  plan: 'PREMIUM';
  durationDays: number; // 30, 90, 180, 365, -1
  approvedBy: string;
  approvedAt: string;
  expiresAt?: string | null;
  status: 'active' | 'revoked' | 'expired';
}

export interface UpgradeRequestItem {
  id: string;
  userId: string;
  email: string;
  requestedPlan: string;
  duration: string;
  paymentReference?: string;
  message?: string;
  status: RequestStatus;
  createdAt: string;
  reviewedAt?: string | null;
  reviewedBy?: string | null;
}

export interface ResellerItem {
  id: string;
  ownerId: string;
  appId: string;
  resellerUsername: string;
  resellerEmail: string;
  keysQuota: number;
  keysUsed: number;
  permissions: string;
  status: 'active' | 'suspended';
  expiresAt?: string | null;
  createdAt: string;
}

export interface ActivityLogItem {
  id: string;
  actorId: string;
  actorEmail: string;
  actorRole: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  timestamp: string;
  ipAddress?: string;
}
